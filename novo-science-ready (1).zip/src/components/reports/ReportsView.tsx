import React, { useState, useMemo } from 'react';
import { userHandle, roleLabel } from '../../services/username';
import {
  BarChart3,
  TrendingUp,
  FileSpreadsheet,
  Printer,
  Calendar,
  DollarSign,
  PieChart,
  Users,
  Boxes,
  CreditCard,
  Receipt,
  ArrowUpRight,
  ArrowDownRight,
  FileDown,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import {
  Order,
  Customer,
  Product,
  Expense,
  Payment,
  UserProfile,
  SystemSettings,
  Area,
} from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { CompanyBrandHeader } from '../common/CompanyBrandHeader';
import {
  exportProfitLossPDF,
  exportSalesReportPDF,
  exportInventoryPDF,
  exportDueSummaryPDF,
  exportStaffPerformancePDF,
  exportDailySalesPDF,
} from '../../utils/pdfExport';

interface ReportsViewProps {
  orders: Order[];
  customers: Customer[];
  products: Product[];
  expenses: Expense[];
  payments: Payment[];
  staffMembers: UserProfile[];
  areas: Area[];
  settings: SystemSettings;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  orders = [],
  customers = [],
  products = [],
  expenses = [],
  payments = [],
  staffMembers = [],
  areas = [],
  settings,
}) => {
  const [selectedReport, setSelectedReport] = useState<
    'profit_loss' | 'daily_sales' | 'sales_summary' | 'due_summary' | 'inventory_valuation' | 'staff_performance'
  >('profit_loss');

  // Date range filter
  const todayStr = new Date().toISOString().split('T')[0];
  const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    .toISOString()
    .split('T')[0];

  const [startDate, setStartDate] = useState(firstDayOfMonth);
  const [endDate, setEndDate] = useState(todayStr);

  const currencySymbol = settings.currencySymbol || '৳';

  // ---- Daily sales (one selected day, local time) ----
  const localDay = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const dayOf = (iso: string) => (iso.length === 10 ? iso : localDay(new Date(iso)));
  const [dailyDate, setDailyDate] = useState(() => localDay(new Date()));

  const dailyOrders = useMemo(
    () =>
      orders.filter(
        (o) => !o.isDeleted && o.orderStatus === 'APPROVED' && dayOf(o.date || o.createdAt) === dailyDate
      ),
    [orders, dailyDate]
  );
  const billOf = (o: Order) => o.grandTotal ?? o.finalAmount ?? 0;
  const dailyTotals = useMemo(
    () => ({
      sales: dailyOrders.reduce((sum, o) => sum + billOf(o), 0),
      paid: dailyOrders.reduce((sum, o) => sum + (o.paidAmount || 0), 0),
      due: dailyOrders.reduce((sum, o) => sum + (o.dueAmount || 0), 0),
    }),
    [dailyOrders]
  );
  const dailyProducts = useMemo(() => {
    const map: Record<string, { name: string; qty: number; amount: number }> = {};
    dailyOrders.forEach((o) =>
      (o.items || []).forEach((it) => {
        const key = it.productId || it.productName;
        if (!map[key]) map[key] = { name: it.productName, qty: 0, amount: 0 };
        map[key].qty += it.quantity || 0;
        map[key].amount += it.total ?? (it.quantity || 0) * (it.unitPrice || 0);
      })
    );
    return Object.values(map).sort((a, b) => b.amount - a.amount);
  }, [dailyOrders]);

  // Filter orders in range (Approved/Delivered count toward sales)
  const rangeOrders = useMemo(() => {
    return orders.filter((o) => {
      const orderDate = (o.date || o.createdAt).split('T')[0];
      return (
        orderDate >= startDate &&
        orderDate <= endDate &&
        o.orderStatus === 'APPROVED'
      );
    });
  }, [orders, startDate, endDate]);

  // Filter expenses in range
  const rangeExpenses = useMemo(() => {
    return expenses.filter((e) => {
      const expDate = (e.date || e.createdAt).split('T')[0];
      return expDate >= startDate && expDate <= endDate;
    });
  }, [expenses, startDate, endDate]);

  // Filter payments collected in range
  const rangePayments = useMemo(() => {
    return payments.filter((p) => {
      const pDate = (p.date || p.createdAt).split('T')[0];
      return pDate >= startDate && pDate <= endDate;
    });
  }, [payments, startDate, endDate]);

  // PROFIT & LOSS CALCULATIONS
  const pnlMetrics = useMemo(() => {
    const totalSales = rangeOrders.reduce((sum, o) => sum + o.finalAmount, 0);

    // COGS estimation: match order items to product purchasePrice
    const prodMap: Record<string, Product> = {};
    products.forEach((p) => {
      prodMap[p.id] = p;
    });

    let totalCogs = 0;
    rangeOrders.forEach((o) => {
      o.items.forEach((item) => {
        const prod = prodMap[item.productId];
        const costPrice = prod ? prod.purchasePrice : item.unitPrice * 0.7; // fallback 70% if unmapped
        totalCogs += costPrice * item.quantity;
      });
    });

    const grossProfit = totalSales - totalCogs;
    const totalExpenses = rangeExpenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = grossProfit - totalExpenses;
    const profitMargin = totalSales > 0 ? (netProfit / totalSales) * 100 : 0;

    return {
      totalSales,
      totalCogs,
      grossProfit,
      totalExpenses,
      netProfit,
      profitMargin,
    };
  }, [rangeOrders, rangeExpenses, products]);

  // INVENTORY VALUATION
  const inventoryMetrics = useMemo(() => {
    let totalCostValuation = 0;
    let totalRetailValuation = 0;
    let totalUnits = 0;
    let lowStockCount = 0;

    products.forEach((p) => {
      totalCostValuation += p.currentStock * p.purchasePrice;
      totalRetailValuation += p.currentStock * p.salePrice;
      totalUnits += p.currentStock;
      if (p.currentStock <= p.minimumStock) lowStockCount++;
    });

    return {
      totalCostValuation,
      totalRetailValuation,
      expectedMargin: totalRetailValuation - totalCostValuation,
      totalUnits,
      lowStockCount,
    };
  }, [products]);

  // STAFF PERFORMANCE
  const staffPerformance = useMemo(() => {
    return (staffMembers || []).map((staff) => {
      const staffOrders = rangeOrders.filter((o) => o.staffId === staff.uid);
      const salesCount = staffOrders.length;
      const salesAmount = staffOrders.reduce((sum, o) => sum + o.finalAmount, 0);
      const collectedAmount = rangePayments
        .filter((p) => p.staffId === staff.uid)
        .reduce((sum, p) => sum + p.amount, 0);

      return {
        staffId: staff.uid,
        name: staff.name,
        email: staff.email,
        role: staff.role,
        salesCount,
        salesAmount,
        collectedAmount,
      };
    });
  }, [staffMembers, rangeOrders, rangePayments]);

  // EXPORT HANDLER
  const handleExportCurrentReport = () => {
    if (selectedReport === 'profit_loss') {
      const data = [
        { Metric: 'Total Sales (Revenue)', Amount: pnlMetrics.totalSales },
        { Metric: 'Cost of Goods Sold (COGS)', Amount: pnlMetrics.totalCogs },
        { Metric: 'Gross Profit', Amount: pnlMetrics.grossProfit },
        { Metric: 'Operating Expenses', Amount: pnlMetrics.totalExpenses },
        { Metric: 'Net Profit (Earnings)', Amount: pnlMetrics.netProfit },
        { Metric: 'Net Margin (%)', Amount: `${pnlMetrics.profitMargin.toFixed(2)}%` },
      ];
      exportToCSV(data, `Profit_Loss_Report_${startDate}_to_${endDate}`);
    } else if (selectedReport === 'daily_sales') {
      exportToCSV(
        dailyOrders.map((o) => ({
          'Order #': o.orderId,
          Customer: o.customerName,
          Area: o.areaName,
          Staff: o.staffName,
          Total: billOf(o),
          Paid: o.paidAmount,
          Due: o.dueAmount,
        })),
        `Daily_Sales_${dailyDate}`
      );
    } else if (selectedReport === 'sales_summary') {
      const data = rangeOrders.map((o) => ({
        'Invoice #': o.orderId,
        Date: formatDate(o.date || o.createdAt),
        Customer: o.customerName,
        Area: o.areaName,
        Staff: o.staffName,
        Total: o.finalAmount,
        Paid: o.paidAmount,
        Due: o.dueAmount,
        Status: o.orderStatus,
      }));
      exportToCSV(data, `Sales_Report_${startDate}_to_${endDate}`);
    } else if (selectedReport === 'inventory_valuation') {
      const data = products.map((p) => ({
        SKU: p.sku,
        Name: p.name,
        Category: p.categoryName,
        Stock: p.currentStock,
        Unit: p.unit,
        'Cost Price': p.purchasePrice,
        'Sale Price': p.salePrice,
        'Cost Valuation': p.currentStock * p.purchasePrice,
        'Retail Valuation': p.currentStock * p.salePrice,
      }));
      exportToCSV(data, `Inventory_Valuation_Report_${todayStr}`);
    } else if (selectedReport === 'staff_performance') {
      const data = staffPerformance.map((s) => ({
        Staff: s.name,
        Username: userHandle({ email: s.email }),
        'Orders Count': s.salesCount,
        'Sales Volume': s.salesAmount,
        'Collections Made': s.collectedAmount,
      }));
      exportToCSV(data, `Staff_Performance_${startDate}_to_${endDate}`);
    } else if (selectedReport === 'due_summary') {
      const data = customers
        .filter((c) => (c.currentDue || 0) > 0)
        .map((c) => ({
          Customer: c.name,
          Business: c.businessName || '',
          Area: c.areaName,
          Phone: c.phone,
          Due: c.currentDue,
        }));
      exportToCSV(data, `Due_Summary_Report_${todayStr}`);
    }
  };

  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const handleDownloadPDF = async (reportType = selectedReport) => {
    setIsDownloadingPdf(true);
    try {
      if (reportType === 'profit_loss') {
        exportProfitLossPDF(pnlMetrics, settings, startDate, endDate);
        setDownloadSuccess('Financial Profit & Loss PDF সফলভাবে ডাউনলোড হয়েছে');
      } else if (reportType === 'daily_sales') {
        exportDailySalesPDF(dailyOrders, settings, dailyDate);
        setDownloadSuccess('Daily Sales PDF সফলভাবে ডাউনলোড হয়েছে');
      } else if (reportType === 'sales_summary') {
        exportSalesReportPDF(rangeOrders, settings, startDate, endDate);
        setDownloadSuccess('Sales Summary PDF সফলভাবে ডাউনলোড হয়েছে');
      } else if (reportType === 'inventory_valuation') {
        exportInventoryPDF(products, settings, inventoryMetrics);
        setDownloadSuccess('Inventory Valuation PDF সফলভাবে ডাউনলোড হয়েছে');
      } else if (reportType === 'due_summary') {
        exportDueSummaryPDF(customers, settings);
        setDownloadSuccess('Customer Due Summary PDF সফলভাবে ডাউনলোড হয়েছে');
      } else if (reportType === 'staff_performance') {
        exportStaffPerformancePDF(staffPerformance, settings, startDate, endDate);
        setDownloadSuccess('Staff Performance PDF সফলভাবে ডাউনলোড হয়েছে');
      }
      setTimeout(() => setDownloadSuccess(null), 4000);
    } catch (err: any) {
      console.error('PDF export error:', err);
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Printable Report Header */}
      <div className="hidden print:block mb-6 bg-white p-4">
        <CompanyBrandHeader settings={settings} variant="letterhead" />
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs print:hidden">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            রিপোর্ট ও ব্যবসায়িক বিশ্লেষণ (Reports & Analytics)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Profit & loss analysis, sales territory trends, inventory valuation, and field staff KPI metrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={isDownloadingPdf}
            onClick={() => handleDownloadPDF()}
            title="বর্তমান সক্রিয় রিপোর্টটি অফিসিয়াল PDF হিসেবে ডাউনলোড করুন"
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
          >
            {isDownloadingPdf ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <FileDown className="w-3.5 h-3.5" />
            )}
            {isDownloadingPdf ? 'PDF তৈরি হচ্ছে...' : 'PDF ডাউনলোড (Download PDF)'}
          </button>

          <button
            type="button"
            onClick={handleExportCurrentReport}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            প্রিন্ট রিপোর্ট
          </button>
        </div>
      </div>

      {/* Success Notification Banner */}
      {downloadSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2 shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold">{downloadSuccess}</span>
        </div>
      )}

      {/* Report Selection Tabs & Date Range */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-4 text-xs print:hidden">
        {/* Tabs */}
        <div className="flex flex-wrap items-center gap-1">
          <button
            type="button"
            onClick={() => setSelectedReport('profit_loss')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedReport === 'profit_loss'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            লাভ-ক্ষতি (Profit & Loss)
          </button>

          <button
            type="button"
            onClick={() => setSelectedReport('daily_sales')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedReport === 'daily_sales'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            দৈনিক বিক্রয় (Daily Sales)
          </button>

          <button
            type="button"
            onClick={() => setSelectedReport('sales_summary')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedReport === 'sales_summary'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            বিক্রয় রিপোর্ট (Sales Summary)
          </button>

          <button
            type="button"
            onClick={() => setSelectedReport('due_summary')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedReport === 'due_summary'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            বকেয়া বাকি (Due Summary)
          </button>

          <button
            type="button"
            onClick={() => setSelectedReport('inventory_valuation')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedReport === 'inventory_valuation'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            ইনভেন্টরি মূল্যায়ন (Stock Valuation)
          </button>

          <button
            type="button"
            onClick={() => setSelectedReport('staff_performance')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedReport === 'staff_performance'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            স্টাফ পারফরম্যান্স (Staff KPI)
          </button>
        </div>

        {/* Date Filter */}
        {selectedReport !== 'daily_sales' && (
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-400" />
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="border border-slate-200 rounded-lg px-2 py-1 text-xs"
          />
          <span className="text-slate-400">&ndash;</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="border border-slate-200 rounded-lg px-2 py-1 text-xs"
          />
        </div>
        )}
      </div>

      {/* REPORT CONTENT VIEW */}

      {/* 1. PROFIT & LOSS REPORT */}
      {selectedReport === 'profit_loss' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Gross Sales Revenue</p>
              <p className="text-2xl font-bold text-slate-900 font-mono mt-1">
                {formatCurrency(pnlMetrics.totalSales, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">{rangeOrders.length} approved invoices</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Cost of Goods Sold (COGS)</p>
              <p className="text-2xl font-bold text-amber-600 font-mono mt-1">
                {formatCurrency(pnlMetrics.totalCogs, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Direct product inventory cost</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Gross Profit (মোট লাভ)</p>
              <p className="text-2xl font-bold text-emerald-600 font-mono mt-1">
                {formatCurrency(pnlMetrics.grossProfit, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Revenue minus COGS</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Operating Expenses</p>
              <p className="text-2xl font-bold text-rose-600 font-mono mt-1">
                {formatCurrency(pnlMetrics.totalExpenses, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">{rangeExpenses.length} expense vouchers</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Net Profit (প্রকৃত লাভ)</p>
              <p
                className={`text-2xl font-bold font-mono mt-1 ${
                  pnlMetrics.netProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'
                }`}
              >
                {formatCurrency(pnlMetrics.netProfit, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">After all overhead expenses</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Net Profit Margin</p>
              <p className="text-2xl font-bold text-blue-600 font-mono mt-1">
                {pnlMetrics.profitMargin.toFixed(1)}%
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Efficiency percentage</p>
            </div>
          </div>

          {/* Breakdown Statement */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-4 border-b border-slate-200 gap-2">
              <h3 className="text-sm font-bold text-slate-900">
                লাভ-ক্ষতি বিস্তারিত বিবরণী (Profit & Loss Statement: {formatDate(startDate)} &ndash; {formatDate(endDate)})
              </h3>
              <button
                type="button"
                disabled={isDownloadingPdf}
                onClick={() => handleDownloadPDF('profit_loss')}
                className="px-3 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors w-fit disabled:opacity-50"
              >
                <FileDown className="w-3.5 h-3.5" />
                P&L PDF ডাউনলোড
              </button>
            </div>

            <div className="space-y-3 text-xs max-w-2xl">
              <div className="flex justify-between py-1 border-b border-slate-100 font-semibold">
                <span className="text-slate-800">১. মোট বিক্রয় রাজস্ব (Total Sales Revenue):</span>
                <span className="font-mono text-slate-900">{formatCurrency(pnlMetrics.totalSales, currencySymbol)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600 pl-4">
                <span>(-) বিক্রিত পণ্যের ক্রয়মূল্য (COGS):</span>
                <span className="font-mono text-rose-600">({formatCurrency(pnlMetrics.totalCogs, currencySymbol)})</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200 font-bold bg-slate-50 px-2 rounded">
                <span className="text-slate-900">২. মোট লাভ (Gross Profit):</span>
                <span className="font-mono text-emerald-700">{formatCurrency(pnlMetrics.grossProfit, currencySymbol)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600 pl-4">
                <span>(-) দৈনন্দিন ও দাপ্তরিক খরচ (Operational Expenses):</span>
                <span className="font-mono text-rose-600">({formatCurrency(pnlMetrics.totalExpenses, currencySymbol)})</span>
              </div>
              <div className="flex justify-between py-2 border-t-2 border-slate-900 font-black text-sm bg-slate-100 px-3 rounded-lg">
                <span className="text-slate-900">৩. নিট প্রকৃত লাভ (Net Profit):</span>
                <span className={`font-mono ${pnlMetrics.netProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {formatCurrency(pnlMetrics.netProfit, currencySymbol)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 0. DAILY SALES REPORT */}
      {selectedReport === 'daily_sales' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-4 flex flex-wrap items-center justify-between gap-3 print:hidden">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>তারিখ:</span>
              <input
                type="date"
                value={dailyDate}
                onChange={(e) => e.target.value && setDailyDate(e.target.value)}
                className="border border-slate-200 rounded-lg px-2 py-1 text-xs"
              />
              <button
                type="button"
                onClick={() => setDailyDate(localDay(new Date()))}
                className="px-2.5 py-1 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                আজ
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isDownloadingPdf}
                onClick={() => handleDownloadPDF('daily_sales')}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <FileDown className="w-3.5 h-3.5" />
                PDF ডাউনলোড
              </button>
              <button
                type="button"
                onClick={handlePrint}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-slate-600" />
                প্রিন্ট
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden print:border-0 print:shadow-none">
            <div className="p-4 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-sm">দৈনিক বিক্রয় রিপোর্ট</h3>
              <p className="text-xs text-slate-500 mt-0.5">তারিখ: {formatDate(dailyDate)}</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 text-xs">
              <div className="rounded-xl border border-blue-200 bg-blue-50 p-3">
                <div className="text-[10px] font-semibold text-blue-800 uppercase">মোট অর্ডার</div>
                <div className="font-bold text-blue-900 text-base mt-1">{dailyOrders.length}</div>
              </div>
              <div className="rounded-xl border border-green-200 bg-green-50 p-3">
                <div className="text-[10px] font-semibold text-green-800 uppercase">মোট বিক্রয়</div>
                <div className="font-bold text-green-900 text-base mt-1 font-mono">
                  {formatCurrency(dailyTotals.sales, currencySymbol)}
                </div>
              </div>
              <div className="rounded-xl border border-teal-200 bg-teal-50 p-3">
                <div className="text-[10px] font-semibold text-teal-800 uppercase">আদায় (Paid)</div>
                <div className="font-bold text-teal-900 text-base mt-1 font-mono">
                  {formatCurrency(dailyTotals.paid, currencySymbol)}
                </div>
              </div>
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-3">
                <div className="text-[10px] font-semibold text-rose-800 uppercase">বাকি (Due)</div>
                <div className="font-bold text-rose-900 text-base mt-1 font-mono">
                  {formatCurrency(dailyTotals.due, currencySymbol)}
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-y border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Order ID</th>
                    <th className="px-4 py-3">Customer</th>
                    <th className="px-4 py-3">Area</th>
                    <th className="px-4 py-3">Staff</th>
                    <th className="px-4 py-3 text-right">Total</th>
                    <th className="px-4 py-3 text-right">Paid</th>
                    <th className="px-4 py-3 text-right">Due</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {dailyOrders.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                        এই তারিখে কোনো অনুমোদিত বিক্রয় নেই।
                      </td>
                    </tr>
                  ) : (
                    dailyOrders.map((o) => (
                      <tr key={o.id}>
                        <td className="px-4 py-2.5 font-mono font-semibold text-slate-900">#{o.orderId}</td>
                        <td className="px-4 py-2.5 font-semibold text-slate-800">{o.customerName}</td>
                        <td className="px-4 py-2.5 text-slate-600">{o.areaName}</td>
                        <td className="px-4 py-2.5 text-slate-600">{o.staffName}</td>
                        <td className="px-4 py-2.5 text-right font-mono font-bold text-slate-900">
                          {formatCurrency(billOf(o), currencySymbol)}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono text-emerald-600">
                          {formatCurrency(o.paidAmount, currencySymbol)}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono text-rose-600">
                          {formatCurrency(o.dueAmount, currencySymbol)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {dailyProducts.length > 0 && (
              <div className="p-4 border-t border-slate-200 print-break-inside-avoid">
                <h4 className="font-bold text-slate-900 text-xs mb-2">পণ্য অনুযায়ী বিক্রয়</h4>
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-y border-slate-200">
                    <tr>
                      <th className="px-4 py-2">Product</th>
                      <th className="px-4 py-2 text-right">Qty</th>
                      <th className="px-4 py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {dailyProducts.map((r) => (
                      <tr key={r.name}>
                        <td className="px-4 py-2 font-semibold text-slate-800">{r.name}</td>
                        <td className="px-4 py-2 text-right font-mono">{r.qty}</td>
                        <td className="px-4 py-2 text-right font-mono font-bold">
                          {formatCurrency(r.amount, currencySymbol)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. SALES SUMMARY */}
      {selectedReport === 'sales_summary' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-wrap justify-between items-center text-xs font-semibold gap-2">
            <div className="flex items-center gap-3">
              <span>Orders in Period: {rangeOrders.length}</span>
              <span className="font-mono text-sm text-blue-600">
                Total: {formatCurrency(pnlMetrics.totalSales, currencySymbol)}
              </span>
            </div>
            <button
              type="button"
              disabled={isDownloadingPdf}
              onClick={() => handleDownloadPDF('sales_summary')}
              className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
            >
              <FileDown className="w-3.5 h-3.5" />
              Sales PDF ডাউনলোড
            </button>
          </div>
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Order ID</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Area</th>
                <th className="px-4 py-3">Staff</th>
                <th className="px-4 py-3 text-right">Total</th>
                <th className="px-4 py-3 text-right">Paid</th>
                <th className="px-4 py-3 text-right">Due</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rangeOrders.map((o) => (
                <tr key={o.id} className="hover:bg-slate-50/70">
                  <td className="px-4 py-2.5 font-mono font-semibold text-slate-900">#{o.orderId}</td>
                  <td className="px-4 py-2.5 text-slate-500">{formatDate(o.date || o.createdAt)}</td>
                  <td className="px-4 py-2.5 font-semibold text-slate-800">{o.customerName}</td>
                  <td className="px-4 py-2.5 text-slate-600">{o.areaName}</td>
                  <td className="px-4 py-2.5 text-slate-600">{o.staffName}</td>
                  <td className="px-4 py-2.5 text-right font-mono font-bold text-slate-900">
                    {formatCurrency(o.finalAmount, currencySymbol)}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-emerald-600">
                    {formatCurrency(o.paidAmount, currencySymbol)}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-rose-600">
                    {formatCurrency(o.dueAmount, currencySymbol)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 3. DUE SUMMARY */}
      {selectedReport === 'due_summary' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-wrap justify-between items-center text-xs font-semibold gap-2">
            <span className="text-slate-800 font-bold">
              বকেয়া কাস্টমার তালিকা ({customers.filter((c) => (c.currentDue || 0) > 0).length} জন)
            </span>
            <button
              type="button"
              disabled={isDownloadingPdf}
              onClick={() => handleDownloadPDF('due_summary')}
              className="px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
            >
              <FileDown className="w-3.5 h-3.5" />
              Due Report PDF ডাউনলোড
            </button>
          </div>
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Business</th>
                <th className="px-4 py-3">Area</th>
                <th className="px-4 py-3">Phone</th>
                <th className="px-4 py-3 text-right">Outstanding Due</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {customers
                .filter((c) => (c.currentDue || 0) > 0)
                .sort((a, b) => (b.currentDue || 0) - (a.currentDue || 0))
                .map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 font-semibold text-slate-900">{c.name}</td>
                    <td className="px-4 py-3 text-slate-600">{c.businessName || 'N/A'}</td>
                    <td className="px-4 py-3 text-slate-600">{c.areaName}</td>
                    <td className="px-4 py-3 text-slate-600">{c.phone}</td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-rose-600 text-sm">
                      {formatCurrency(c.currentDue || 0, currencySymbol)}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 4. INVENTORY VALUATION */}
      {selectedReport === 'inventory_valuation' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Total Valuation (At Cost)</p>
              <p className="text-2xl font-bold text-slate-900 font-mono mt-1">
                {formatCurrency(inventoryMetrics.totalCostValuation, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Warehouse purchase valuation</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Retail Sales Potential</p>
              <p className="text-2xl font-bold text-blue-600 font-mono mt-1">
                {formatCurrency(inventoryMetrics.totalRetailValuation, currencySymbol)}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Gross potential value</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-500">Total Units in Stock</p>
              <p className="text-2xl font-bold text-slate-900 font-mono mt-1">
                {inventoryMetrics.totalUnits}
              </p>
              <p className="text-[11px] text-amber-600 mt-1">{inventoryMetrics.lowStockCount} items at safety alert</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex flex-wrap justify-between items-center text-xs font-semibold gap-2">
              <span className="text-slate-800 font-bold">
                ক্যাটালগ পণ্য ও ইনভেন্টরি স্টক মূল্যায়ন ({products.length} Products)
              </span>
              <button
                type="button"
                disabled={isDownloadingPdf}
                onClick={() => handleDownloadPDF('inventory_valuation')}
                className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
              >
                <FileDown className="w-3.5 h-3.5" />
                Inventory PDF ডাউনলোড
              </button>
            </div>
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Product Name</th>
                  <th className="px-4 py-3">SKU</th>
                  <th className="px-4 py-3 text-center">Stock</th>
                  <th className="px-4 py-3 text-right">Cost Price</th>
                  <th className="px-4 py-3 text-right">Sale Price</th>
                  <th className="px-4 py-3 text-right">Total Cost Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-2.5 font-semibold text-slate-900">{p.name}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-500">{p.sku}</td>
                    <td className="px-4 py-2.5 text-center font-bold">
                      {p.currentStock} {p.unit}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-600">
                      {formatCurrency(p.purchasePrice, currencySymbol)}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-900">
                      {formatCurrency(p.salePrice, currencySymbol)}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono font-bold text-slate-900">
                      {formatCurrency(p.currentStock * p.purchasePrice, currencySymbol)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. STAFF PERFORMANCE */}
      {selectedReport === 'staff_performance' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-wrap justify-between items-center text-xs font-semibold gap-2">
            <span className="text-slate-800 font-bold">
              মাঠ কর্মকর্তা বিক্রয় ও আদায় পারফরম্যান্স ({staffPerformance.length} Officers)
            </span>
            <button
              type="button"
              disabled={isDownloadingPdf}
              onClick={() => handleDownloadPDF('staff_performance')}
              className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
            >
              <FileDown className="w-3.5 h-3.5" />
              Staff KPI PDF ডাউনলোড
            </button>
          </div>
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Staff Name</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3 text-center">Orders Generated</th>
                <th className="px-4 py-3 text-right">Sales Volume</th>
                <th className="px-4 py-3 text-right">Due Collections</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {staffPerformance.map((s) => (
                <tr key={s.staffId} className="hover:bg-slate-50/70">
                  <td className="px-4 py-3 font-semibold text-slate-900">
                    <div>{s.name}</div>
                    <span className="text-[10px] text-slate-400 font-normal">@{userHandle(s)}</span>
                  </td>
                  <td className="px-4 py-3 uppercase text-[10px] font-bold text-slate-600">
                    {roleLabel(s.role)}
                  </td>
                  <td className="px-4 py-3 text-center font-bold text-slate-900 font-mono">
                    {s.salesCount}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-emerald-600 text-sm">
                    {formatCurrency(s.salesAmount, currencySymbol)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-blue-600 text-sm">
                    {formatCurrency(s.collectedAmount, currencySymbol)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
