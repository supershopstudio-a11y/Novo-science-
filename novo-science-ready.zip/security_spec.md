# Security notes

* Login uses Firebase Authentication only (username + password; the username is mapped to a private e-mail-shaped id). No passwords are stored in Firestore.
* A person can use the app only if an admin created a profile for them (`users/{uid}`, status `active`).
  Anyone else who signs up through the public Firebase API is rejected by the rules.
* The first admin is created once from the login screen; the marker doc `system/bootstrap` then blocks any further self-created admin.
* Profile types: Admin (full access) and User (permission based). Users cannot change their own role, status or permissions.
* Only users with the approve permission can move an order to APPROVED; invoices, payments and audit logs are protected.
* Activity logs and stock transactions are immutable.
