# Security notes

* Login uses Firebase Authentication only (email + password, or Google). No passwords are stored in Firestore.
* A person can use the app only if an admin created a profile for them (`users/{uid}`, status `active`).
  Anyone else who signs up through the public Firebase API is rejected by the rules.
* The owner is identified by a **verified** e-mail (`rashedulkarimrm12@gmail.com`).
  Change it in two places if the owner changes: `src/services/authContext.tsx` (OWNER_EMAIL) and `firestore.rules` (isOwner).
* Admins cannot create or edit Super Admins. Staff cannot change their own role, status or permissions.
* Only users with the approve permission can move an order to APPROVED; invoices, payments and audit logs are protected.
* Activity logs and stock transactions are immutable.
