import React, { useState, useMemo } from 'react';
import {
  Boxes,
  ArrowUpRight,
  ArrowDownRight,
  RotateCcw,
  Search,
  Filter,
  AlertTriangle,
  History,
  FileSpreadsheet,
  Plus,
} from 'lucide-react';
import { Product, InventoryTransaction, UserProfile, SystemSettings, InventoryTransactionType, UserStock } from '../../types';
import { Modal } from '../common/Modal';
import { formatCurrency, formatDateTime } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { checkPermission } from '../../permissions';
import { manageStockOperation } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';

interface InventoryViewProps {
  products: Product[];
  transactions: InventoryTransaction[];
  userStocks?: UserStock[];
  staffMembers?: UserProfile[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  products = [],
  transactions = [],
  userStocks = [],
  staffMembers = [],
  currentUser,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<'current_stock' | 'user_stocks' | 'audit_log'>('current_stock');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');

  // Stock In / Out Modal
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [stockType, setStockType] = useState<InventoryTransactionType>('STOCK_IN');
  const [quantity, setQuantity] = useState<number>(10);
  const [referenceId, setReferenceId] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canManageStock = checkPermission(currentUser, 'inventory.stockIn');
  const currencySymbol = settings.currencySymbol || '৳';

  // Filtered Products
  const filteredProducts = useMemo(() => {
    let list = products;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          p.categoryName.toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => a.currentStock - b.currentStock);
  }, [products, searchQuery]);

  // Filtered Transactions
  const filteredTransactions = useMemo(() => {
    let list = transactions;

    if (typeFilter !== 'ALL') {
      list = list.filter((t) => t.type === typeFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (t) =>
          t.productName.toLowerCase().includes(q) ||
          t.sku.toLowerCase().includes(q) ||
          t.performedByName.toLowerCase().includes(q) ||
          (t.referenceId && t.referenceId.toLowerCase().includes(q))
      );
    }

    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [transactions, typeFilter, searchQuery]);

  const handleOpenStockModal = (prod?: Product) => {
    setSelectedProductId(prod ? prod.id : products[0]?.id || '');
    setStockType('STOCK_IN');
    setQuantity(10);
    setReferenceId('');
    setReason('');
    setError(null);
    setIsStockModalOpen(true);
  };

  const handleStockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) {
      setError('অনুগ্রহ করে পণ্য নির্বাচন করুন');
      return;
    }
    if (quantity <= 0) {
      setError('পরিমাণ শূন্যের বেশি হতে হবে');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await manageStockOperation({
        productId: selectedProductId,
        type: stockType,
        quantity: Number(quantity),
        reason: reason || `${stockType} via Inventory Hub`,
        referenceId,
        user: currentUser,
      });
      setIsStockModalOpen(false);
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleExportStockCSV = () => {
    const data = filteredProducts.map((p) => ({
      'Product ID': p.productId,
      Name: p.name,
      SKU: p.sku,
      Category: p.categoryName,
      'Current Stock': p.currentStock,
      'Safety Stock': p.minimumStock,
      Unit: p.unit,
      'Purchase Price': p.purchasePrice,
      'Stock Valuation': p.currentStock * p.purchasePrice,
    }));
    exportToCSV(data, 'Inventory_Stock_Report');
  };

  const handleExportAuditCSV = () => {
    const data = filteredTransactions.map((t) => ({
      'Transaction ID': t.transactionId,
      Date: formatDateTime(t.createdAt),
      Product: t.productName,
      SKU: t.sku,
      Type: t.type,
      Quantity: t.quantity,
      'Previous Stock': t.previousStock,
      'New Stock': t.newStock,
      Reference: t.referenceId || '',
      Reason: t.reason,
      'Performed By': t.performedByName,
    }));
    exportToCSV(data, 'Inventory_Audit_Log_Export');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Boxes className="w-5 h-5 text-blue-600" />
            ইনভেন্টরি স্টক ও অডিট ট্রেইল (Inventory Hub)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time warehouse inventory counts, automated sales deductions, and complete immutable transaction logs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={activeTab === 'current_stock' ? handleExportStockCSV : handleExportAuditCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>

          {canManageStock && (
            <button
              type="button"
              onClick={() => handleOpenStockModal()}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              স্টক ইন / সমন্বয় (Stock In / Adj)
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          type="button"
          onClick={() => setActiveTab('current_stock')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'current_stock'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          সেন্ট্রাল স্টক ক্যাটালগ (Central Stock)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('user_stocks')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'user_stocks'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Boxes className="w-4 h-4" />
          ইউজার ও স্টাফদের ব্যক্তিগত স্টক (User Allocated Stocks)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('audit_log')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'audit_log'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          স্টক ট্রানজ্যাকশন অডিট হিস্ট্রি (Audit Trail)
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search product, SKU, user, ref..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          {activeTab === 'audit_log' && (
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Transaction Types</option>
              <option value="STOCK_IN">Stock In</option>
              <option value="STOCK_OUT">Stock Out</option>
              <option value="SALE_DEDUCTION">Sale Deduction (বিক্রয় কর্তন)</option>
              <option value="SALE_RESTORE">Sale Restore (অর্ডার বাতিল ফেরত)</option>
              <option value="ADJUSTMENT">Adjustment (গণনা সমন্বয়)</option>
            </select>
          )}
        </div>
      </div>

      {/* TAB 1: CURRENT STOCK TABLE */}
      {activeTab === 'current_stock' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Product Name & SKU</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3 text-center">Current Stock</th>
                  <th className="px-4 py-3 text-center">Safety Alert</th>
                  <th className="px-4 py-3 text-right">Unit Cost</th>
                  <th className="px-4 py-3 text-right">Total Stock Value</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProducts.map((prod) => {
                  const isLow = prod.currentStock > 0 && prod.currentStock <= prod.minimumStock;
                  const isOut = prod.currentStock <= 0;

                  return (
                    <tr key={prod.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <div>{prod.name}</div>
                        <span className="text-[10px] text-slate-400 font-mono font-normal">
                          SKU: {prod.sku}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-slate-600">{prod.categoryName}</td>

                      <td className="px-4 py-3 text-center">
                        <span
                          className={`inline-block font-bold px-3 py-0.5 rounded-full text-xs ${
                            isOut
                              ? 'bg-rose-100 text-rose-800'
                              : isLow
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {prod.currentStock} {prod.unit}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-center text-slate-500 font-mono">
                        {prod.minimumStock} {prod.unit}
                      </td>

                      <td className="px-4 py-3 text-right font-mono text-slate-600">
                        {formatCurrency(prod.purchasePrice, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(prod.currentStock * prod.purchasePrice, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-right">
                        {canManageStock && (
                          <button
                            type="button"
                            onClick={() => handleOpenStockModal(prod)}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded text-[11px] transition-colors inline-flex items-center gap-1 cursor-pointer"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5" />
                            স্টক পরিবর্তন
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: USER ALLOCATED STOCKS */}
      {activeTab === 'user_stocks' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex justify-between items-center text-xs font-semibold">
            <span className="text-slate-800 font-bold">
              কর্মকর্তা ও ব্যবহারকারীদের ব্যক্তিগত স্টক খতিয়ান
            </span>
            <span className="text-slate-500 font-mono">
              মোট বরাদ্দ রেকর্ড: {userStocks.filter((s) => s.quantity > 0).length} টি
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">ব্যবহারকারী / কর্মকর্তা</th>
                  <th className="px-4 py-3">পণ্য নাম</th>
                  <th className="px-4 py-3">SKU</th>
                  <th className="px-4 py-3 text-center">ব্যক্তিগত স্টক</th>
                  <th className="px-4 py-3 text-right">মজুদ বাজারমূল্য</th>
                  <th className="px-4 py-3">সর্বশেষ হস্তান্তর তারিখ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {userStocks.filter((s) => s.quantity > 0).length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-slate-400">
                      কোনো কর্মকর্তার কাছে বর্তমানে ব্যক্তিগত স্টক নেই। প্রোডাক্ট রিকোয়েস্ট অনুমোদিত হলে এখানে প্রদর্শিত হবে।
                    </td>
                  </tr>
                ) : (
                  userStocks
                    .filter((s) => s.quantity > 0)
                    .map((s) => {
                      const prod = products.find((p) => p.id === s.productId);
                      const val = (prod?.salePrice || 0) * s.quantity;
                      return (
                        <tr key={s.id} className="hover:bg-slate-50/50">
                          <td className="px-4 py-3 font-semibold text-slate-900">
                            {s.userName}
                          </td>
                          <td className="px-4 py-3 font-bold text-slate-800">{s.productName}</td>
                          <td className="px-4 py-3 font-mono text-slate-500">{s.sku}</td>
                          <td className="px-4 py-3 text-center">
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold font-mono text-xs border border-emerald-200">
                              {s.quantity} {s.unit}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-slate-800">
                            {formatCurrency(val, currencySymbol)}
                          </td>
                          <td className="px-4 py-3 text-slate-500 text-[11px]">
                            {formatDateTime(s.lastUpdated)}
                          </td>
                        </tr>
                      );
                    })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT LOGS TABLE */}
      {activeTab === 'audit_log' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Date & Time</th>
                  <th className="px-4 py-3">Product & SKU</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3 text-center">Change Qty</th>
                  <th className="px-4 py-3 text-center">Stock Flow</th>
                  <th className="px-4 py-3">Reference / Reason</th>
                  <th className="px-4 py-3">Performed By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-slate-400">
                      কোনো ট্রানজ্যাকশন রেকর্ড পাওয়া যায়নি
                    </td>
                  </tr>
                ) : (
                  filteredTransactions.map((tx) => {
                    const isPositive = tx.newStock > tx.previousStock;

                    return (
                      <tr key={tx.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-4 py-3 text-slate-500 font-mono">
                          {formatDateTime(tx.createdAt)}
                        </td>

                        <td className="px-4 py-3 font-semibold text-slate-900">
                          <div>{tx.productName}</div>
                          <span className="text-[10px] text-slate-400 font-mono">{tx.sku}</span>
                        </td>

                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              tx.type === 'STOCK_IN' || tx.type === 'SALE_RESTORE'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : tx.type === 'SALE_DEDUCTION'
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}
                          >
                            {tx.type.replace('_', ' ')}
                          </span>
                        </td>

                        <td className="px-4 py-3 text-center font-mono font-bold">
                          <span className={isPositive ? 'text-emerald-600' : 'text-rose-600'}>
                            {isPositive ? `+${tx.quantity}` : `-${tx.quantity}`}
                          </span>
                        </td>

                        <td className="px-4 py-3 text-center font-mono text-slate-600">
                          <span className="text-slate-400">{tx.previousStock}</span> &rarr;{' '}
                          <span className="font-bold text-slate-900">{tx.newStock}</span>
                        </td>

                        <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                          {tx.referenceId && (
                            <span className="font-semibold text-blue-600 mr-1.5 font-mono">
                              #{tx.referenceId}
                            </span>
                          )}
                          {tx.reason}
                        </td>

                        <td className="px-4 py-3 text-slate-700 font-medium">{tx.performedByName}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STOCK IN / OUT / ADJUSTMENT MODAL */}
      {isStockModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsStockModalOpen(false)}
          title="ইনভেন্টরি স্টক সমন্বয় (Stock Management)"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setIsStockModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleStockSubmit}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                {loading ? 'প্রক্রিয়াকরণ...' : 'স্টক আপডেট নিশ্চিত করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleStockSubmit} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">পণ্য নির্বাচন করুন (Product)*</label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.sku}) &bull; Current Stock: {p.currentStock} {p.unit}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">অপারেশন টাইপ (Type)*</label>
              <select
                value={stockType}
                onChange={(e) => setStockType(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium"
              >
                <option value="STOCK_IN">Stock In (নতুন চালান গ্রহণ)</option>
                <option value="STOCK_OUT">Stock Out (ক্ষতিগ্রস্ত / নমুনা ইত্যাদি)</option>
                <option value="ADJUSTMENT">Stock Adjustment (সরাসরি গণনা সমন্বয়)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">পরিমাণ (Quantity)*</label>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold font-mono"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">রেফারেন্স নম্বর (Invoice / Challan #)</label>
              <input
                type="text"
                value={referenceId}
                onChange={(e) => setReferenceId(e.target.value)}
                placeholder="যেমন: CHAL-9901"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">কারণ বা বিবরণ (Reason)*</label>
              <textarea
                rows={2}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="স্টক পরিবর্তনের সুনির্দিষ্ট কারণ..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
