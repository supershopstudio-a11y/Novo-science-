import React, { useState, useMemo } from 'react';
import {
  Package,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  FileSpreadsheet,
  Layers,
  CheckCircle2,
  RefreshCw,
  Lock,
} from 'lucide-react';
import { Product, Category, UserProfile, SystemSettings, InventoryTransactionType } from '../../types';
import { Modal } from '../common/Modal';
import { EmptyState } from '../common/EmptyState';
import { formatCurrency, formatDateTime, getNowISO, generateId } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { checkPermission } from '../../permissions';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { logActivity, softDeleteRecord, manageStockOperation } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { syncNeoventisProducts } from '../../services/seed';

interface ProductsViewProps {
  products: Product[];
  categories: Category[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

export const ProductsView: React.FC<ProductsViewProps> = ({
  products = [],
  categories = [],
  currentUser,
  settings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW' | 'OUT' | 'IN_STOCK'>('ALL');

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  // Stock In / Adjustment inline modal
  const [stockProduct, setStockProduct] = useState<Product | null>(null);
  const [stockActionType, setStockActionType] = useState<InventoryTransactionType>('STOCK_IN');
  const [stockQuantity, setStockQuantity] = useState<number>(10);
  const [stockReason, setStockReason] = useState('');

  // Form Fields
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    categoryId: '',
    unit: 'pcs',
    purchasePrice: 0,
    salePrice: 0,
    currentStock: 0,
    minimumStock: 10,
    status: 'active' as Product['status'],
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  const canCreate = checkPermission(currentUser, 'product.create') || checkPermission(currentUser, 'ADD_PRODUCT');
  const canEdit = checkPermission(currentUser, 'product.edit');
  const canDelete = checkPermission(currentUser, 'product.delete');
  const canManageStock = checkPermission(currentUser, 'inventory.stockIn');

  const handleSyncProducts = async () => {
    setSyncLoading(true);
    setSyncMessage(null);
    try {
      const res = await syncNeoventisProducts();
      setSyncMessage(res.message || 'পণ্য তালিকা সফলভাবে সিঙ্ক হয়েছে (Tab-Oxialpha, Tab-Cur-Q, Depheat Cream, Inj-Secjoint)');
      setTimeout(() => setSyncMessage(null), 5000);
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err));
    } finally {
      setSyncLoading(false);
    }
  };

  const currencySymbol = settings.currencySymbol || '৳';

  // Category Map
  const categoryMap = useMemo(() => {
    const map: Record<string, string> = {};
    categories.forEach((c) => {
      map[c.id] = c.name;
    });
    return map;
  }, [categories]);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    let list = products;

    if (categoryFilter !== 'ALL') {
      list = list.filter((p) => p.categoryId === categoryFilter);
    }

    if (stockFilter === 'LOW') {
      list = list.filter((p) => p.currentStock > 0 && p.currentStock <= p.minimumStock);
    } else if (stockFilter === 'OUT') {
      list = list.filter((p) => p.currentStock <= 0);
    } else if (stockFilter === 'IN_STOCK') {
      list = list.filter((p) => p.currentStock > p.minimumStock);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          p.categoryName.toLowerCase().includes(q)
      );
    }

    return list.sort((a, b) => a.name.localeCompare(b.name));
  }, [products, categoryFilter, stockFilter, searchQuery]);

  const handleOpenCreate = () => {
    setFormData({
      name: '',
      sku: `SKU-${Date.now().toString().slice(-4)}`,
      categoryId: categories[0]?.id || '',
      unit: 'pcs',
      purchasePrice: 0,
      salePrice: 0,
      currentStock: 50,
      minimumStock: 10,
      status: 'active',
    });
    setError(null);
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setFormData({
      name: p.name,
      sku: p.sku,
      categoryId: p.categoryId,
      unit: p.unit,
      purchasePrice: p.purchasePrice,
      salePrice: p.salePrice,
      currentStock: p.currentStock,
      minimumStock: p.minimumStock,
      status: p.status,
    });
    setError(null);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim() || !formData.sku.trim()) {
      setError('পণ্যের নাম এবং এসকেইউ (SKU) আবশ্যক');
      return;
    }

    if (!editingProduct && !canCreate) {
      setError('নতুন পণ্য যোগ করার এক্সেস শুধুমাত্র সুপার অ্যাডমিনের কাছে রয়েছে অথবা সুপার অ্যাডমিন কর্তৃক অনুমোদিত ইউজারের জন্য সংরক্ষিত।');
      return;
    }

    setLoading(true);
    try {
      const now = getNowISO();
      const catName = categoryMap[formData.categoryId] || 'General';

      if (editingProduct) {
        const prodRef = doc(db, 'products', editingProduct.id);
        const updated: Partial<Product> = {
          name: formData.name.trim(),
          sku: formData.sku.trim().toUpperCase(),
          categoryId: formData.categoryId,
          categoryName: catName,
          unit: formData.unit,
          purchasePrice: Number(formData.purchasePrice) || 0,
          salePrice: Number(formData.salePrice) || 0,
          minimumStock: Number(formData.minimumStock) || 0,
          status: formData.status,
          updatedAt: now,
        };

        await updateDoc(prodRef, updated);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'PRODUCT_UPDATED',
          module: 'products',
          recordId: editingProduct.id,
          newData: updated,
        });

        setEditingProduct(null);
      } else {
        const prodId = generateId('PROD');
        const prodRef = doc(db, 'products', prodId);
        const newProd: Product = {
          id: prodId,
          productId: prodId,
          name: formData.name.trim(),
          sku: formData.sku.trim().toUpperCase(),
          categoryId: formData.categoryId,
          categoryName: catName,
          brand: (formData as any).brand || 'Neoventis Biotech',
          unit: formData.unit,
          purchasePrice: Number(formData.purchasePrice) || 0,
          salePrice: Number(formData.salePrice) || 0,
          currentStock: Number(formData.currentStock) || 0,
          minimumStock: Number(formData.minimumStock) || 0,
          status: formData.status,
          createdAt: now,
        };

        await setDoc(prodRef, newProd);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'PRODUCT_CREATED',
          module: 'products',
          recordId: prodId,
          newData: newProd,
        });

        setIsCreateOpen(false);
      }
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!productToDelete) return;
    setLoading(true);
    try {
      await softDeleteRecord({
        collectionName: 'products',
        recordId: productToDelete.id,
        deleteReason: deleteReason || 'Deleted by staff/admin',
        user: currentUser,
      });
      setProductToDelete(null);
      setDeleteReason('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleStockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockProduct) return;
    if (stockQuantity <= 0) {
      setError('পরিমাণ শূন্যের বেশি হতে হবে');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await manageStockOperation({
        productId: stockProduct.id,
        type: stockActionType,
        quantity: Number(stockQuantity),
        reason: stockReason || `${stockActionType} applied manually`,
        user: currentUser,
      });
      setStockProduct(null);
      setStockQuantity(10);
      setStockReason('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    const data = filteredProducts.map((p) => ({
      'Product ID': p.productId,
      Name: p.name,
      SKU: p.sku,
      Category: p.categoryName,
      Unit: p.unit,
      'Purchase Price': p.purchasePrice,
      'Sale Price': p.salePrice,
      'Current Stock': p.currentStock,
      'Minimum Stock': p.minimumStock,
      Status: p.status,
    }));
    exportToCSV(data, 'Products_Catalog_Export');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-600" />
            পণ্য ক্যাটালগ ও তালিকা (Product Catalog)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage inventory items, barcodes/SKU, purchase and sales pricing, and safety stock thresholds.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={syncLoading}
            onClick={handleSyncProducts}
            title="Neoventis Biotech এর নির্ধারিত পণ্যসমূহ (Tab-Oxialpha, Tab-Cur-Q, Depheat Cream, Inj-Secjoint) সিঙ্ক করুন"
            className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncLoading ? 'animate-spin' : ''}`} />
            {syncLoading ? 'সিঙ্ক হচ্ছে...' : 'পণ্য সিঙ্ক (Sync Products)'}
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>

          {canCreate ? (
            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              নতুন পণ্য যোগ করুন (Add Product)
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-500 bg-slate-100 rounded-lg border border-slate-200" title="নতুন পণ্য যোগ করার এক্সেস সুপার এডমিনের নিয়ন্ত্রণে">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>পণ্য যোগ এক্সেস: সুপার এডমিনের নিয়ন্ত্রণে</span>
            </div>
          )}
        </div>
      </div>

      {/* Sync Notification Banner */}
      {syncMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{syncMessage}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Total Catalog Items</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{filteredProducts.length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Low Stock Alert</p>
          <p className="text-xl font-bold text-amber-600 mt-1">
            {filteredProducts.filter((p) => p.currentStock > 0 && p.currentStock <= p.minimumStock).length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Out of Stock</p>
          <p className="text-xl font-bold text-rose-600 mt-1">
            {filteredProducts.filter((p) => p.currentStock <= 0).length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Total Stock Value (Cost)</p>
          <p className="text-xl font-bold text-slate-900 mt-1 font-mono">
            {formatCurrency(
              filteredProducts.reduce((sum, p) => sum + p.currentStock * p.purchasePrice, 0),
              currencySymbol
            )}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search product by name, SKU..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Categories (সব ক্যাটাগরি)</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={stockFilter}
            onChange={(e) => setStockFilter(e.target.value as any)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Stock Statuses</option>
            <option value="IN_STOCK">In Stock (&gt; Safety Stock)</option>
            <option value="LOW">Low Stock (&le; Safety Stock)</option>
            <option value="OUT">Out of Stock (0 units)</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Product Name & SKU</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3 text-right">Purchase Price</th>
                <th className="px-4 py-3 text-right">Sale Price</th>
                <th className="px-4 py-3 text-center">Current Stock</th>
                <th className="px-4 py-3 text-center">Safety Level</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={7}>
                    <div className="py-12 flex flex-col items-center justify-center text-center px-4">
                      <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                        <Package className="w-6 h-6" />
                      </div>
                      <h3 className="text-sm font-bold text-slate-800">কোনো পণ্য পাওয়া যায়নি</h3>
                      <p className="text-xs text-slate-500 mt-1 max-w-md">
                        ক্যাটালগে কোনো সক্রিয় পণ্য তালিকাভুক্ত নেই অথবা সার্চ ফিল্টারের সাথে মিলছে না। Neoventis Biotech এর নির্ধারিত পণ্যসমূহ অবিলম্বে সিঙ্ক করতে নিচের বাটনে চাপ দিন।
                      </p>
                      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                        <button
                          type="button"
                          disabled={syncLoading}
                          onClick={handleSyncProducts}
                          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-2 cursor-pointer transition-colors disabled:opacity-50"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${syncLoading ? 'animate-spin' : ''}`} />
                          {syncLoading ? 'সিঙ্ক হচ্ছে...' : 'Neoventis পণ্য সিঙ্ক করুন (Sync 4 Products)'}
                        </button>
                        {canCreate && (
                          <button
                            type="button"
                            onClick={handleOpenCreate}
                            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            ম্যানুয়াল পণ্য যোগ
                          </button>
                        )}
                      </div>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((prod) => {
                  const isLow = prod.currentStock > 0 && prod.currentStock <= prod.minimumStock;
                  const isOut = prod.currentStock <= 0;

                  return (
                    <tr key={prod.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <div>{prod.name}</div>
                        <span className="text-[10px] text-slate-400 font-mono font-normal">
                          SKU: {prod.sku}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-slate-600 font-medium">
                        {prod.categoryName || 'General'}
                      </td>

                      <td className="px-4 py-3 text-right font-mono text-slate-600">
                        {formatCurrency(prod.purchasePrice, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(prod.salePrice, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-center">
                        <span
                          className={`inline-flex items-center gap-1 font-bold px-2.5 py-0.5 rounded-full text-xs ${
                            isOut
                              ? 'bg-rose-100 text-rose-800'
                              : isLow
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {prod.currentStock} {prod.unit}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-center text-slate-500 font-mono">
                        &ge; {prod.minimumStock} {prod.unit}
                      </td>

                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {canManageStock && (
                            <button
                              type="button"
                              onClick={() => {
                                setStockProduct(prod);
                                setStockActionType('STOCK_IN');
                              }}
                              className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                              title="স্টক আপডেট"
                            >
                              <ArrowUpRight className="w-3.5 h-3.5" />
                              স্টক ইন
                            </button>
                          )}

                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(prod)}
                              className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-100 transition-colors"
                              title="সম্পাদনা"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}

                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => setProductToDelete(prod)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT PRODUCT MODAL */}
      {(isCreateOpen || editingProduct) && (
        <Modal
          isOpen={true}
          onClose={() => {
            setIsCreateOpen(false);
            setEditingProduct(null);
          }}
          title={editingProduct ? 'পণ্য সংশোধন (Edit Product)' : 'নতুন পণ্য নিবন্ধন (Add Product)'}
          maxWidth="lg"
          footer={
            <>
              <button
                type="button"
                onClick={() => {
                  setIsCreateOpen(false);
                  setEditingProduct(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleSaveProduct}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5"
              >
                {loading ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন (Save)'}
              </button>
            </>
          }
        >
          <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">পণ্যের নাম (Product Name)*</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="যেমন: ACI Pure Salt 1kg"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">এসকেইউ / কোড (SKU)*</label>
                <input
                  type="text"
                  required
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  placeholder="SKU-1001"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono uppercase"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">ক্যাটাগরি (Category)*</label>
                <select
                  value={formData.categoryId}
                  onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                  required
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  <option value="">-- ক্যাটাগরি সিলেক্ট করুন --</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">ক্রয় মূল্য (Purchase Price - ৳)*</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.purchasePrice}
                  onChange={(e) => setFormData({ ...formData, purchasePrice: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">বিক্রয় মূল্য (Sale Price - ৳)*</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.salePrice}
                  onChange={(e) => setFormData({ ...formData, salePrice: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono font-bold text-blue-700"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">একক (Unit)*</label>
                <select
                  value={formData.unit}
                  onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  <option value="Box (30 Tabs)">Box (30 Tabs)</option>
                  <option value="Tube (30g)">Tube (30g)</option>
                  <option value="Vial (1 Amp)">Vial (1 Amp)</option>
                  <option value="Strip (10 Tabs)">Strip (10 Tabs)</option>
                  <option value="box">Box</option>
                  <option value="pcs">Pieces (pcs)</option>
                  <option value="carton">Carton</option>
                  <option value="bottle">Bottle</option>
                </select>
              </div>

              {!editingProduct && (
                <div>
                  <label className="font-bold text-slate-700 block mb-1">প্রারম্ভিক স্টক (Initial Stock)*</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.currentStock}
                    onChange={(e) => setFormData({ ...formData, currentStock: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono font-bold"
                  />
                </div>
              )}

              <div>
                <label className="font-bold text-slate-700 block mb-1">ন্যূনতম নিরাপত্তা স্টক (Safety Alert)*</label>
                <input
                  type="number"
                  min="0"
                  value={formData.minimumStock}
                  onChange={(e) => setFormData({ ...formData, minimumStock: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>
            </div>
          </form>
        </Modal>
      )}

      {/* STOCK OPERATION MODAL */}
      {stockProduct && (
        <Modal
          isOpen={true}
          onClose={() => setStockProduct(null)}
          title={`স্টক অপারেশন: ${stockProduct.name}`}
          subtitle={`Current Stock: ${stockProduct.currentStock} ${stockProduct.unit}`}
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setStockProduct(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading || stockQuantity <= 0}
                onClick={handleStockSubmit}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                {loading ? 'প্রক্রিয়াকরণ...' : 'স্টক আপডেট সম্পন্ন করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleStockSubmit} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">অপারেশনের ধরন (Operation Type)*</label>
              <select
                value={stockActionType}
                onChange={(e) => setStockActionType(e.target.value as InventoryTransactionType)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium"
              >
                <option value="STOCK_IN">Stock In (পণ্য গ্রহণ / নতুন সরবরাহ)</option>
                <option value="STOCK_OUT">Stock Out (ক্ষতিগ্রস্ত / নমুনা / ফেরত)</option>
                <option value="ADJUSTMENT">Stock Adjustment (গণনা সমন্বয়)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                পরিমাণ (Quantity - {stockProduct.unit})*
              </label>
              <input
                type="number"
                min="1"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(Number(e.target.value))}
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold font-mono"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">কারণ বা রেফারেন্স (Reason / Ref)*</label>
              <textarea
                rows={2}
                value={stockReason}
                onChange={(e) => setStockReason(e.target.value)}
                placeholder="যেমন: চালান নং CHAL-4921 / গুদাম থেকে সমন্বয়..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}

      {/* DELETE DIALOG */}
      {productToDelete && (
        <Modal
          isOpen={true}
          onClose={() => setProductToDelete(null)}
          title="পণ্য ডিলিট নিশ্চিতকরণ (Soft Delete)"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleDeleteConfirm}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                {loading ? 'মুছে ফেলা হচ্ছে...' : 'ডিলিট করুন (Confirm Delete)'}
              </button>
            </>
          }
        >
          <div className="space-y-3 text-xs">
            <p className="text-slate-600">
              আপনি কি নিশ্চিত যে <span className="font-bold text-slate-900">{productToDelete.name}</span> কে ক্যাটালগ থেকে সরাতে চান?
            </p>
            <div>
              <label className="font-bold text-slate-700 block mb-1">ডিলিট করার কারণ*</label>
              <textarea
                rows={2}
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="কারণ লিখুন..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
