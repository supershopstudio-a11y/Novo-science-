import React, { useState, useMemo } from 'react';
import {
  GitPullRequest,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  Truck,
  Clock,
  AlertTriangle,
  FileSpreadsheet,
  Boxes,
  UserCheck,
  ShieldAlert,
  ArrowRight,
  ShieldCheck,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  ProductRequest,
  Product,
  Area,
  UserProfile,
  SystemSettings,
  UserStock,
} from '../../types';
import { Modal } from '../common/Modal';
import { StatusBadge } from '../common/Badge';
import { EmptyState } from '../common/EmptyState';
import { formatDateTime, formatDate, formatCurrency } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { createProductRequest, updateProductRequestStatus } from '../../services/dbService';
import { checkPermission, isSuperAdminUser } from '../../permissions';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';

interface ProductRequestsViewProps {
  productRequests: ProductRequest[];
  products: Product[];
  areas: Area[];
  userStocks?: UserStock[];
  staffMembers?: UserProfile[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

export const ProductRequestsView: React.FC<ProductRequestsViewProps> = ({
  productRequests = [],
  products = [],
  areas = [],
  userStocks = [],
  staffMembers = [],
  currentUser,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<'requests' | 'my_stock' | 'all_stocks'>('requests');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Create Request Modal
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [selectedAreaId, setSelectedAreaId] = useState('');
  const [quantity, setQuantity] = useState<number>(10);
  const [priority, setPriority] = useState<ProductRequest['priority']>('MEDIUM');
  const [notes, setNotes] = useState('');

  // Status Change / Approval Modal
  const [requestToUpdate, setRequestToUpdate] = useState<ProductRequest | null>(null);
  const [newStatus, setNewStatus] = useState<ProductRequest['status']>('APPROVED');
  const [adminNote, setAdminNote] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check: Does user have (Add Product) access?
  // User Prompt: "যার কাছে (Add Product) এক্সেস থাকবে সে superadmin কে প্রোডাক্ট এর জন্য রিকোয়েস্ট পাঠাবে"
  const hasAddProductAccess =
    isSuperAdminUser(currentUser) ||
    currentUser.role === 'admin' ||
    checkPermission(currentUser, 'product.view') ||
    checkPermission(currentUser, 'product.create') ||
    checkPermission(currentUser, 'ADD_PRODUCT');

  // Can approve/manage requests: Superadmin or Admin
  const canManageRequests = isSuperAdminUser(currentUser) || currentUser.role === 'admin';

  // My Personal Stock List
  const myStocks = useMemo(() => {
    return userStocks.filter((s) => s.userId === currentUser.uid && s.quantity > 0);
  }, [userStocks, currentUser.uid]);

  // Scoped Requests list
  const filteredRequests = useMemo(() => {
    let list = productRequests;

    if (currentUser.role === 'staff' && !isSuperAdminUser(currentUser)) {
      list = list.filter((r) => r.staffId === currentUser.uid);
    }

    if (statusFilter !== 'ALL') {
      list = list.filter((r) => r.status === statusFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (r) =>
          r.productName.toLowerCase().includes(q) ||
          r.requestId.toLowerCase().includes(q) ||
          r.staffName.toLowerCase().includes(q) ||
          (r.areaName && r.areaName.toLowerCase().includes(q)) ||
          (r.approvedByName && r.approvedByName.toLowerCase().includes(q))
      );
    }

    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [productRequests, statusFilter, searchQuery, currentUser]);

  const handleOpenCreate = () => {
    if (!hasAddProductAccess) {
      setError('প্রোডাক্ট রিকোয়েস্ট পাঠানোর অনুমতি আপনার নেই। অ্যাডমিনের সাথে যোগাযোগ করুন।');
      return;
    }
    setSelectedProductId(products[0]?.id || '');
    setSelectedAreaId(areas[0]?.id || '');
    setQuantity(10);
    setPriority('MEDIUM');
    setNotes('');
    setError(null);
    setIsCreateOpen(true);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasAddProductAccess) {
      setError('আপনার কাছে (Add Product) এক্সেস নেই।');
      return;
    }
    if (!selectedProductId) {
      setError('পণ্য সিলেক্ট করুন');
      return;
    }
    if (quantity <= 0) {
      setError('পরিমাণ শূন্যের বেশি হতে হবে');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const prod = products.find((p) => p.id === selectedProductId);
      const area = areas.find((a) => a.id === selectedAreaId);

      await createProductRequest(
        {
          productId: selectedProductId,
          productName: prod ? prod.name : 'Unknown',
          quantity: Number(quantity),
          unit: prod?.unit || 'pcs',
          priority,
          areaId: selectedAreaId || '',
          areaName: area ? area.name : 'সকল এলাকা',
          note: notes,
        },
        currentUser
      );

      setIsCreateOpen(false);
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleStatusSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestToUpdate) return;

    setLoading(true);
    setError(null);
    try {
      await updateProductRequestStatus(requestToUpdate.id, newStatus, adminNote, currentUser);
      setRequestToUpdate(null);
      setAdminNote('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    const data = filteredRequests.map((r) => ({
      'Request ID': r.requestId,
      Date: formatDateTime(r.createdAt),
      Product: r.productName,
      Quantity: `${r.quantity} ${r.unit || 'pcs'}`,
      Priority: r.priority,
      Staff: r.staffName,
      Area: r.areaName,
      Status: r.status,
      'Approved By': r.approvedByName || '-',
      'Deducted From': r.deductedFromUserName || '-',
      'Added To': r.addedToUserName || '-',
      Notes: r.note || '',
      'Admin Note': r.adminNote || '',
    }));
    exportToCSV(data, 'Product_Requests_Requisitions');
  };

  return (
    <div className="space-y-6">
      {/* 1. Header & Access Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <GitPullRequest className="w-5 h-5 text-blue-600" />
            পণ্য রিকুইজিশন ও স্টক হস্তান্তর (Product Requests & Stock Allocation)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            স্টাফরা অ্যাডমিনকে প্রোডাক্ট রিকোয়েস্ট পাঠান। অনুমোদনের পর অনুমোদকের সেন্ট্রাল স্টক কমবে এবং আবেদনকারীর স্টকে যোগ হবে।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>

          {hasAddProductAccess ? (
            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              সুপারএডমিনকে রিকোয়েস্ট পাঠান
            </button>
          ) : (
            <div
              title="রিকোয়েস্ট পাঠাতে সুপার এডমিনের কাছ থেকে 'Add Product' এক্সেস নিন"
              className="px-3 py-1.5 text-xs font-medium text-slate-400 bg-slate-100 border border-slate-200 rounded-lg flex items-center gap-1.5 cursor-not-allowed"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
              Add Product এক্সেস প্রয়োজন
            </div>
          )}
        </div>
      </div>

      {/* Access Status Banner */}
      {hasAddProductAccess ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs text-emerald-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>(Add Product) এক্সেস সক্রিয়:</strong> আপনার কাছে নতুন পণ্য যোগের অনুমোদন রয়েছে। আপনি সুপারএডমিনের কাছে প্রয়োজনীয় পণ্যের রিকুইজিশন পাঠাতে পারেন।
            </span>
          </div>
          <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
            Eligible Requester
          </span>
        </div>
      ) : (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs text-amber-800">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>এক্সেস সীমাবদ্ধতা:</strong> শুধুমাত্র যাদের কাছে <strong>(Add Product)</strong> এক্সেস থাকবে তারা সুপারএডমিনকে প্রোডাক্টের জন্য রিকোয়েস্ট পাঠাতে পারবেন। আপনার এক্সেস প্রয়োজন হলে সুপারএডমিনের সাথে যোগাযোগ করুন।
            </span>
          </div>
          <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold text-[11px]">
            No Add-Product Access
          </span>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-200 gap-1 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('requests')}
          className={`px-4 py-2.5 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'requests'
              ? 'border-blue-600 text-blue-600 bg-blue-50/40 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <GitPullRequest className="w-4 h-4" />
          রিকুইজিশন অনুরোধ তালিকা ({filteredRequests.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('my_stock')}
          className={`px-4 py-2.5 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'my_stock'
              ? 'border-blue-600 text-blue-600 bg-blue-50/40 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Boxes className="w-4 h-4" />
          আমার ব্যক্তিগত স্টক ({myStocks.length} টি পণ্য)
        </button>

        {canManageRequests && (
          <button
            type="button"
            onClick={() => setActiveTab('all_stocks')}
            className={`px-4 py-2.5 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'all_stocks'
                ? 'border-blue-600 text-blue-600 bg-blue-50/40 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            সকল কর্মকর্তার স্টক বিবরণ (All User Stocks)
          </button>
        )}
      </div>

      {/* TAB 1: PRODUCT REQUESTS LIST */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-3 grow">
              <div className="relative min-w-[240px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="রিকোয়েস্ট আইডি, পণ্য, কর্মকর্তা খুঁজুন..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
              >
                <option value="ALL">সকল স্ট্যাটাস (All)</option>
                <option value="PENDING">Pending (অপেক্ষমাণ)</option>
                <option value="APPROVED">Approved (অনুমোদিত ও স্টক যুক্ত)</option>
                <option value="DELIVERED">Delivered (সরবরাহ সম্পন্ন)</option>
                <option value="REJECTED">Rejected (প্রত্যাখ্যাত)</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">রিকোয়েস্ট আইডি</th>
                    <th className="px-4 py-3">পণ্যের বিবরণ</th>
                    <th className="px-4 py-3 text-center">পরিমাণ</th>
                    <th className="px-4 py-3 text-center">অগ্রাধিকার</th>
                    <th className="px-4 py-3">আবেদনকারী কর্মকর্তা</th>
                    <th className="px-4 py-3">স্টক হস্তান্তর অডিট (Stock Transfer)</th>
                    <th className="px-4 py-3">তারিখ</th>
                    <th className="px-4 py-3 text-center">স্ট্যাটাস</th>
                    <th className="px-4 py-3 text-right">পদক্ষেপ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRequests.length === 0 ? (
                    <tr>
                      <td colSpan={9}>
                        <EmptyState
                          title="কোনো রিকুইজিশন অনুরোধ পাওয়া যায়নি"
                          description="বর্তমান ফিল্টারে কোনো প্রোডাক্ট রিকোয়েস্ট নেই।"
                          actionText={hasAddProductAccess ? "সুপারএডমিনকে নতুন রিকুইজিশন পাঠান" : undefined}
                          onAction={hasAddProductAccess ? handleOpenCreate : undefined}
                        />
                      </td>
                    </tr>
                  ) : (
                    filteredRequests.map((req) => (
                      <tr key={req.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="px-4 py-3 font-mono font-bold text-blue-600">
                          #{req.requestId}
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-bold text-slate-800">{req.productName}</div>
                          {req.note && (
                            <div className="text-[11px] text-slate-500 italic mt-0.5 line-clamp-1">
                              &ldquo;{req.note}&rdquo;
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-center font-bold text-slate-800 font-mono">
                          {req.quantity} {req.unit || 'pcs'}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              req.priority === 'URGENT'
                                ? 'bg-rose-100 text-rose-700'
                                : req.priority === 'HIGH'
                                ? 'bg-amber-100 text-amber-700'
                                : req.priority === 'MEDIUM'
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {req.priority}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-800">{req.staffName}</div>
                          <div className="text-[11px] text-slate-500">{req.areaName || 'সকল এলাকা'}</div>
                        </td>
                        <td className="px-4 py-3">
                          {req.status === 'APPROVED' || req.status === 'DELIVERED' ? (
                            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-1.5 text-[11px] text-emerald-800 space-y-0.5">
                              <div className="flex items-center gap-1 font-semibold text-emerald-900">
                                <span>অনুমোদক: {req.approvedByName || req.deductedFromUserName || 'সুপারএডমিন'}</span>
                                <ArrowRight className="w-3 h-3 text-emerald-600" />
                                <span>{req.addedToUserName || req.staffName}</span>
                              </div>
                              <div className="text-[10px] text-emerald-700">
                                ✓ অনুমোদকের সেন্ট্রাল স্টক কর্তন &bull; ইউজারের স্টকে যোগ হয়েছে
                              </div>
                              {req.adminNote && (
                                <div className="text-[10px] text-slate-600 italic">
                                  নোট: {req.adminNote}
                                </div>
                              )}
                            </div>
                          ) : req.status === 'REJECTED' ? (
                            <span className="text-[11px] text-rose-600 italic">
                              স্টক হস্তান্তর বাতিল {req.adminNote ? `(${req.adminNote})` : ''}
                            </span>
                          ) : (
                            <span className="text-[11px] text-amber-600 font-medium">
                              অপেক্ষমাণ (অনুমোদনের পর স্টক হস্তান্তর হবে)
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-slate-500 text-[11px]">
                          {formatDateTime(req.createdAt)}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <StatusBadge status={req.status} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          {canManageRequests && req.status === 'PENDING' && (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setRequestToUpdate(req);
                                  setNewStatus('APPROVED');
                                }}
                                className="px-2.5 py-1 bg-emerald-600 text-white hover:bg-emerald-700 font-semibold rounded text-[11px] transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                অনুমোদন করুন
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setRequestToUpdate(req);
                                  setNewStatus('REJECTED');
                                }}
                                className="px-2 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 font-semibold rounded text-[11px] transition-colors border border-rose-200 cursor-pointer"
                              >
                                প্রত্যাখ্যান
                              </button>
                            </div>
                          )}

                          {canManageRequests && req.status === 'APPROVED' && (
                            <button
                              type="button"
                              onClick={() => {
                                setRequestToUpdate(req);
                                setNewStatus('DELIVERED');
                              }}
                              className="px-2.5 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold rounded text-[11px] transition-colors border border-blue-200 flex items-center gap-1 ml-auto cursor-pointer"
                            >
                              <Truck className="w-3 h-3" />
                              ডেলিভারি সম্পন্ন
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MY USER STOCK (ব্যক্তিগত মজুদ) */}
      {activeTab === 'my_stock' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Boxes className="w-5 h-5 text-emerald-600" />
                  আমার বর্তমান স্টক ভাণ্ডার ({currentUser.name})
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  সুপারএডমিন কর্তৃক অনুমোদিত হয়ে আপনার ব্যক্তিগত স্টকে যুক্ত থাকা পণ্যসমূহ।
                </p>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500">মোট মজুদ একক:</div>
                <div className="text-lg font-bold text-blue-600 font-mono">
                  {myStocks.reduce((sum, s) => sum + (s.quantity || 0), 0)} Units
                </div>
              </div>
            </div>

            {myStocks.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <Boxes className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                <p className="font-semibold text-slate-600">আপনার ব্যক্তিগত স্টকে বর্তমানে কোনো পণ্য জমা নেই</p>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  সুপারএডমিনের কাছে প্রোডাক্ট রিকোয়েস্ট পাঠান। সুপারএডমিন রিকোয়েস্ট এপ্রুভ করলেই আপনার স্টকে পণ্য জমা হবে।
                </p>
                {hasAddProductAccess && (
                  <button
                    type="button"
                    onClick={handleOpenCreate}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-lg hover:bg-blue-700"
                  >
                    সুপারএডমিনকে প্রোডাক্ট রিকোয়েস্ট পাঠান
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
                {myStocks.map((stock) => {
                  const prod = products.find((p) => p.id === stock.productId);
                  return (
                    <div
                      key={stock.id}
                      className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="font-bold text-slate-800 text-sm">{stock.productName}</div>
                          <div className="text-[11px] font-mono text-slate-500">{stock.sku}</div>
                        </div>
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold font-mono text-sm rounded-lg">
                          {stock.quantity} {stock.unit}
                        </span>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500">
                        <span>একক মূল্য: {formatCurrency(prod?.salePrice || 0, settings.currencySymbol)}</span>
                        <span>
                          মোট মূল্য: {formatCurrency((prod?.salePrice || 0) * stock.quantity, settings.currencySymbol)}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1">
                        সর্বশেষ আপডেট: {formatDateTime(stock.lastUpdated)}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: ALL USER STOCKS (ADMIN VIEW) */}
      {activeTab === 'all_stocks' && canManageRequests && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex justify-between items-center text-xs font-semibold">
            <span className="text-slate-800 font-bold">
              কর্মকর্তা ও স্টাফদের ব্যক্তিগত স্টক অডিট (All User Stocks)
            </span>
            <span className="text-slate-500 font-mono">
              মোট রেকর্ড: {userStocks.filter((s) => s.quantity > 0).length} টি
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">কর্মকর্তার নাম</th>
                  <th className="px-4 py-3">পণ্য</th>
                  <th className="px-4 py-3">SKU</th>
                  <th className="px-4 py-3 text-center">ব্যক্তিগত স্টক পরিমাণ</th>
                  <th className="px-4 py-3 text-right">মজুদ বাজারমূল্য</th>
                  <th className="px-4 py-3">সর্বশেষ হালনাগাদ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {userStocks.filter((s) => s.quantity > 0).length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-slate-400">
                      কোনো কর্মকর্তার কাছে বর্তমানে কোনো সক্রিয় স্টক মজুদ নেই।
                    </td>
                  </tr>
                ) : (
                  userStocks
                    .filter((s) => s.quantity > 0)
                    .map((s) => {
                      const prod = products.find((p) => p.id === s.productId);
                      const val = (prod?.salePrice || 0) * s.quantity;
                      return (
                        <tr key={s.id} className="hover:bg-slate-50/50">
                          <td className="px-4 py-3 font-semibold text-slate-800">
                            {s.userName}
                          </td>
                          <td className="px-4 py-3 font-bold text-slate-900">{s.productName}</td>
                          <td className="px-4 py-3 font-mono text-slate-500">{s.sku}</td>
                          <td className="px-4 py-3 text-center">
                            <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold font-mono text-xs">
                              {s.quantity} {s.unit}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-slate-800">
                            {formatCurrency(val, settings.currencySymbol)}
                          </td>
                          <td className="px-4 py-3 text-slate-500 text-[11px]">
                            {formatDateTime(s.lastUpdated)}
                          </td>
                        </tr>
                      );
                    })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CREATE REQUEST MODAL */}
      {isCreateOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsCreateOpen(false)}
          title="সুপারএডমিনকে প্রোডাক্ট রিকোয়েস্ট পাঠান"
          subtitle="শুধুমাত্র (Add Product) এক্সেসধারী ব্যবহারকারীদের জন্য"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setIsCreateOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleCreateSubmit}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5"
              >
                {loading ? 'জমা দেওয়া হচ্ছে...' : 'সুপারএডমিনকে রিকোয়েস্ট জমা দিন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-slate-700 text-[11px] leading-relaxed">
              <span className="font-bold text-blue-900 block mb-0.5">নিয়মাবলী:</span>
              আপনি সুপারএডমিনের কাছে স্টকের আবেদন পাঠাচ্ছেন। সুপারএডমিন এই রিকোয়েস্টটি অনুমোদন করলে সুপারএডমিনের সেন্ট্রাল স্টক থেকে পণ্য কর্তন হবে এবং সরাসরি আপনার ব্যক্তিগত স্টকে যুক্ত হবে।
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">পণ্য নির্বাচন (Product)*</label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.sku}) &bull; সেন্ট্রাল স্টক: {p.currentStock} {p.unit}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">এলাকা / টেরিটরি (Territory)*</label>
              <select
                value={selectedAreaId}
                onChange={(e) => setSelectedAreaId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
              >
                <option value="">-- সকল এলাকা / নির্ধারিত টেরিটরি --</option>
                {areas.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name} ({a.division || 'Territory'})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">পরিমাণ (Quantity)*</label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">অগ্রাধিকার (Priority)*</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium"
                >
                  <option value="LOW">Low (সাধারণ)</option>
                  <option value="MEDIUM">Medium (প্রয়োজনীয়)</option>
                  <option value="HIGH">High (জরুরি)</option>
                  <option value="URGENT">Urgent (অতি জরুরি)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">নোট / চাহিদা বিবরণ (Optional)</label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="যেমন: ফিল্ডে নতুন ক্যাম্পেইনের জন্য তাৎক্ষণিক প্রয়োজন..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}

      {/* UPDATE STATUS & APPROVAL MODAL (SUPER ADMIN / ADMIN) */}
      {requestToUpdate && (
        <Modal
          isOpen={true}
          onClose={() => setRequestToUpdate(null)}
          title={`রিকুইজিশন অনুমোদন ও স্টক হস্তান্তর: #${requestToUpdate.requestId}`}
          subtitle={`আবেদনকারী: ${requestToUpdate.staffName} &bull; পণ্য: ${requestToUpdate.productName}`}
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setRequestToUpdate(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleStatusSubmit}
                className={`px-5 py-2 text-xs font-semibold text-white rounded-lg cursor-pointer flex items-center gap-1.5 ${
                  newStatus === 'APPROVED'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : newStatus === 'REJECTED'
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {loading
                  ? 'প্রক্রিয়াকরণ হচ্ছে...'
                  : newStatus === 'APPROVED'
                  ? 'অনুমোদন ও স্টক হস্তান্তর নিশ্চিত করুন'
                  : 'স্ট্যাটাস আপডেট করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleStatusSubmit} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">পদক্ষেপ নির্বাচন করুন*</label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium"
              >
                <option value="APPROVED">অনুমোদন করুন (Approve & Transfer Stock)</option>
                <option value="REJECTED">প্রত্যাখ্যান করুন (Reject Request)</option>
                <option value="DELIVERED">সরবরাহ সম্পন্ন (Mark as Delivered)</option>
              </select>
            </div>

            {newStatus === 'APPROVED' && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-slate-700 space-y-2">
                <div className="font-bold text-emerald-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  স্টক সমন্বয় ও স্বয়ংক্রিয় স্থানান্তর নীতি:
                </div>
                <div className="text-[11px] space-y-1">
                  <div className="flex items-start gap-1.5 text-rose-700">
                    <span className="font-bold text-sm leading-none">&minus;</span>
                    <span>
                      অনুমোদক (<strong>{currentUser.name}</strong>) এর সেন্ট্রাল স্টক থেকে <strong>{requestToUpdate.quantity} {requestToUpdate.unit || 'টি'}</strong> {requestToUpdate.productName} কর্তন হবে।
                    </span>
                  </div>
                  <div className="flex items-start gap-1.5 text-emerald-700">
                    <span className="font-bold text-sm leading-none">&#43;</span>
                    <span>
                      আবেদনকারী ব্যবহারকারী (<strong>{requestToUpdate.staffName}</strong>) এর ব্যক্তিগত স্টকে <strong>{requestToUpdate.quantity} {requestToUpdate.unit || 'টি'}</strong> যোগ হবে।
                    </span>
                  </div>
                </div>
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">মন্তব্য বা দিকনির্দেশনা (Admin Note)</label>
              <textarea
                rows={3}
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="চালান সংক্রান্ত মন্তব্য বা প্রেরণের নির্দেশ..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
