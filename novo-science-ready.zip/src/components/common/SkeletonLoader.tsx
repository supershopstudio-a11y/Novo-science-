import React from 'react';

export const TableSkeleton: React.FC<{ rows?: number; columns?: number }> = ({
  rows = 5,
  columns = 6,
}) => {
  return (
    <div className="w-full bg-white rounded-xl border border-slate-200 overflow-hidden animate-pulse">
      <div className="h-11 bg-slate-100 border-b border-slate-200 flex items-center px-4 gap-4">
        {Array.from({ length: columns }).map((_, i) => (
          <div key={i} className="h-4 bg-slate-200 rounded-sm grow" />
        ))}
      </div>
      <div className="divide-y divide-slate-100">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="h-14 px-4 flex items-center gap-4">
            {Array.from({ length: columns }).map((_, c) => (
              <div
                key={c}
                className="h-4 bg-slate-100 rounded-sm"
                style={{ width: `${Math.floor(40 + Math.random() * 50)}%` }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export const CardSkeleton: React.FC<{ count?: number }> = ({ count = 4 }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white p-5 rounded-xl border border-slate-200 animate-pulse space-y-3">
          <div className="flex justify-between">
            <div className="h-3.5 bg-slate-200 rounded-sm w-24" />
            <div className="w-8 h-8 bg-slate-200 rounded-lg" />
          </div>
          <div className="h-7 bg-slate-200 rounded-sm w-32" />
          <div className="h-3 bg-slate-100 rounded-sm w-16" />
        </div>
      ))}
    </div>
  );
};
