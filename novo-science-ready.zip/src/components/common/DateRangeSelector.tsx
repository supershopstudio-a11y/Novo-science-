import React from 'react';
import { Calendar } from 'lucide-react';
import { DateFilterType, DateRange } from '../../utils/formatters';

interface DateRangeSelectorProps {
  filterType: DateFilterType;
  onFilterChange: (type: DateFilterType) => void;
  customRange?: DateRange;
  onCustomRangeChange?: (range: DateRange) => void;
}

export const DateRangeSelector: React.FC<DateRangeSelectorProps> = ({
  filterType,
  onFilterChange,
  customRange,
  onCustomRangeChange,
}) => {
  const options: { label: string; value: DateFilterType }[] = [
    { label: 'All Time', value: 'all' },
    { label: 'Today', value: 'today' },
    { label: 'Yesterday', value: 'yesterday' },
    { label: 'This Week', value: 'this_week' },
    { label: 'This Month', value: 'this_month' },
    { label: 'Last Month', value: 'last_month' },
    { label: 'This Year', value: 'this_year' },
    { label: 'Custom Range', value: 'custom' },
  ];

  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1 shadow-2xs">
        <Calendar className="w-4 h-4 text-slate-400 ml-2 mr-1" />
        <select
          value={filterType}
          onChange={(e) => onFilterChange(e.target.value as DateFilterType)}
          className="text-xs font-semibold text-slate-700 bg-transparent border-0 focus:ring-0 focus:outline-hidden pr-6 py-1 cursor-pointer"
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {filterType === 'custom' && onCustomRangeChange && (
        <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs">
          <input
            type="date"
            value={customRange?.startDate || ''}
            onChange={(e) =>
              onCustomRangeChange({
                ...customRange,
                startDate: e.target.value,
              })
            }
            className="text-xs font-medium text-slate-700 border-0 focus:ring-0 p-0"
          />
          <span className="text-slate-400">to</span>
          <input
            type="date"
            value={customRange?.endDate || ''}
            onChange={(e) =>
              onCustomRangeChange({
                ...customRange,
                endDate: e.target.value,
              })
            }
            className="text-xs font-medium text-slate-700 border-0 focus:ring-0 p-0"
          />
        </div>
      )}
    </div>
  );
};
