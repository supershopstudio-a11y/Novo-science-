import React from 'react';

export type BadgeVariant =
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'neutral'
  | 'purple'
  | 'emerald'
  | 'amber';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  dot = false,
}) => {
  const variantStyles: Record<BadgeVariant, { bg: string; text: string; dot: string }> = {
    success: { bg: 'bg-green-100 text-green-700 border-green-200/60', text: 'text-green-700', dot: 'bg-green-500' },
    emerald: { bg: 'bg-emerald-100 text-emerald-700 border-emerald-200/60', text: 'text-emerald-700', dot: 'bg-emerald-500' },
    warning: { bg: 'bg-amber-100 text-amber-700 border-amber-200/60', text: 'text-amber-700', dot: 'bg-amber-500' },
    amber: { bg: 'bg-amber-100 text-amber-700 border-amber-200/60', text: 'text-amber-700', dot: 'bg-amber-500' },
    danger: { bg: 'bg-red-100 text-red-700 border-red-200/60', text: 'text-red-700', dot: 'bg-red-500' },
    info: { bg: 'bg-blue-100 text-blue-700 border-blue-200/60', text: 'text-blue-700', dot: 'bg-blue-500' },
    purple: { bg: 'bg-indigo-100 text-indigo-700 border-indigo-200/60', text: 'text-indigo-700', dot: 'bg-indigo-500' },
    neutral: { bg: 'bg-slate-100 text-slate-700 border-slate-200/60', text: 'text-slate-700', dot: 'bg-slate-400' },
  };

  const current = variantStyles[variant] || variantStyles.neutral;
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-0.5 text-[11px]';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-bold rounded ${current.bg} ${sizeClasses} tracking-tight whitespace-nowrap`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${current.dot}`} />}
      {children}
    </span>
  );
};

export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const norm = (status || '').toUpperCase();

  switch (norm) {
    case 'APPROVED':
    case 'PAID':
    case 'ACTIVE':
    case 'IN_STOCK':
    case 'IN STOCK':
    case 'DELIVERED':
      return <Badge variant="success" dot>{norm}</Badge>;

    case 'PENDING':
    case 'PARTIAL':
    case 'LOW_STOCK':
    case 'LOW STOCK':
    case 'MEDIUM':
      return <Badge variant="warning" dot>{norm}</Badge>;

    case 'REJECTED':
    case 'CANCELLED':
    case 'BLOCKED':
    case 'OUT_OF_STOCK':
    case 'OUT OF STOCK':
    case 'URGENT':
    case 'HIGH':
    case 'OVERDUE':
      return <Badge variant="danger" dot>{norm}</Badge>;

    case 'CASH':
      return <Badge variant="purple" dot>{norm}</Badge>;

    case 'DUE':
    case 'SUSPENDED':
      return <Badge variant="warning" dot>{norm}</Badge>;

    default:
      return <Badge variant="neutral">{norm || 'UNKNOWN'}</Badge>;
  }
};
