import React from 'react';
import { Phone, MapPin, Globe, PhoneCall } from 'lucide-react';
import { SystemSettings } from '../../types';

interface CompanyBrandHeaderProps {
  settings?: Partial<SystemSettings>;
  variant?: 'letterhead' | 'compact' | 'login';
  className?: string;
}

/**
 * Reusable official brand header component representing Neoventis Biotech Nutraceuticals
 * and Novo Science International Ltd.
 */
export const CompanyBrandHeader: React.FC<CompanyBrandHeaderProps> = ({
  settings,
  variant = 'letterhead',
  className = '',
}) => {
  const companyName = settings?.companyName || 'NEOVENTIS BIOTECH';
  const tagline = settings?.tagline || 'NUTRACEUTICALS';
  const partnerName = settings?.partnerName || 'Novo Science International Ltd.';
  const partnerTagline = settings?.partnerTagline || 'Marketing & Distribution Partner';
  const hotline = settings?.phone || settings?.companyPhone || '+880 1511-812080';
  const telephone = settings?.telephone || '+88-02-9696576';
  const headOffice =
    settings?.headOfficeAddress ||
    settings?.address ||
    settings?.companyAddress ||
    'Neoventis House, 98/4/A, Jafrabad (Pulper, Shankar), Mohammadpur, Dhaka 1207.';
  const regionalOffice =
    settings?.regionalOfficeAddress || 'Holding # 101, Uttar Chartna, Cumilla-3500.';
  const website = settings?.website || 'www.biotech.neoventisgrp.com';

  // SVG representation of the NB Neoventis Biotech logo
  const NbLogoSvg = ({ className: svgClass = 'w-16 h-12' }: { className?: string }) => (
    <svg viewBox="0 0 160 110" className={svgClass} fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* 'N' Left Stem & Diagonal */}
      <path
        d="M20 15 H48 V52 L78 15 H106 V95 H78 V58 L48 95 H20 V15 Z"
        fill="#111827"
      />
      {/* 'B' Right Structure in Orange with dynamic cutout */}
      <path
        d="M74 15 H118 C136 15 148 24 148 38 C148 48 140 54 130 57 C143 60 152 68 152 80 C152 95 138 95 118 95 H74 V72 H114 C122 72 128 71 128 65 C128 59 121 58 114 58 H88 V46 H114 C120 46 125 45 125 39 C125 33 119 32 112 32 H74 V15 Z"
        fill="#F97316"
      />
      {/* Dynamic white sweep across NB */}
      <path
        d="M35 88 C70 65 110 40 150 25 C145 28 105 52 45 94 Z"
        fill="#FFFFFF"
      />
      {/* Swoosh Orange Arc */}
      <path
        d="M32 90 C68 66 112 40 152 24 C140 34 85 68 40 94 Z"
        fill="#EA580C"
      />
    </svg>
  );

  // SVG representation of Novo Science International Ltd. emblem
  const NovoScienceLogo = ({ className: svgClass = 'w-8 h-8' }: { className?: string }) => (
    <svg viewBox="0 0 100 100" className={svgClass} fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Left dark shape */}
      <path
        d="M18 18 H44 V46 L62 20 H88 L58 54 L88 84 H60 L44 62 V84 H18 V18 Z"
        fill="#1E293B"
      />
      {/* Red swirl ribbon & dot */}
      <path
        d="M48 24 C58 24 68 34 68 46 C68 56 60 66 48 74 C42 66 44 52 48 44 C50 40 52 32 48 24 Z"
        fill="#DC2626"
      />
      <circle cx="76" cy="30" r="7" fill="#DC2626" />
    </svg>
  );

  // Compact variant (Sidebar / Header / Small cards)
  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-2.5 ${className}`}>
        <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 shadow-2xs flex items-center justify-center p-1 shrink-0">
          <NbLogoSvg className="w-full h-full" />
        </div>
        <div className="flex flex-col min-w-0">
          <span className="text-xs font-black tracking-tight text-slate-900 truncate">
            {companyName}
          </span>
          <span className="text-[9px] font-bold text-orange-600 tracking-wider uppercase">
            {tagline}
          </span>
        </div>
      </div>
    );
  }

  // Login variant
  if (variant === 'login') {
    return (
      <div className={`text-center space-y-3 ${className}`}>
        <div className="flex justify-center items-center">
          <div className="bg-white p-3 rounded-2xl shadow-md border border-slate-100 flex items-center justify-center">
            <NbLogoSvg className="w-20 h-14" />
          </div>
        </div>
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            {companyName}
          </h1>
          <p className="text-[11px] font-extrabold tracking-[0.25em] text-orange-600 uppercase mt-0.5">
            {tagline}
          </p>
        </div>
        <div className="pt-2 border-t border-slate-100 flex items-center justify-center gap-2 text-left">
          <NovoScienceLogo className="w-6 h-6 shrink-0" />
          <div>
            <p className="text-[11px] font-bold text-slate-800 leading-tight">
              {partnerName}
            </p>
            <p className="text-[9px] text-slate-500 font-medium">
              {partnerTagline}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Full Letterhead variant (Invoices, Challans, Reports)
  return (
    <div
      className={`grid grid-cols-1 md:grid-cols-12 gap-6 items-center border-b-2 border-slate-900 pb-6 print:pb-4 ${className}`}
    >
      {/* Left side: Brand identity & Partner */}
      <div className="md:col-span-6 space-y-4">
        {/* Main Logo & Brand */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-3">
            <div className="p-1 rounded-lg">
              <NbLogoSvg className="w-20 h-14" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-orange-600 tracking-tight uppercase leading-none">
                {companyName}
              </h1>
              <p className="text-[11px] sm:text-xs font-black tracking-[0.3em] text-slate-900 uppercase mt-1">
                {tagline}
              </p>
            </div>
          </div>
        </div>

        {/* Distribution Partner Section */}
        <div className="flex items-center gap-2.5 pt-2 border-t border-slate-200">
          <NovoScienceLogo className="w-9 h-9 shrink-0" />
          <div className="text-left">
            <h2 className="text-sm font-extrabold text-slate-900 leading-tight">
              {partnerName}
            </h2>
            <p className="text-[10px] font-semibold text-slate-600">
              {partnerTagline}
            </p>
          </div>
        </div>
      </div>

      {/* Vertical divider on desktop */}
      <div className="hidden md:block md:col-span-1 flex justify-center">
        <div className="w-[1.5px] h-full min-h-[120px] bg-slate-300 mx-auto" />
      </div>

      {/* Right side: Contact Details & Addresses */}
      <div className="md:col-span-5 space-y-2.5 text-xs text-slate-700">
        {/* Phone / Mobile */}
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-900 text-white flex items-center justify-center shrink-0 shadow-2xs">
            <Phone className="w-3.5 h-3.5" />
          </div>
          <span className="font-semibold text-slate-900">{hotline}</span>
        </div>

        {/* Telephone */}
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-900 text-white flex items-center justify-center shrink-0 shadow-2xs">
            <PhoneCall className="w-3.5 h-3.5" />
          </div>
          <span className="font-semibold text-slate-900">{telephone}</span>
        </div>

        {/* Head Office */}
        <div className="flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-900 text-white flex items-center justify-center shrink-0 shadow-2xs mt-0.5">
            <MapPin className="w-3.5 h-3.5" />
          </div>
          <div className="leading-snug">
            <span className="font-bold text-slate-900 block">Head Office:</span>
            <span className="text-[11px] text-slate-600">{headOffice}</span>
          </div>
        </div>

        {/* Regional Office */}
        <div className="flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-900 text-white flex items-center justify-center shrink-0 shadow-2xs mt-0.5">
            <MapPin className="w-3.5 h-3.5" />
          </div>
          <div className="leading-snug">
            <span className="font-bold text-slate-900 block">Regional Office:</span>
            <span className="text-[11px] text-slate-600">{regionalOffice}</span>
          </div>
        </div>

        {/* Website */}
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-900 text-white flex items-center justify-center shrink-0 shadow-2xs">
            <Globe className="w-3.5 h-3.5" />
          </div>
          <a
            href={`https://${website.replace(/^https?:\/\//, '')}`}
            target="_blank"
            rel="noreferrer"
            className="font-semibold text-indigo-700 hover:underline text-[11px]"
          >
            {website}
          </a>
        </div>
      </div>
    </div>
  );
};
