import React, { useState, useMemo } from 'react';
import {
  UserCheck,
  Plus,
  Search,
  Shield,
  Edit2,
  Trash2,
  Lock,
  MapPin,
  CheckCircle2,
  XCircle,
  AlertCircle,
  AlertTriangle,
  Crown,
  CheckSquare,
  Key,
  Eye,
  EyeOff,
} from 'lucide-react';
import { UserProfile, Area, SystemSettings, Role } from '../../types';
import { Modal } from '../common/Modal';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { doc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { logActivity } from '../../services/dbService';
import { createStaffLogin } from '../../services/staffAccounts';
import { normalizeUsername, usernameToEmail, validateUsername, userHandle, roleLabel, isAdminRole } from '../../services/username';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { getNowISO } from '../../utils/formatters';
import { isSuperAdminUser, SUPER_ADMIN_PERMISSIONS } from '../../permissions';

interface StaffManagementViewProps {
  staffMembers: UserProfile[];
  areas: Area[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

export const PERMISSION_KEYS = [
  {
    key: 'ADD_PRODUCT',
    label: 'নতুন পণ্য যোগ করুন (Add Product)',
    description: 'ক্যাটালগে নতুন ওষুধ ও পণ্য যোগ করার এক্সেস (সুপার এডমিনের কাছে থাকে, চাইলে যে কাউকে দিতে পারে)',
    isSpecial: true,
  },
  {
    key: 'MANAGE_PRODUCTS',
    label: 'পণ্য ও স্টক পরিচালনা (Manage Products & Stock)',
    description: 'বিদ্যমান ক্যাটালগ পণ্য সংশোধন, মূল্য ও ইনভেন্টরি স্টক ইন/আউট পরিচালনা',
  },
  {
    key: 'ADD_CUSTOMER',
    label: 'নতুন কাস্টমার তৈরি/যুক্তকরণ (Add New Customer)',
    description: 'নতুন কাস্টমার বা দোকানদার অ্যাড করার অনুমতি (সুপার এডমিন চাইলে স্টাফ বা এডমিনকে দিবে, না চাইলে বন্ধ রাখবে)',
    isSpecial: true,
  },
  {
    key: 'VIEW_CUSTOMERS',
    label: 'কাস্টমার তালিকা দেখার অনুমতি (View Customers Directory)',
    description: 'গ্রাহক ও পার্টির তালিকা, বকেয়া খতিয়ান ও প্রোফাইল দেখার অনুমতি',
  },
  {
    key: 'CREATE_ORDER',
    label: 'বিক্রয় ও অর্ডার তৈরি (Create Sales Order)',
    description: 'নতুন সেলস অর্ডার সাবমিট ও বিল তৈরি করার অনুমতি',
  },
  {
    key: 'APPROVE_ORDER',
    label: 'অর্ডার অনুমোদন ও ইনভয়েস (Approve Orders & Invoices)',
    description: 'পেন্ডিং অর্ডার অনুমোদন করা এবং ইনভয়েস ইস্যুর অনুমতি',
  },
  {
    key: 'CANCEL_ORDER',
    label: 'অর্ডার বাতিলকরণ (Cancel Order)',
    description: 'ভুল বা অপ্রয়োজনীয় অর্ডার বাতিল করার অনুমতি',
  },
  {
    key: 'COLLECT_PAYMENT',
    label: 'বাকি আদায় ও লেনদেন (Collect Due Payments)',
    description: 'কাস্টমার বকেয়া টাকা আদায় ও পেমেন্ট এন্ট্রি করার অনুমতি',
  },
  {
    key: 'VIEW_ALL_AREAS',
    label: 'সকল টেরিটরি/এলাকা দেখার অনুমতি (View All Territories)',
    description: 'নির্দিষ্ট জোনের বাইরেও সমস্ত এলাকার তথ্য দেখার অনুমতি',
  },
  {
    key: 'MANAGE_EXPENSES',
    label: 'ব্যয় বা খরচ পরিচালনা (Manage Expenses)',
    description: 'কোম্পানির দৈনন্দিন পরিচালনা ব্যয় এন্ট্রি ও নিরীক্ষা',
  },
  {
    key: 'VIEW_REPORTS',
    label: 'ব্যবসায়িক রিপোর্ট ও অ্যানালিটিক্স (View Reports & Analytics)',
    description: 'লাভ-ক্ষতি, বিক্রয় ও স্টক অ্যানালিটিক্স রিপোর্ট দেখার অনুমতি',
  },
  {
    key: 'MANAGE_STAFF',
    label: 'স্টাফ ও রোল পরিচালনা (Manage Staff & Roles)',
    description: 'নতুন স্টাফ তৈরি ও পারমিশন কন্ট্রোল করার অনুমতি',
  },
  {
    key: 'MANAGE_SETTINGS',
    label: 'সিস্টেম সেটিংস ও অডিট লগ (Settings & Logs)',
    description: 'কোম্পানি প্রোফাইল সেটিংস ও অ্যাক্টিভিটি লগ দেখার অনুমতি',
  },
];

export const StaffManagementView: React.FC<StaffManagementViewProps> = ({
  staffMembers = [],
  areas = [],
  currentUser,
  settings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<UserProfile | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    phone: '',
    password: '',
    role: 'staff' as Role,
    assignedAreas: [] as string[],
    status: 'active' as UserProfile['status'],
    permissions: {
      ADD_PRODUCT: false,
      MANAGE_PRODUCTS: false,
      ADD_CUSTOMER: false,
      VIEW_CUSTOMERS: true,
      CREATE_ORDER: true,
      COLLECT_PAYMENT: true,
      APPROVE_ORDER: false,
      CANCEL_ORDER: false,
      VIEW_ALL_AREAS: false,
      MANAGE_EXPENSES: false,
      VIEW_REPORTS: false,
      MANAGE_STAFF: false,
      MANAGE_SETTINGS: false,
    } as Record<string, boolean>,
  });
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [staffToDelete, setStaffToDelete] = useState<UserProfile | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteDone, setDeleteDone] = useState<string | null>(null);

  const isSuperAdmin = isSuperAdminUser(currentUser);

  // Check for duplicate names among all staff
  const duplicateNameCount = useMemo(() => {
    const counts: Record<string, number> = {};
    staffMembers.forEach((s) => {
      const key = (s.name || '').trim().toLowerCase();
      counts[key] = (counts[key] || 0) + 1;
    });
    return counts;
  }, [staffMembers]);

  // Filter staff
  const filteredStaff = staffMembers.filter((s) => {
    if (roleFilter === 'ADMIN' && !isAdminRole(s.role)) return false;
    if (roleFilter === 'USER' && isAdminRole(s.role)) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        userHandle(s).toLowerCase().includes(q) ||
        (s.phone && s.phone.includes(q))
      );
    }
    return true;
  });

  const handleOpenCreate = () => {
    setFormData({
      name: '',
      username: '',
      phone: '',
      password: '',
      role: 'staff',
      assignedAreas: areas.length > 0 ? [areas[0].id] : [],
      status: 'active',
      permissions: {
        ADD_PRODUCT: false,
        MANAGE_PRODUCTS: false,
        ADD_CUSTOMER: false,
        VIEW_CUSTOMERS: true,
        CREATE_ORDER: true,
        COLLECT_PAYMENT: true,
        APPROVE_ORDER: false,
        CANCEL_ORDER: false,
        VIEW_ALL_AREAS: false,
        MANAGE_EXPENSES: false,
        VIEW_REPORTS: false,
        MANAGE_STAFF: false,
        MANAGE_SETTINGS: false,
      },
    });
    setShowPassword(false);
    setError(null);
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (staff: UserProfile) => {
    setEditingStaff(staff);
    setFormData({
      name: staff.name,
      username: userHandle(staff),
      phone: staff.phone || '',
      password: '',
      role: isAdminRole(staff.role) ? 'super_admin' : 'staff',
      assignedAreas: staff.assignedAreas || [],
      status: staff.status,
      permissions: {
        ADD_PRODUCT: Boolean(staff.permissions?.ADD_PRODUCT || staff.permissions?.['product.create']),
        MANAGE_PRODUCTS: Boolean(staff.permissions?.MANAGE_PRODUCTS),
        ADD_CUSTOMER: Boolean(staff.permissions?.ADD_CUSTOMER || staff.permissions?.['customer.create']),
        VIEW_CUSTOMERS: Boolean(staff.permissions?.VIEW_CUSTOMERS ?? staff.permissions?.['customer.view'] ?? true),
        CREATE_ORDER: Boolean(staff.permissions?.CREATE_ORDER),
        COLLECT_PAYMENT: Boolean(staff.permissions?.COLLECT_PAYMENT),
        APPROVE_ORDER: Boolean(staff.permissions?.APPROVE_ORDER),
        CANCEL_ORDER: Boolean(staff.permissions?.CANCEL_ORDER),
        VIEW_ALL_AREAS: Boolean(staff.permissions?.VIEW_ALL_AREAS),
        MANAGE_EXPENSES: Boolean(staff.permissions?.MANAGE_EXPENSES),
        VIEW_REPORTS: Boolean(staff.permissions?.VIEW_REPORTS),
        MANAGE_STAFF: Boolean(staff.permissions?.MANAGE_STAFF),
        MANAGE_SETTINGS: Boolean(staff.permissions?.MANAGE_SETTINGS || staff.permissions?.['settings.view']),
      },
    });
    setShowPassword(false);
    setError(null);
  };

  const handleSaveStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim()) {
      setError('নাম প্রদান করুন');
      return;
    }

    const targetUsername = normalizeUsername(formData.username);
    if (!editingStaff) {
      const bad = validateUsername(targetUsername);
      if (bad) {
        setError(bad);
        return;
      }
      const existing = staffMembers.find((s) => userHandle(s).toLowerCase() === targetUsername);
      if (existing) {
        setError(`"${targetUsername}" ইউজার নামটি ইতিমধ্যে ব্যবহৃত হচ্ছে (${existing.name})। অন্য ইউজার নাম দিন।`);
        return;
      }
    }

    if (!editingStaff && (!formData.password || formData.password.trim().length < 6)) {
      setError('স্টাফের লগইনের জন্য অন্তত ৬ অক্ষরের পাসওয়ার্ড দিন (Password must be at least 6 characters)');
      return;
    }

    setLoading(true);
    try {
      const now = getNowISO();
      const resolvedPermissions = {
        ...formData.permissions,
        ADD_PRODUCT: Boolean(formData.permissions.ADD_PRODUCT),
        'product.create': Boolean(formData.permissions.ADD_PRODUCT),
        ADD_CUSTOMER: Boolean(formData.permissions.ADD_CUSTOMER),
        'customer.create': Boolean(formData.permissions.ADD_CUSTOMER),
      };

      if (editingStaff) {
        const staffRef = doc(db, 'users', editingStaff.uid);
        const updated: Partial<UserProfile> = {
          name: formData.name.trim(),
          phone: formData.phone.trim(),
          role: formData.role,
          assignedAreas: formData.assignedAreas,
          permissions: resolvedPermissions,
          status: formData.status,
          updatedAt: now,
        };

        await updateDoc(staffRef, updated);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'STAFF_UPDATED',
          module: 'staff',
          recordId: editingStaff.uid,
          newData: updated,
        });

        setEditingStaff(null);
      } else {
        // Real Firebase Auth account (no password is ever stored in the database)
        const uid = await createStaffLogin(targetUsername, formData.password.trim());
        const userRef = doc(db, 'users', uid);
        const newUser: UserProfile = {
          uid,
          username: targetUsername,
          email: usernameToEmail(targetUsername),
          name: formData.name.trim(),
          phone: formData.phone.trim(),
          role: formData.role,
          assignedAreas: formData.assignedAreas,
          permissions: resolvedPermissions,
          status: formData.status,
          createdAt: now,
        };

        await setDoc(userRef, newUser);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'STAFF_CREATED',
          module: 'staff',
          recordId: uid,
          newData: newUser,
        });

        setIsCreateOpen(false);
      }
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteStaff = async () => {
    if (!staffToDelete) return;
    const target = staffToDelete;
    setDeleteLoading(true);
    setDeleteError(null);
    setDeleteDone(null);
    try {
      await deleteDoc(doc(db, 'users', target.uid));
      setDeleteDone(`"${target.name}" মুছে ফেলা হয়েছে।`);
      // The log is best effort: a logging problem must not hide a successful delete.
      logActivity({
        userId: currentUser.uid,
        userName: currentUser.name,
        action: 'STAFF_DELETED',
        module: 'staff',
        recordId: target.uid,
        oldData: target,
      }).catch((e) => console.error('Delete log failed:', e));
    } catch (err: any) {
      console.error('Delete staff failed:', err);
      const code = String(err?.code || err?.message || '');
      setDeleteError(
        code.includes('permission-denied') || code.includes('insufficient permissions')
          ? 'মুছতে পারেনি: Firestore Rules অনুমতি দিচ্ছে না। আপনার অ্যাকাউন্ট "super_admin" কিনা এবং নতুন Rules পাবলিশ করা আছে কিনা দেখুন।'
          : `মুছতে পারেনি: ${getFriendlyErrorMessage(err)}`
      );
    } finally {
      setDeleteLoading(false);
      setStaffToDelete(null);
    }
  };

  const handleRoleChange = (newRole: Role) => {
    if (newRole === 'super_admin') {
      const allPerms: Record<string, boolean> = {};
      PERMISSION_KEYS.forEach((p) => {
        allPerms[p.key] = true;
      });
      allPerms['product.create'] = true;
      allPerms['customer.create'] = true;
      setFormData((prev) => ({
        ...prev,
        role: newRole,
        assignedAreas: areas.map((a) => a.id),
        permissions: allPerms,
      }));
    } else if (newRole === 'admin') {
      const adminPerms: Record<string, boolean> = {};
      PERMISSION_KEYS.forEach((p) => {
        // Super admin can explicitly choose whether admin can add products or add customers
        adminPerms[p.key] = p.key !== 'ADD_CUSTOMER' && p.key !== 'ADD_PRODUCT';
      });
      adminPerms['product.create'] = false;
      adminPerms['customer.create'] = false;
      setFormData((prev) => ({
        ...prev,
        role: newRole,
        permissions: adminPerms,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        role: newRole,
        permissions: {
          ADD_PRODUCT: false,
          'product.create': false,
          MANAGE_PRODUCTS: false,
          ADD_CUSTOMER: false,
          'customer.create': false,
          VIEW_CUSTOMERS: true,
          CREATE_ORDER: true,
          COLLECT_PAYMENT: true,
          APPROVE_ORDER: false,
          CANCEL_ORDER: false,
          VIEW_ALL_AREAS: false,
          MANAGE_EXPENSES: false,
          VIEW_REPORTS: false,
          MANAGE_STAFF: false,
          MANAGE_SETTINGS: false,
        },
      }));
    }
  };

  const handleSelectAllPermissions = () => {
    const allPerms: Record<string, boolean> = {};
    PERMISSION_KEYS.forEach((p) => {
      allPerms[p.key] = true;
    });
    setFormData((prev) => ({
      ...prev,
      permissions: allPerms,
    }));
  };

  const handleClearAllPermissions = () => {
    const cleared: Record<string, boolean> = {};
    PERMISSION_KEYS.forEach((p) => {
      cleared[p.key] = false;
    });
    setFormData((prev) => ({
      ...prev,
      permissions: cleared,
    }));
  };

  const handleToggleArea = (areaId: string) => {
    setFormData((prev) => {
      const exists = prev.assignedAreas.includes(areaId);
      return {
        ...prev,
        assignedAreas: exists
          ? prev.assignedAreas.filter((id) => id !== areaId)
          : [...prev.assignedAreas, areaId],
      };
    });
  };

  const handleTogglePermission = (key: string) => {
    setFormData((prev) => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [key]: !prev.permissions[key],
      },
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-blue-600" />
            স্টাফ ও ইউজার রোল ব্যবস্থাপনা (Staff & RBAC)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Administer staff profiles, assign territory zones, and grant granular role-based permissions.
          </p>
        </div>

        <div>
          <button
            type="button"
            onClick={handleOpenCreate}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            নতুন স্টাফ অ্যাকাউন্ট (Add Staff)
          </button>
        </div>
      </div>

      {/* SUPER ADMIN CLEARANCE BANNER */}
      {isSuperAdmin && (
        <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white p-4 sm:p-5 rounded-2xl shadow-sm border border-purple-800/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center text-amber-300 shrink-0">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold tracking-tight text-white">
                  সুপার অ্যাডমিন পূর্ণ কর্তৃত্ব সক্রিয় (Super Admin Clearance Active)
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full font-bold">
                  All Access Granted
                </span>
              </div>
              <p className="text-xs text-purple-200/90 mt-0.5">
                সিস্টেমের সমস্ত অর্ডার, চালান, পেমেন্ট, স্টক, আর্থিক রিপোর্ট, অডিট হিস্টোরি ও যে-কোনো স্টাফের পারমিশন নিয়ন্ত্রণ করার শতভাগ অধিকার আপনার রয়েছে।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="নাম, ইউজার নাম বা ফোন দিয়ে খুঁজুন..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">সব প্রোফাইল</option>
            <option value="ADMIN">অ্যাডমিন</option>
            <option value="USER">ইউজার</option>
          </select>
        </div>
      </div>

      {/* Duplicate warning & explanation banner */}
      {deleteError && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium">
          {deleteError}
        </div>
      )}
      {deleteDone && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs font-medium">
          {deleteDone}
        </div>
      )}

      {isSuperAdmin && staffMembers.some((s) => (duplicateNameCount[(s.name || '').trim().toLowerCase()] || 0) > 1) && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-950">একই নামের একাধিক অ্যাকাউন্ট সনাক্ত হয়েছে (Duplicate Accounts Detected)</p>
              <p className="text-[11px] text-amber-700 mt-0.5">
                আগে ইউজারনেম দিয়ে লগইন করার সময় সিস্টেমে অতিরিক্ত অ্যাকাউন্ট তৈরি হয়ে থাকতে পারে। আপনি যে একাউন্টে পাসওয়ার্ড সক্রিয় করেছেন সেটি রেখে অপ্রয়োজনীয় বা অতিরিক্ত অ্যাকাউন্টটি ডানদিকের লাল ট্র্যাশ (<Trash2 className="w-3 h-3 inline text-rose-600" /> Delete) বাটনে ক্লিক করে মুছে দিতে পারেন।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Card List (Screen width < md) */}
      <div className="block md:hidden space-y-3">
        {filteredStaff.map((staff) => {
          const isDuplicate = (duplicateNameCount[(staff.name || '').trim().toLowerCase()] || 0) > 1;
          return (
            <div
              key={staff.uid}
              className={`bg-white rounded-xl border p-4 shadow-xs space-y-3 transition-colors ${
                isDuplicate ? 'border-amber-200 bg-amber-50/20' : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 text-sm">{staff.name}</h4>
                    {isDuplicate && (
                      <span className="text-[10px] text-amber-700 bg-amber-100/80 px-1.5 py-0.5 rounded font-semibold border border-amber-300">
                        ডুপ্লিকেট নাম
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">@{userHandle(staff)}</p>
                  {staff.phone && <p className="text-xs text-slate-400 mt-0.5">{staff.phone}</p>}
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider ${
                      isAdminRole(staff.role)
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {roleLabel(staff.role)}
                  </span>
                  <span
                    className={`px-2 py-0.2 rounded text-[10px] font-semibold uppercase ${
                      staff.status === 'active'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-rose-50 text-rose-700'
                    }`}
                  >
                    {staff.status}
                  </span>
                </div>
              </div>

              {/* Password & Permission badges */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100 text-xs">
                {isAdminRole(staff.role) ? (
                  <span className="text-[10px] text-purple-700 bg-purple-50 border border-purple-200 px-1.5 py-0.5 rounded font-medium">
                    👑 অল এক্সেস
                  </span>
                ) : (
                  <>
                    {Boolean(staff.permissions?.ADD_PRODUCT || staff.permissions?.['product.create']) && (
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-300 px-1.5 py-0.5 rounded font-medium">
                        + পণ্য যোগ অনুমতি
                      </span>
                    )}
                    {Boolean(staff.permissions?.ADD_CUSTOMER || staff.permissions?.['customer.create']) && (
                      <span className="text-[10px] text-blue-700 bg-blue-50 border border-blue-200 px-1.5 py-0.5 rounded font-medium">
                        + কাস্টমার যোগ
                      </span>
                    )}
                  </>
                )}
              </div>

              {/* Action buttons on mobile */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => handleOpenEdit(staff)}
                  className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  এডিট ও পাসওয়ার্ড
                </button>
                {isSuperAdmin && staff.uid !== currentUser.uid && (
                  <button
                    type="button"
                    onClick={() => setStaffToDelete(staff)}
                    className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    মুছে ফেলুন
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Staff Table (Desktop width >= md) */}
      <div className="hidden md:block bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Staff Name & Contact</th>
                <th className="px-4 py-3">প্রোফাইল টাইপ</th>
                <th className="px-4 py-3">Assigned Territories</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStaff.map((staff) => {
                const isDuplicate = (duplicateNameCount[(staff.name || '').trim().toLowerCase()] || 0) > 1;
                return (
                  <tr key={staff.uid} className={`hover:bg-slate-50/70 transition-colors ${isDuplicate ? 'bg-amber-50/15' : ''}`}>
                    <td className="px-4 py-3 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        <span>{staff.name}</span>
                        {isDuplicate && (
                          <span className="text-[10px] text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.2 rounded font-medium">
                            ডুপ্লিকেট নাম
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-normal">
                        <span>@{userHandle(staff)}</span>
                        {staff.phone && <span>&bull; {staff.phone}</span>}
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex flex-col items-start gap-1">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider ${
                            isAdminRole(staff.role)
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {roleLabel(staff.role)}
                        </span>
                        {!isAdminRole(staff.role) && Boolean(staff.permissions?.ADD_PRODUCT || staff.permissions?.['product.create']) && (
                          <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-300 px-1.5 py-0.2 rounded font-medium" title="সুপার এডমিন নতুন পণ্য যোগ করার অনুমতি দিয়েছেন">
                            + পণ্য যোগ এক্সেস
                          </span>
                        )}
                        {!isAdminRole(staff.role) && Boolean(staff.permissions?.ADD_CUSTOMER || staff.permissions?.['customer.create']) && (
                          <span className="text-[10px] text-blue-700 bg-blue-50 border border-blue-200 px-1.5 py-0.2 rounded font-medium" title="কাস্টমার তৈরির অনুমতি আছে">
                            + কাস্টমার যোগ
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      {isAdminRole(staff.role) || staff.permissions?.VIEW_ALL_AREAS ? (
                        <span className="text-[11px] font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                          All Territories (All Zones)
                        </span>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {Array.isArray(staff.assignedAreas) && staff.assignedAreas.length > 0 ? (
                            staff.assignedAreas.map((areaId) => {
                              const area = areas.find((a) => a.id === areaId);
                              return (
                                <span
                                  key={areaId}
                                  className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded"
                                >
                                  {area ? area.name : areaId}
                                </span>
                              );
                            })
                          ) : (
                            <span className="text-slate-400">None assigned</span>
                          )}
                        </div>
                      )}
                    </td>

                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          staff.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700'
                        }`}
                      >
                        {staff.status}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(staff)}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          এডিট ও পাসওয়ার্ড
                        </button>
                        {isSuperAdmin && staff.uid !== currentUser.uid && (
                          <button
                            type="button"
                            onClick={() => setStaffToDelete(staff)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="স্টাফ মুছুন (Delete Staff)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT STAFF MODAL */}
      {(isCreateOpen || editingStaff) && (
        <Modal
          isOpen={true}
          onClose={() => {
            setIsCreateOpen(false);
            setEditingStaff(null);
          }}
          title={editingStaff ? `স্টাফ পারমিশন সম্পাদন: ${editingStaff.name}` : 'নতুন স্টাফ নিবন্ধন (Add Staff)'}
          maxWidth="lg"
          footer={
            <>
              <button
                type="button"
                onClick={() => {
                  setIsCreateOpen(false);
                  setEditingStaff(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleSaveStaff}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                {loading ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleSaveStaff} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">স্টাফের নাম (Name)*</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="যেমন: তানভীর হাসান"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">ইউজার নাম (Username)*</label>
                <input
                  type="text"
                  required
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  disabled={Boolean(editingStaff)}
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  placeholder="যেমন: tanvir"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs disabled:bg-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">ফোন নম্বর</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="01811223344"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">প্রোফাইল টাইপ*</label>
                <select
                  value={formData.role === 'staff' ? 'staff' : 'super_admin'}
                  onChange={(e) => handleRoleChange(e.target.value as Role)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white font-medium"
                >
                  <option value="staff">ইউজার (পারমিশন অনুযায়ী)</option>
                  <option value="super_admin">অ্যাডমিন (সম্পূর্ণ এক্সেস)</option>
                </select>
              </div>

              {/* Login password: only when creating. */}
              <div className="col-span-2">
                {!editingStaff ? (
                  <>
                    <label className="font-bold text-slate-700 block mb-1">লগইন পাসওয়ার্ড (Password)*</label>
                    <div className="relative">
                      <Key className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        autoComplete="new-password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন"
                        minLength={6}
                        className="w-full pl-9 pr-10 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                        title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                      >
                        {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      এই ইউজার নাম ও পাসওয়ার্ড দিয়ে লগইন করা যাবে। পাসওয়ার্ড ডেটাবেসে সংরক্ষণ করা হয় না।
                    </p>
                  </>
                ) : (
                  <p className="text-[11px] text-slate-500">
                    পাসওয়ার্ড বদলাতে চাইলে ইউজার নিজে লগইন করে প্রোফাইল থেকে বদলাবেন।
                  </p>
                )}
              </div>
            </div>

            {formData.role === 'super_admin' && (
              <div className="p-3 bg-purple-50 border border-purple-200 text-purple-800 rounded-xl flex items-center gap-2">
                <Crown className="w-4 h-4 text-purple-600 shrink-0" />
                <span className="text-[11px] font-semibold">
                  অ্যাডমিনের জন্য সিস্টেমের সমস্ত ক্ষমতা, টেরিটোরি এবং অ্যাক্সেস পারমিশন সম্পূর্ণ উন্মুক্ত থাকে।
                </span>
              </div>
            )}

            {/* ASSIGNED AREAS */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                দায়িত্বপ্রাপ্ত এলাকা (Assigned Territories)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                {areas.map((a) => {
                  const isChecked = formData.assignedAreas.includes(a.id);
                  return (
                    <label
                      key={a.id}
                      className="flex items-center gap-2 text-[11px] font-medium text-slate-700 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleToggleArea(a.id)}
                        className="rounded text-blue-600 focus:ring-blue-500"
                      />
                      <span>{a.name}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* GRANULAR PERMISSIONS */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-slate-700 block">
                  সুনির্দিষ্ট পারমিশন ও এক্সেস কন্ট্রোল (Granular Permissions)
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSelectAllPermissions}
                    className="text-[11px] text-blue-600 hover:text-blue-700 font-semibold hover:underline cursor-pointer"
                  >
                    সব নির্বাচন (Select All)
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    type="button"
                    onClick={handleClearAllPermissions}
                    className="text-[11px] text-slate-500 hover:text-slate-700 font-semibold hover:underline cursor-pointer"
                  >
                    সব বাতিল (Clear All)
                  </button>
                </div>
              </div>
              <div className="space-y-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                {PERMISSION_KEYS.map((p) => {
                  const isGranted = Boolean(formData.permissions[p.key]);
                  const isProductAdd = p.key === 'ADD_PRODUCT';
                  const isCustomerAdd = p.key === 'ADD_CUSTOMER';
                  return (
                    <label
                      key={p.key}
                      className={`flex items-start justify-between text-xs font-medium p-2.5 rounded-xl border transition-all cursor-pointer ${
                        isProductAdd
                          ? isGranted
                            ? 'bg-emerald-50/90 border-emerald-300 text-emerald-900 shadow-2xs'
                            : 'bg-amber-50/40 border-amber-200/70 text-slate-800'
                          : isCustomerAdd
                          ? isGranted
                            ? 'bg-blue-50/90 border-blue-300 text-blue-900 shadow-2xs'
                            : 'bg-amber-50/40 border-amber-200/70 text-slate-800'
                          : isGranted
                          ? 'bg-white border-slate-200 text-slate-900 shadow-2xs'
                          : 'bg-slate-100/60 border-slate-200/50 text-slate-500 hover:bg-slate-100'
                      }`}
                    >
                      <div className="pr-3 flex-1">
                        <div className="flex items-center gap-2 font-bold">
                          <span>{p.label}</span>
                          {isProductAdd && (
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                              isGranted
                                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                : 'bg-amber-100 text-amber-800 border-amber-300'
                            }`}>
                              {isGranted ? 'অনুমতি সক্রিয়' : 'সুপার এডমিনের নিয়ন্ত্রণে'}
                            </span>
                          )}
                          {isCustomerAdd && (
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                              isGranted
                                ? 'bg-blue-100 text-blue-800 border-blue-300'
                                : 'bg-amber-100 text-amber-800 border-amber-300'
                            }`}>
                              {isGranted ? 'অনুমতি সক্রিয়' : 'সুপার এডমিনের নিয়ন্ত্রণে'}
                            </span>
                          )}
                        </div>
                        {p.description && (
                          <p className="text-[11px] text-slate-500 font-normal mt-0.5 leading-snug">
                            {p.description}
                          </p>
                        )}
                      </div>
                      <input
                        type="checkbox"
                        checked={isGranted}
                        onChange={() => handleTogglePermission(p.key)}
                        className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer shrink-0"
                      />
                    </label>
                  );
                })}
              </div>
            </div>
          </form>
        </Modal>
      )}

      {/* CONFIRM DELETE DIALOG */}
      {staffToDelete && (
        <ConfirmDialog
          isOpen={Boolean(staffToDelete)}
          onClose={() => setStaffToDelete(null)}
          onConfirm={handleDeleteStaff}
          title="স্টাফ একাউন্ট অপসারণ (Delete Staff Account)"
          message={`আপনি কি নিশ্চিতভাবে "${staffToDelete.name}" (@${userHandle(staffToDelete)}) একাউন্টটি মুছে ফেলতে চান? এটি স্থায়ীভাবে মুছে ফেলা হবে।`}
          confirmText="মুছে ফেলুন (Delete)"
          cancelText="বাতিল"
          type="danger"
          loading={deleteLoading}
        />
      )}
    </div>
  );
};
