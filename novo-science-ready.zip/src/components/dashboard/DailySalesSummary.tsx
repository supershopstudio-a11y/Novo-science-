import React, { useMemo } from 'react';
import {
  TrendingUp,
  CreditCard,
  ShoppingCart,
  DollarSign,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  Calendar,
  Layers,
  Wallet,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { Order, Payment, Expense } from '../../types';
import { formatCurrency, formatDate, isDateInRange, getDateRange } from '../../utils/formatters';

interface DailySalesSummaryProps {
  orders: Order[];
  payments: Payment[];
  expenses?: Expense[];
  currencySymbol?: string;
  onNavigate?: (tab: string) => void;
  onOpenCreateOrder?: () => void;
  title?: string;
  subtitle?: string;
  className?: string;
  compact?: boolean;
}

export const DailySalesSummary: React.FC<DailySalesSummaryProps> = ({
  orders = [],
  payments = [],
  expenses = [],
  currencySymbol = '৳',
  onNavigate,
  onOpenCreateOrder,
  title = 'দৈনিক বিক্রয় সারাংশ (Daily Sales Summary)',
  subtitle = 'আজকের বিক্রয়, পেমেন্ট কালেকশন ও অর্ডার পারফরম্যান্স',
  className = '',
  compact = false,
}) => {
  const todayRange = useMemo(() => getDateRange('today'), []);

  // Compute daily metrics
  const summary = useMemo(() => {
    const todayOrders = (orders || []).filter((o) =>
      isDateInRange(o.date || o.createdAt, todayRange)
    );

    // All orders created today
    const totalOrdersCount = todayOrders.length;
    const totalOrderAmount = todayOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    // Approved orders today
    const approvedOrders = todayOrders.filter((o) => o.orderStatus === 'APPROVED');
    const approvedOrdersCount = approvedOrders.length;
    const approvedSalesAmount = approvedOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    // Pending approval orders today
    const pendingOrders = todayOrders.filter((o) => o.orderStatus === 'PENDING');
    const pendingOrdersCount = pendingOrders.length;
    const pendingOrdersAmount = pendingOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    // Delivered / Dispatched orders today
    const deliveredOrdersCount = todayOrders.filter((o) => o.orderStatus === 'DELIVERED').length;

    // Payments collected today
    const todayPayments = (payments || []).filter((p) =>
      isDateInRange(p.date || p.createdAt, todayRange)
    );
    const totalCollected = todayPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const paymentTransactionsCount = todayPayments.length;

    // Payment methods breakdown today
    const cashCollected = todayPayments
      .filter((p) => (p.paymentMethod || '').toLowerCase() === 'cash')
      .reduce((sum, p) => sum + (p.amount || 0), 0);
    const bankOrDigitalCollected = totalCollected - cashCollected;

    // Direct payments collected inside today's orders
    const todayDirectPaidInOrders = todayOrders.reduce((sum, o) => sum + (o.paidAmount || 0), 0);
    const todayDueGenerated = Math.max(0, totalOrderAmount - todayDirectPaidInOrders);

    // Today's expenses
    const todayExpenses = (expenses || [])
      .filter((e) => isDateInRange(e.date || e.createdAt, todayRange))
      .reduce((sum, e) => sum + (e.amount || 0), 0);

    // Net cash flow today (Collections minus Expenses)
    const netCashFlow = totalCollected - todayExpenses;

    // Average Order Value
    const averageOrderValue =
      totalOrdersCount > 0 ? Math.round(totalOrderAmount / totalOrdersCount) : 0;

    // Collection recovery rate (% of today's sales collected)
    const collectionRatio =
      totalOrderAmount > 0 ? Math.min(100, Math.round((totalCollected / totalOrderAmount) * 100)) : 0;

    return {
      totalOrdersCount,
      totalOrderAmount,
      approvedOrdersCount,
      approvedSalesAmount,
      pendingOrdersCount,
      pendingOrdersAmount,
      deliveredOrdersCount,
      totalCollected,
      paymentTransactionsCount,
      cashCollected,
      bankOrDigitalCollected,
      todayDueGenerated,
      todayExpenses,
      netCashFlow,
      averageOrderValue,
      collectionRatio,
      todayDateFormatted: formatDate(new Date().toISOString()),
    };
  }, [orders, payments, expenses, todayRange]);

  return (
    <div
      className={`bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow overflow-hidden ${className}`}
    >
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">{title}</h2>
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live Today
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">{subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-center">
            <div className="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 px-3 py-1.5 rounded-lg text-xs text-slate-200">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>{summary.todayDateFormatted}</span>
            </div>
            {onOpenCreateOrder && (
              <button
                type="button"
                onClick={onOpenCreateOrder}
                className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 shadow-sm cursor-pointer"
              >
                + নতুন অর্ডার
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="p-4 sm:p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Card 1: Today's Total Sales */}
          <div
            onClick={() => onNavigate?.('orders')}
            className="group relative bg-gradient-to-br from-blue-50/50 to-indigo-50/30 border border-blue-100 rounded-xl p-4.5 hover:border-blue-300 transition-all cursor-pointer shadow-xs"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                আজকের মোট বিক্রয় (Total Sales)
              </span>
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>

            <div className="mt-3">
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {formatCurrency(summary.totalOrderAmount, currencySymbol)}
              </div>
              <div className="flex items-center gap-2 mt-2 text-xs text-slate-600">
                <span className="font-semibold text-blue-700 bg-blue-100/70 px-1.5 py-0.5 rounded">
                  অনুমোদিত: {formatCurrency(summary.approvedSalesAmount, currencySymbol)}
                </span>
                {summary.pendingOrdersCount > 0 && (
                  <span className="text-[11px] text-amber-700 font-medium">
                    ({summary.pendingOrdersCount}টি অনুমোদনের অপেক্ষায়)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Card 2: Collected Payments */}
          <div
            onClick={() => onNavigate?.('due')}
            className="group relative bg-gradient-to-br from-emerald-50/60 to-teal-50/30 border border-emerald-100 rounded-xl p-4.5 hover:border-emerald-300 transition-all cursor-pointer shadow-xs"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                আজকের কালেকশন (Collected Payments)
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                <CreditCard className="w-4 h-4" />
              </div>
            </div>

            <div className="mt-3">
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight text-emerald-700">
                {formatCurrency(summary.totalCollected, currencySymbol)}
              </div>
              <div className="flex items-center justify-between mt-2 text-xs text-slate-600">
                <span>{summary.paymentTransactionsCount}টি লেনদেন থেকে আদায়</span>
                {summary.cashCollected > 0 && (
                  <span className="text-[11px] text-slate-500 font-mono">
                    নগদ: {formatCurrency(summary.cashCollected, currencySymbol)}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Card 3: Today's New Orders */}
          <div
            onClick={() => onNavigate?.('orders')}
            className="group relative bg-gradient-to-br from-purple-50/50 to-pink-50/30 border border-purple-100 rounded-xl p-4.5 hover:border-purple-300 transition-all cursor-pointer shadow-xs sm:col-span-2 lg:col-span-1"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                আজকের নতুন অর্ডার (New Orders)
              </span>
              <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                <ShoppingCart className="w-4 h-4" />
              </div>
            </div>

            <div className="mt-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  {summary.totalOrdersCount}
                </span>
                <span className="text-xs text-slate-500 font-medium">টি অর্ডার নথিভুক্ত</span>
              </div>

              <div className="flex items-center gap-1.5 mt-2 flex-wrap text-[11px]">
                <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-semibold border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3" /> {summary.approvedOrdersCount} অনুমোদিত
                </span>
                {summary.pendingOrdersCount > 0 && (
                  <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md font-semibold border border-amber-200">
                    <Clock className="w-3 h-3" /> {summary.pendingOrdersCount} পেন্ডিং
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Supplementary Metrics Strip */}
        {!compact && (
          <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/70">
              <span className="text-slate-500 block text-[11px]">গড় অর্ডার মূল্য (AOV)</span>
              <span className="font-bold text-slate-800 text-sm mt-0.5 block">
                {formatCurrency(summary.averageOrderValue, currencySymbol)}
              </span>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/70">
              <span className="text-slate-500 block text-[11px]">আজকের বাকি তৈরি (Due Generated)</span>
              <span className="font-bold text-amber-700 text-sm mt-0.5 block">
                {formatCurrency(summary.todayDueGenerated, currencySymbol)}
              </span>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/70">
              <span className="text-slate-500 block text-[11px]">আজকের খরচ (Daily Expense)</span>
              <span className="font-bold text-rose-600 text-sm mt-0.5 block">
                {formatCurrency(summary.todayExpenses, currencySymbol)}
              </span>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/70">
              <span className="text-slate-500 block text-[11px]">নীট ক্যাশ প্রবাহ (Net Cash In)</span>
              <span
                className={`font-bold text-sm mt-0.5 block ${
                  summary.netCashFlow >= 0 ? 'text-emerald-700' : 'text-rose-600'
                }`}
              >
                {formatCurrency(summary.netCashFlow, currencySymbol)}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
