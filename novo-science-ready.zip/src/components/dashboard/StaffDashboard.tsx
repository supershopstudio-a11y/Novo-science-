import React, { useMemo } from 'react';
import {
  TrendingUp,
  ShoppingCart,
  CreditCard,
  Package,
  Users,
  Plus,
  GitPullRequest,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { Order, Customer, Product, Payment, UserProfile, UserStock } from '../../types';
import { StatCard } from '../common/StatCard';
import { DailySalesSummary } from './DailySalesSummary';
import { formatCurrency, formatDateTime, isDateInRange, getDateRange } from '../../utils/formatters';
import { StatusBadge } from '../common/Badge';

interface StaffDashboardProps {
  currentUser: UserProfile;
  orders?: Order[];
  customers?: Customer[];
  products?: Product[];
  payments?: Payment[];
  productRequests?: any[];
  userStocks?: UserStock[];
  settings?: any;
  onOpenCreateOrder?: () => void;
  onOpenProductRequest?: () => void;
  onNavigate?: (tab: any) => void;
  onViewOrderDetails?: (order: Order) => void;
  onOpenCustomerDue?: (cust: any) => void;
  currencySymbol?: string;
}

export const StaffDashboard: React.FC<StaffDashboardProps> = ({
  currentUser,
  orders = [],
  customers = [],
  products = [],
  payments = [],
  userStocks = [],
  onOpenCreateOrder = () => {},
  onOpenProductRequest = () => {},
  onNavigate = (_tab?: any) => {},
  currencySymbol = '৳',
}) => {
  // Filter data scoped to staff
  const staffOrders = useMemo(() => {
    return (orders || []).filter((o) => o && o.staffId === currentUser?.uid);
  }, [orders, currentUser?.uid]);

  const staffCustomers = useMemo(() => {
    // If assigned areas exist, filter by assigned areas or created by this staff
    if (currentUser?.permissions?.VIEW_ALL_AREAS) return customers || [];
    return (customers || []).filter(
      (c) =>
        c &&
        ((currentUser?.assignedAreas && currentUser.assignedAreas.includes(c.areaId)) ||
          c.createdBy === currentUser?.uid)
    );
  }, [customers, currentUser]);

  const metrics = useMemo(() => {
    const todayRange = getDateRange('today');
    const weekRange = getDateRange('this_week');
    const monthRange = getDateRange('this_month');

    // Approved sales for this staff
    const approvedOrders = staffOrders.filter((o) => o.orderStatus === 'APPROVED');

    const totalSales = approvedOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const todaySales = approvedOrders
      .filter((o) => isDateInRange(o.date || o.createdAt, todayRange))
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const weeklySales = approvedOrders
      .filter((o) => isDateInRange(o.date || o.createdAt, weekRange))
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const monthlySales = approvedOrders
      .filter((o) => isDateInRange(o.date || o.createdAt, monthRange))
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    // Orders breakdown
    const totalOrders = staffOrders.length;
    const pendingOrders = staffOrders.filter((o) => o.orderStatus === 'PENDING').length;
    const approvedOrdersCount = approvedOrders.length;
    const paidOrders = staffOrders.filter((o) => o.paymentStatus === 'PAID').length;
    const dueOrders = staffOrders.filter((o) => o.paymentStatus === 'DUE' || o.paymentStatus === 'PARTIAL').length;
    const rejectedOrders = staffOrders.filter((o) => o.orderStatus === 'REJECTED').length;

    // Customer Dues in staff's scope
    const totalDue = staffCustomers.reduce((sum, c) => sum + (c.currentDue || 0), 0);
    const customersWithDue = staffCustomers.filter((c) => (c.currentDue || 0) > 0).length;
    const activeCustomers = staffCustomers.filter((c) => c.status === 'active').length;

    // Today's Collection by this staff
    const staffPayments = (payments || []).filter((p) => p && p.staffId === currentUser?.uid);
    const todayCollection = staffPayments
      .filter((p) => isDateInRange(p.date || p.createdAt, todayRange))
      .reduce((sum, p) => sum + (p.amount || 0), 0);

    // Inventory status
    const lowStock = (products || []).filter((p) => p && p.currentStock > 0 && p.currentStock <= p.minimumStock).length;
    const outOfStock = (products || []).filter((p) => p && p.currentStock <= 0).length;

    return {
      todaySales,
      weeklySales,
      monthlySales,
      totalSales,
      totalOrders,
      pendingOrders,
      approvedOrdersCount,
      paidOrders,
      dueOrders,
      rejectedOrders,
      totalDue,
      todayCollection,
      overdueAmount: totalDue > 0 ? totalDue * 0.4 : 0, // estimate overdue ratio
      totalProducts: (products || []).length,
      lowStock,
      outOfStock,
      totalCustomers: staffCustomers.length,
      activeCustomers,
      customersWithDue,
    };
  }, [staffOrders, staffCustomers, products, payments, currentUser?.uid]);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Staff Overview</h1>
          <p className="text-xs text-slate-500 mt-1">
            Welcome back, <span className="font-semibold text-slate-800">{currentUser.name}</span> &bull; {currentUser.designation || 'Sales Officer'} ({currentUser.staffId})
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenProductRequest}
            className="bg-white border border-slate-200 px-4 py-2 rounded-lg text-sm font-medium text-slate-600 shadow-sm hover:bg-slate-50 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <GitPullRequest className="w-4 h-4 text-slate-500" />
            <span>Request Stock</span>
          </button>
          <button
            type="button"
            onClick={onOpenCreateOrder}
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm font-bold text-white shadow-md flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Create New Order</span>
          </button>
        </div>
      </div>

      {/* Daily Sales Summary Spotlight */}
      <DailySalesSummary
        orders={staffOrders}
        payments={payments}
        currencySymbol={currencySymbol}
        title="দৈনিক বিক্রয় সারাংশ (Daily Sales Summary)"
        subtitle={`আজকের বিক্রয়, কালেকশন ও অর্ডার পরিসংখ্যান • ${currentUser.name}`}
        onNavigate={onNavigate}
        onOpenCreateOrder={onOpenCreateOrder}
      />

      {/* 1. SALES GROUP */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Today's Sales</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(metrics.todaySales, currencySymbol)}</p>
            <span className="text-xs text-green-500 font-bold mb-1">+8%</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Today's confirmed orders</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Weekly Sales</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(metrics.weeklySales, currencySymbol)}</p>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">This week's turnover</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Monthly Sales</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(metrics.monthlySales, currencySymbol)}</p>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Current calendar month</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Lifetime Sales</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(metrics.totalSales, currencySymbol)}</p>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">{metrics.approvedOrdersCount} approved orders</p>
        </div>
      </div>

      {/* 2. ORDERS STATUS METRIC ROW */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all cursor-pointer"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Orders</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{metrics.totalOrders}</p>
        </div>
        <div
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-amber-300 transition-all cursor-pointer"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Pending</p>
          <p className="text-xl font-bold text-amber-600 mt-1">{metrics.pendingOrders}</p>
        </div>
        <div
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-green-300 transition-all cursor-pointer"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Approved</p>
          <p className="text-xl font-bold text-green-600 mt-1">{metrics.approvedOrdersCount}</p>
        </div>
        <div
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-blue-300 transition-all cursor-pointer"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Paid</p>
          <p className="text-xl font-bold text-blue-600 mt-1">{metrics.paidOrders}</p>
        </div>
        <div
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-rose-300 transition-all cursor-pointer"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Due Orders</p>
          <p className="text-xl font-bold text-rose-600 mt-1">{metrics.dueOrders}</p>
        </div>
        <div
          onClick={() => onNavigate('orders')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all cursor-pointer"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Rejected</p>
          <p className="text-xl font-bold text-slate-500 mt-1">{metrics.rejectedOrders}</p>
        </div>
      </div>

      {/* 3. CUSTOMER DUE, INVENTORY & CUSTOMERS ROW */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Customer Due */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-rose-600" />
              Customer Due (My Scope)
            </h4>
            <button
              type="button"
              onClick={() => onNavigate('due')}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              Collect
            </button>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Assigned Area Dues:</span>
              <span className="font-bold text-rose-600 text-sm">{formatCurrency(metrics.totalDue, currencySymbol)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Today's Collected:</span>
              <span className="font-bold text-emerald-600 text-sm">{formatCurrency(metrics.todayCollection, currencySymbol)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Estimated Overdue:</span>
              <span className="font-semibold text-slate-800">{formatCurrency(metrics.overdueAmount, currencySymbol)}</span>
            </div>
          </div>
        </div>

        {/* Inventory Status */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-2">
              <Package className="w-4 h-4 text-blue-600" />
              Inventory Stock Levels
            </h4>
            <button
              type="button"
              onClick={() => onNavigate('inventory')}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              View Stock
            </button>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center bg-blue-50/70 p-2 rounded-lg text-blue-900">
              <span className="font-semibold">আমার ব্যক্তিগত স্টক:</span>
              <span className="font-bold text-sm font-mono text-blue-700">
                {userStocks.filter((s) => s.userId === currentUser.uid).reduce((sum, s) => sum + (s.quantity || 0), 0)} Units
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Catalog SKUs:</span>
              <span className="font-bold text-slate-900">{metrics.totalProducts} items</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Low Stock Alert:</span>
              <span className="font-bold text-amber-600">{metrics.lowStock} products</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Out of Stock:</span>
              <span className="font-bold text-rose-600">{metrics.outOfStock} products</span>
            </div>
          </div>
        </div>

        {/* Customer Accounts */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-600" />
              Territory Customers
            </h4>
            <button
              type="button"
              onClick={() => onNavigate('customers')}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              Manage
            </button>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Total Clients:</span>
              <span className="font-bold text-slate-900">{metrics.totalCustomers}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Active Accounts:</span>
              <span className="font-bold text-emerald-600">{metrics.activeCustomers}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Clients with Due:</span>
              <span className="font-bold text-amber-600">{metrics.customersWithDue}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. RECENT SALES & ORDERS TABLE FOR THIS STAFF */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-slate-800 text-sm">
              My Recent Sales Pipeline
            </h4>
            <p className="text-xs text-slate-400">Orders placed by your staff account</p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('sales')}
            className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
          >
            All Sales
          </button>
        </div>

        <div className="overflow-x-auto grow">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-500 font-bold">
              <tr className="border-b border-slate-100">
                <th className="px-6 py-3">Order / Inv</th>
                <th className="px-6 py-3">Customer & Area</th>
                <th className="px-6 py-3">Date</th>
                <th className="px-6 py-3">Grand Total</th>
                <th className="px-6 py-3">Paid / Due</th>
                <th className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="text-xs text-slate-600 divide-y divide-slate-100">
              {staffOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-slate-400">
                    No orders submitted yet
                  </td>
                </tr>
              ) : (
                staffOrders.slice(0, 6).map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-3.5 font-semibold text-slate-900">
                      <div>#{ord.orderId}</div>
                      {ord.invoiceNumber && (
                        <span className="text-[10px] text-blue-600 font-mono font-bold">
                          {ord.invoiceNumber}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-3.5">
                      <p className="font-medium text-slate-800">{ord.customerName}</p>
                      <p className="text-[10px] text-slate-400">{ord.areaName}</p>
                    </td>
                    <td className="px-6 py-3.5 text-slate-500">
                      {formatDateTime(ord.date || ord.createdAt)}
                    </td>
                    <td className="px-6 py-3.5 font-bold text-slate-800">
                      {formatCurrency(ord.grandTotal, currencySymbol)}
                    </td>
                    <td className="px-6 py-3.5">
                      <span className="text-emerald-600 font-medium">
                        Paid: {formatCurrency(ord.paidAmount, currencySymbol)}
                      </span>
                      <br />
                      <span className="text-rose-600 font-medium">
                        Due: {formatCurrency(ord.dueAmount, currencySymbol)}
                      </span>
                    </td>
                    <td className="px-6 py-3.5">
                      <StatusBadge status={ord.orderStatus} />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
