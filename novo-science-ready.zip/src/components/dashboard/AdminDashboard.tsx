import React, { useMemo } from 'react';
import {
  TrendingUp,
  DollarSign,
  ShoppingCart,
  CreditCard,
  Users,
  Package,
  AlertTriangle,
  Boxes,
  PieChart,
  Calendar,
  Layers,
  ArrowUpRight,
  ShieldAlert,
  Clock,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { Order, Customer, Product, Payment, Expense, ProductRequest, UserProfile, Area, SystemSettings } from '../../types';
import { StatCard } from '../common/StatCard';
import { DailySalesSummary } from './DailySalesSummary';
import { formatCurrency, formatDate, isDateInRange, getDateRange } from '../../utils/formatters';

interface AdminDashboardProps {
  orders: Order[];
  customers: Customer[];
  products: Product[];
  payments: Payment[];
  expenses: Expense[];
  productRequests: ProductRequest[];
  currentUser?: UserProfile;
  settings?: SystemSettings;
  staffMembers?: UserProfile[];
  areas?: Area[];
  onNavigateToTab?: (tab: any) => void;
  onNavigate?: (tab: any) => void;
  onOpenCreateOrder?: () => void;
  onViewOrderDetails?: (order: Order) => void;
  currencySymbol?: string;
  lowStockThreshold?: number;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  orders = [],
  customers = [],
  products = [],
  payments = [],
  expenses = [],
  productRequests = [],
  currentUser,
  settings,
  staffMembers = [],
  areas = [],
  onNavigateToTab,
  onNavigate,
  onOpenCreateOrder,
  onViewOrderDetails,
  currencySymbol = settings?.currency || '৳',
  lowStockThreshold = settings?.lowStockThreshold || 10,
}) => {
  const navigate = onNavigateToTab || onNavigate || (() => {});

  // Compute key metrics
  const metrics = useMemo(() => {
    const todayRange = getDateRange('today');
    const thisMonthRange = getDateRange('this_month');

    const safeOrders = orders || [];
    const safeCustomers = customers || [];
    const safeProducts = products || [];
    const safePayments = payments || [];
    const safeExpenses = expenses || [];
    const safeProductRequests = productRequests || [];

    // Approved orders count for verified revenue & profit
    const approvedOrders = safeOrders.filter((o) => o && o.orderStatus === 'APPROVED');
    
    // Sales
    const totalSales = approvedOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const todaySales = approvedOrders
      .filter((o) => isDateInRange(o.date || o.createdAt, todayRange))
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const todayOrdersCount = approvedOrders.filter((o) => isDateInRange(o.date || o.createdAt, todayRange)).length;
    const monthlySales = approvedOrders
      .filter((o) => isDateInRange(o.date || o.createdAt, thisMonthRange))
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    // Dues & Payments
    const totalPaid = approvedOrders.reduce((sum, o) => sum + (o.paidAmount || 0), 0);
    const totalDue = safeCustomers.reduce((sum, c) => sum + (c.currentDue || 0), 0);
    const dueAccountsCount = safeCustomers.filter((c) => (c.currentDue || 0) > 0).length;

    // Today's Collection
    const todayCollection = safePayments
      .filter((p) => isDateInRange(p.date || p.createdAt, todayRange))
      .reduce((sum, p) => sum + (p.amount || 0), 0);

    // Expenses & Profit calculation
    const totalExpenses = safeExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    let totalCost = 0;
    approvedOrders.forEach((o) => {
      if (o.items && Array.isArray(o.items)) {
        o.items.forEach((item) => {
          totalCost += (item.purchasePrice || 0) * (item.quantity || 0);
        });
      }
    });

    const grossProfit = totalSales - totalCost;
    const netProfit = grossProfit - totalExpenses;

    // Inventory status
    const lowStockItems = safeProducts.filter(
      (p) => p && p.currentStock > 0 && p.currentStock <= (p.minimumStock || lowStockThreshold)
    );
    const outOfStockItems = safeProducts.filter((p) => p && p.currentStock <= 0);

    // Pending counts
    const pendingOrders = safeOrders.filter((o) => o && o.orderStatus === 'PENDING');
    const pendingOrdersAmount = pendingOrders.reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const pendingRequestsCount = safeProductRequests.filter((r) => r && r.status === 'PENDING').length;

    return {
      todaySales,
      todayOrdersCount,
      monthlySales,
      totalSales,
      totalPaid,
      totalDue,
      dueAccountsCount,
      todayCollection,
      totalCustomers: customers.length,
      totalProducts: products.length,
      lowStockCount: lowStockItems.length,
      outOfStockCount: outOfStockItems.length,
      pendingOrdersCount: pendingOrders.length,
      pendingOrdersAmount,
      pendingRequestsCount,
      totalExpenses,
      grossProfit,
      netProfit,
    };
  }, [orders, customers, products, payments, expenses, productRequests, lowStockThreshold]);

  // Breakdown for Area Sales Performance
  const areaSalesBreakdown = useMemo(() => {
    const map: Record<string, { name: string; sales: number; ordersCount: number }> = {};
    (orders || [])
      .filter((o) => o && o.orderStatus === 'APPROVED')
      .forEach((o) => {
        const areaName = o.areaName || 'General Dhaka';
        if (!map[areaName]) map[areaName] = { name: areaName, sales: 0, ordersCount: 0 };
        map[areaName].sales += o.grandTotal || 0;
        map[areaName].ordersCount += 1;
      });
    return Object.values(map).sort((a, b) => b.sales - a.sales).slice(0, 5);
  }, [orders]);

  // Staff leaderboard
  const staffLeaderboard = useMemo(() => {
    const staffMap: Record<string, { name: string; sales: number; count: number }> = {};
    (orders || [])
      .filter((o) => o && o.orderStatus === 'APPROVED')
      .forEach((o) => {
        const staffName = o.staffName || 'Staff Member';
        if (!staffMap[staffName]) staffMap[staffName] = { name: staffName, sales: 0, count: 0 };
        staffMap[staffName].sales += o.grandTotal || 0;
        staffMap[staffName].count += 1;
      });
    return Object.values(staffMap).sort((a, b) => b.sales - a.sales).slice(0, 3);
  }, [orders]);

  // Recent Pipeline Orders
  const recentPipelineOrders = useMemo(() => {
    return [...(orders || [])].sort((a, b) => {
      const timeA = new Date(a.date || a.createdAt || 0).getTime();
      const timeB = new Date(b.date || b.createdAt || 0).getTime();
      return timeB - timeA;
    }).slice(0, 6);
  }, [orders]);

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">System Overview</h1>
          <p className="text-xs text-slate-500 mt-1">
            Enterprise sales, real-time inventory tracking, receivables & territory operations
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-white border border-slate-200 px-4 py-2 rounded-lg text-sm font-medium text-slate-600 shadow-sm flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>Today (Asia/Dhaka)</span>
          </div>
          {onOpenCreateOrder && (
            <button
              type="button"
              onClick={onOpenCreateOrder}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm font-bold text-white shadow-md transition-colors cursor-pointer"
            >
              + Create New Order
            </button>
          )}
        </div>
      </div>

      {/* Daily Sales Summary Spotlight */}
      <DailySalesSummary
        orders={orders}
        payments={payments}
        expenses={expenses}
        currencySymbol={currencySymbol}
        onNavigate={navigate}
        onOpenCreateOrder={onOpenCreateOrder}
      />

      {/* Row 1: Key Performance Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Today's Sales</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(metrics.todaySales, currencySymbol)}</p>
            <span className="text-xs text-green-500 font-bold mb-1">+12%</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Invoice Count: {metrics.todayOrdersCount} Orders</p>
        </div>

        <div
          onClick={() => navigate('orders')}
          className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md cursor-pointer hover:border-slate-300"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Pending Orders</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{metrics.pendingOrdersCount}</p>
            <span className="text-xs text-amber-500 font-bold mb-1">Action Required</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {formatCurrency(metrics.pendingOrdersAmount, currencySymbol)} Awaiting Approval
          </p>
        </div>

        <div
          onClick={() => navigate('due')}
          className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md cursor-pointer hover:border-slate-300"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Due</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(metrics.totalDue, currencySymbol)}</p>
            <span className="text-xs text-red-500 font-bold mb-1">{metrics.dueAccountsCount} Accounts</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Overdue Collection Alert</p>
        </div>

        <div
          onClick={() => navigate('inventory')}
          className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm transition-all hover:shadow-md cursor-pointer hover:border-slate-300"
        >
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Low Stock Alert</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-slate-900">
              {String(metrics.lowStockCount).padStart(2, '0')} SKUs
            </p>
            <span className="text-xs text-red-500 font-bold mb-1">Critical</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Reorder Threshold Reached</p>
        </div>
      </div>

      {/* Row 2: Financial Margin Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Gross Revenue"
          value={formatCurrency(metrics.totalSales, currencySymbol)}
          subtitle="Cumulative sales turnover"
          icon={TrendingUp}
          iconBgColor="bg-blue-50"
          iconColor="text-blue-600"
        />
        <StatCard
          title="Total Collected"
          value={formatCurrency(metrics.totalPaid, currencySymbol)}
          subtitle="Settled in cash & bank"
          icon={CreditCard}
          iconBgColor="bg-emerald-50"
          iconColor="text-emerald-600"
        />
        <StatCard
          title="Operating Expenses"
          value={formatCurrency(metrics.totalExpenses, currencySymbol)}
          subtitle="Rent, staff, transport & utility"
          icon={DollarSign}
          iconBgColor="bg-amber-50"
          iconColor="text-amber-600"
          onClick={() => navigate('expenses')}
        />
        <StatCard
          title="Net Profit"
          value={formatCurrency(metrics.netProfit, currencySymbol)}
          subtitle="Gross profit minus expenses"
          icon={PieChart}
          iconBgColor="bg-purple-50"
          iconColor="text-purple-600"
        />
      </div>

      {/* Row 3: Grid Layout with Recent Order Pipeline and Area Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        {/* Left Column (2 Cols): Recent Order Pipeline Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-bold text-slate-800 text-sm">Recent Order Pipeline</h2>
            <button
              type="button"
              onClick={() => navigate('orders')}
              className="text-xs text-blue-600 font-bold hover:underline cursor-pointer"
            >
              View All Orders
            </button>
          </div>

          <div className="overflow-x-auto grow">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-500 font-bold">
                <tr className="border-b border-slate-100">
                  <th className="px-6 py-3">Order ID</th>
                  <th className="px-6 py-3">Customer</th>
                  <th className="px-6 py-3">Area</th>
                  <th className="px-6 py-3">Amount</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="text-xs text-slate-600 divide-y divide-slate-100">
                {recentPipelineOrders.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-10 text-center text-slate-400">
                      No order records found in the pipeline
                    </td>
                  </tr>
                ) : (
                  recentPipelineOrders.map((order) => {
                    const isPending = order.orderStatus === 'PENDING';
                    const isApproved = order.orderStatus === 'APPROVED';
                    const isRejected = order.orderStatus === 'REJECTED';

                    return (
                      <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-3.5 font-semibold text-slate-900">
                          #{order.orderId}
                        </td>
                        <td className="px-6 py-3.5">
                          <p className="font-medium text-slate-800">{order.customerName}</p>
                          <p className="text-[10px] text-slate-400">{order.customerPhone}</p>
                        </td>
                        <td className="px-6 py-3.5">{order.areaName || 'Dhaka'}</td>
                        <td className="px-6 py-3.5 font-bold text-slate-800">
                          {formatCurrency(order.grandTotal, currencySymbol)}
                        </td>
                        <td className="px-6 py-3.5">
                          {isPending && (
                            <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px] font-bold">
                              PENDING
                            </span>
                          )}
                          {isApproved && (
                            <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-[10px] font-bold">
                              APPROVED
                            </span>
                          )}
                          {isRejected && (
                            <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px] font-bold">
                              REJECTED
                            </span>
                          )}
                          {!isPending && !isApproved && !isRejected && (
                            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-bold">
                              {order.orderStatus}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-3.5 text-right">
                          {onViewOrderDetails ? (
                            <button
                              type="button"
                              onClick={() => onViewOrderDetails(order)}
                              className="text-blue-600 font-bold hover:underline cursor-pointer"
                            >
                              {isPending ? 'Review' : 'Invoice'}
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => navigate('orders')}
                              className="text-blue-600 font-bold hover:underline cursor-pointer"
                            >
                              Details
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column (1 Col): Area Performance & Staff Leaderboard */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col">
          <div className="px-6 py-4 border-b border-slate-100">
            <h2 className="font-bold text-slate-800 text-sm">Area Performance</h2>
          </div>

          <div className="p-6 space-y-4 grow">
            {areaSalesBreakdown.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">No regional sales records available</p>
            ) : (
              areaSalesBreakdown.map((area) => {
                const maxSale = Math.max(...areaSalesBreakdown.map((a) => a.sales), 1);
                const percent = Math.min(Math.round((area.sales / maxSale) * 100), 100);

                return (
                  <div key={area.name} className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <span>{area.name}</span>
                      <span>{formatCurrency(area.sales, currencySymbol)}</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-blue-500 h-full rounded-full transition-all duration-300"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}

            {/* Staff Leaderboard */}
            <div className="mt-6 pt-6 border-t border-slate-100">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">
                Staff Leaderboard
              </p>
              <div className="space-y-3">
                {staffLeaderboard.length === 0 ? (
                  <p className="text-xs text-slate-400 py-2">No staff sales history</p>
                ) : (
                  staffLeaderboard.map((staff, idx) => (
                    <div key={staff.name} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs shrink-0">
                        {idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate">{staff.name}</p>
                        <p className="text-[10px] text-slate-400">
                          {staff.count} Orders &bull; {formatCurrency(staff.sales, currencySymbol)}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
