import React, { useState } from 'react';
import {
  Settings,
  Save,
  Receipt,
  CheckCircle2,
  DollarSign,
  Clock,
  Shield,
  Layers,
} from 'lucide-react';
import { SystemSettings, UserProfile } from '../../types';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { logActivity } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { isSuperAdminUser } from '../../permissions';

interface SettingsViewProps {
  settings: SystemSettings;
  currentUser: UserProfile;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ settings, currentUser }) => {
  const [formData, setFormData] = useState<SystemSettings>({ ...settings });
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canEditSettings = isSuperAdminUser(currentUser) || currentUser.role === 'admin';

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canEditSettings) return;

    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const settingsRef = doc(db, 'settings', 'global');
      const { lastInvoiceNumber: _counter, ...toSave } = formData;
      await setDoc(settingsRef, toSave, { merge: true });

      await logActivity({
        userId: currentUser.uid,
        userName: currentUser.name,
        action: 'SETTINGS_UPDATED',
        module: 'settings',
        recordId: 'global',
        newData: formData,
      });

      setSuccessMessage('সিস্টেম সেটিংস সফলভাবে সংরক্ষিত হয়েছে (Settings successfully saved)');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            সিস্টেম কনফিগারেশন সেটিংস (System Settings)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Business profiles, invoice numbering templates, currency and tax defaults, and automation rules.
          </p>
        </div>

        {canEditSettings && (
          <button
            type="button"
            disabled={loading}
            onClick={handleSave}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            {loading ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সংরক্ষণ করুন (Save)'}
          </button>
        )}
      </div>

      {successMessage && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl flex items-center gap-2 text-xs">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs">
          {error}
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* SECTION: BILLING & FORMATTING */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
            <Receipt className="w-4 h-4 text-slate-600" />
            চালান প্রিফিক্স ও মুদ্রা ফরম্যাটিং (Invoice Prefix & Financial Defaults)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">মুদ্রা প্রতীক (Currency Symbol)</label>
              <input
                type="text"
                disabled={!canEditSettings}
                value={formData.currencySymbol}
                onChange={(e) => setFormData({ ...formData, currencySymbol: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">ইনভয়েস প্রিফিক্স (Invoice Prefix)</label>
              <input
                type="text"
                disabled={!canEditSettings}
                value={formData.invoicePrefix}
                onChange={(e) => setFormData({ ...formData, invoicePrefix: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">অর্ডার প্রিফিক্স (Order Prefix)</label>
              <input
                type="text"
                disabled={!canEditSettings}
                value={formData.orderPrefix}
                onChange={(e) => setFormData({ ...formData, orderPrefix: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">ডিফল্ট ভ্যাট / ট্যাক্স (VAT %)</label>
              <input
                type="number"
                min="0"
                max="100"
                step="0.1"
                disabled={!canEditSettings}
                value={formData.taxRate}
                onChange={(e) => setFormData({ ...formData, taxRate: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">ন্যূনতম নিরাপত্তা স্টক ডিফল্ট</label>
              <input
                type="number"
                min="1"
                disabled={!canEditSettings}
                value={formData.lowStockThreshold}
                onChange={(e) => setFormData({ ...formData, lowStockThreshold: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">টাইমজোন (Timezone)</label>
              <input
                type="text"
                disabled
                value="Asia/Dhaka (GMT+6)"
                className="w-full px-3 py-2 border border-slate-200 bg-slate-50 rounded-lg text-xs font-medium text-slate-600"
              />
            </div>
          </div>
        </div>

        {/* SECTION 3: AUTOMATION RULES */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
            <Shield className="w-4 h-4 text-slate-600" />
            অটোমেশন ও পলিসি রুলস (Automation & Business Rules)
          </h3>

          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
              <div>
                <p className="font-bold text-slate-800">অর্ডার অনুমোদনে স্বয়ংক্রিয় স্টক কর্তন (Auto Stock Deduction)</p>
                <p className="text-[11px] text-slate-500">
                  When an order is approved, deduct inventory quantities immediately from warehouse.
                </p>
              </div>
              <input
                type="checkbox"
                disabled={!canEditSettings}
                checked={formData.autoStockDeduction}
                onChange={(e) => setFormData({ ...formData, autoStockDeduction: e.target.checked })}
                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
              <div>
                <p className="font-bold text-slate-800">আংশিক পেমেন্ট ও বাকি অর্ডার অনুমোদন (Allow Partial Payments)</p>
                <p className="text-[11px] text-slate-500">
                  Allow sales orders to be confirmed with Partial or Due payments within customer credit limit.
                </p>
              </div>
              <input
                type="checkbox"
                disabled={!canEditSettings}
                checked={formData.allowPartialPayments}
                onChange={(e) => setFormData({ ...formData, allowPartialPayments: e.target.checked })}
                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>
          </div>
        </div>
      </form>
    </div>
  );
};
