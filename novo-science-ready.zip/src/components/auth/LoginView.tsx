import React, { useState } from 'react';
import { Lock, User as UserIcon, AlertCircle, ArrowRight, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuth } from '../../services/authContext';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { CompanyBrandHeader } from '../common/CompanyBrandHeader';

const SAVED_USERNAME_KEY = 'novo_saved_username';

const readSavedUsername = () => {
  try {
    return localStorage.getItem(SAVED_USERNAME_KEY) || '';
  } catch {
    return '';
  }
};

export const LoginView: React.FC = () => {
  const { login, statusError } = useAuth();

  const [username, setUsername] = useState(readSavedUsername);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const friendly = (err: any) => {
    const msg = String(err?.code || err?.message || '');
    if (msg.includes('auth/invalid-credential') || msg.includes('auth/user-not-found') || msg.includes('auth/wrong-password')) {
      return 'ইউজার নাম বা পাসওয়ার্ড ভুল।';
    }
    if (err?.message && !msg.includes('auth/') && !msg.includes('firestore')) return err.message;
    return getFriendlyErrorMessage(err);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(username, password);
      try {
        localStorage.setItem(SAVED_USERNAME_KEY, username.trim().toLowerCase());
      } catch {
        /* ignore */
      }
    } catch (err: any) {
      console.error(err);
      setError(friendly(err));
    } finally {
      setBusy(false);
    }
  };

  const message = error || statusError;

  return (
    <div className="min-h-dvh bg-slate-900 flex items-center justify-center p-4 safe-top safe-bottom relative overflow-hidden">
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 sm:p-10 relative z-10 space-y-5">
        <CompanyBrandHeader variant="login" />
        <p className="text-center text-sm text-slate-500 -mt-2">
          ইউজার নাম ও পাসওয়ার্ড দিয়ে লগইন করুন
        </p>

        {message && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-sm flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{message}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="font-bold text-slate-700 text-sm block mb-1.5">ইউজার নাম</span>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="যেমন: rashed"
                className="w-full pl-10 pr-3 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none"
              />
            </div>
          </label>

          <label className="block">
            <span className="font-bold text-slate-700 text-sm block mb-1.5">পাসওয়ার্ড</span>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-11 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </label>

          <button
            type="submit"
            disabled={busy}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {busy ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>অপেক্ষা করুন...</span>
              </>
            ) : (
              <>
                <span>লগইন করুন</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="text-center">
          <p className="text-[11px] text-slate-400">
            অ্যাকাউন্ট না থাকলে আপনার অ্যাডমিনের সাথে যোগাযোগ করুন।
          </p>
        </div>
      </div>
    </div>
  );
};
