import React, { useState } from 'react';
import {
  MapPin,
  Plus,
  Search,
  Edit2,
  Trash2,
  Users,
  Building,
} from 'lucide-react';
import { Area, Customer, UserProfile, SystemSettings } from '../../types';
import { Modal } from '../common/Modal';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { logActivity, softDeleteRecord } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { getNowISO, generateId } from '../../utils/formatters';
import { isSuperAdminUser } from '../../permissions';

interface AreasViewProps {
  areas: Area[];
  customers: Customer[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

const BANGLADESH_DIVISIONS = [
  'Dhaka',
  'Chittagong',
  'Sylhet',
  'Rajshahi',
  'Khulna',
  'Barisal',
  'Rangpur',
  'Mymensingh',
];

export const AreasView: React.FC<AreasViewProps> = ({
  areas = [],
  customers = [],
  currentUser,
  settings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [divisionFilter, setDivisionFilter] = useState('ALL');

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<Area | null>(null);
  const [areaToDelete, setAreaToDelete] = useState<Area | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    division: BANGLADESH_DIVISIONS[0],
    description: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canManage = isSuperAdminUser(currentUser) || currentUser.role === 'admin';

  const filteredAreas = areas.filter((a) => {
    if (divisionFilter !== 'ALL' && a.division !== divisionFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return a.name.toLowerCase().includes(q) || a.division.toLowerCase().includes(q);
    }
    return true;
  });

  const handleOpenCreate = () => {
    setFormData({
      name: '',
      division: BANGLADESH_DIVISIONS[0],
      description: '',
    });
    setError(null);
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (a: Area) => {
    setEditingArea(a);
    setFormData({
      name: a.name,
      division: a.division,
      description: a.description || '',
    });
    setError(null);
  };

  const handleSaveArea = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim()) {
      setError('এলাকার নাম আবশ্যক');
      return;
    }

    setLoading(true);
    try {
      const now = getNowISO();

      if (editingArea) {
        const areaRef = doc(db, 'areas', editingArea.id);
        const updated: Partial<Area> = {
          name: formData.name.trim(),
          division: formData.division,
          description: formData.description.trim(),
          updatedAt: now,
        };

        await updateDoc(areaRef, updated);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'AREA_UPDATED',
          module: 'areas',
          recordId: editingArea.id,
          newData: updated,
        });

        setEditingArea(null);
      } else {
        const areaId = generateId('AREA');
        const areaRef = doc(db, 'areas', areaId);
        const newArea: Area = {
          id: areaId,
          areaId,
          name: formData.name.trim(),
          division: formData.division,
          description: formData.description.trim(),
          status: 'active',
          assignedStaff: [],
          createdAt: now,
        };

        await setDoc(areaRef, newArea);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'AREA_CREATED',
          module: 'areas',
          recordId: areaId,
          newData: newArea,
        });

        setIsCreateOpen(false);
      }
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!areaToDelete) return;
    setLoading(true);
    try {
      await softDeleteRecord({
        collectionName: 'areas',
        recordId: areaToDelete.id,
        deleteReason: deleteReason || 'Deleted by admin',
        user: currentUser,
      });
      setAreaToDelete(null);
      setDeleteReason('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            এলাকা ও টেরিটরি ব্যবস্থাপনা (Territory Management)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Geographic sales routes, division assignments, and distribution zones.
          </p>
        </div>

        {canManage && (
          <button
            type="button"
            onClick={handleOpenCreate}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            নতুন এলাকা যোগ করুন (Add Area)
          </button>
        )}
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search area name or division..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <select
            value={divisionFilter}
            onChange={(e) => setDivisionFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Divisions (সব বিভাগ)</option>
            {BANGLADESH_DIVISIONS.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Areas Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filteredAreas.map((area) => {
          const custCount = customers.filter((c) => c.areaId === area.id).length;
          const areaDue = customers
            .filter((c) => c.areaId === area.id)
            .reduce((sum, c) => sum + (c.currentDue || 0), 0);

          return (
            <div
              key={area.id}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    {area.name}
                  </h3>
                  <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded mt-1 inline-block">
                    {area.division} Division
                  </span>
                </div>

                {canManage && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(area)}
                      className="p-1 text-slate-400 hover:text-blue-600 rounded hover:bg-slate-100"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setAreaToDelete(area)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {area.description && (
                <p className="text-xs text-slate-500 line-clamp-2">{area.description}</p>
              )}

              <div className="border-t border-slate-100 pt-3 flex justify-between items-center text-xs">
                <span className="text-slate-500 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  {custCount} Customers
                </span>
                <span className="font-mono font-bold text-rose-600">
                  {settings.currencySymbol || '৳'}{areaDue.toLocaleString()} Due
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* CREATE / EDIT MODAL */}
      {(isCreateOpen || editingArea) && (
        <Modal
          isOpen={true}
          onClose={() => {
            setIsCreateOpen(false);
            setEditingArea(null);
          }}
          title={editingArea ? 'এলাকা সম্পাদনা (Edit Area)' : 'নতুন এলাকা যুক্ত করুন (Add Area)'}
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => {
                  setIsCreateOpen(false);
                  setEditingArea(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleSaveArea}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                {loading ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleSaveArea} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">এলাকার নাম (Area Name)*</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="যেমন: মিরপুর / চকবাজার / আগ্রাবাদ"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">বিভাগ (Division)*</label>
              <select
                value={formData.division}
                onChange={(e) => setFormData({ ...formData, division: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
              >
                {BANGLADESH_DIVISIONS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">বিবরণ / রুট গাইড</label>
              <textarea
                rows={2}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="এলাকা বা বিতরণ রুটের বর্ণনা..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}

      {/* DELETE MODAL */}
      {areaToDelete && (
        <Modal
          isOpen={true}
          onClose={() => setAreaToDelete(null)}
          title="এলাকা ডিলিট নিশ্চিতকরণ"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setAreaToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleDeleteConfirm}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                {loading ? 'মুছে ফেলা হচ্ছে...' : 'ডিলিট করুন'}
              </button>
            </>
          }
        >
          <div className="space-y-3 text-xs">
            <p className="text-slate-600">
              আপনি কি নিশ্চিত যে <span className="font-bold text-slate-900">{areaToDelete.name}</span> এলাকাটি ডিলিট করতে চান?
            </p>
            <div>
              <label className="font-bold text-slate-700 block mb-1">ডিলিট করার কারণ*</label>
              <textarea
                rows={2}
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="কারণ লিখুন..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
