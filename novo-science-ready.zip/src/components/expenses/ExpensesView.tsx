import React, { useState, useMemo } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Filter,
  Trash2,
  Edit2,
  DollarSign,
  FileSpreadsheet,
  Calendar,
  PieChart,
} from 'lucide-react';
import { Expense, UserProfile, SystemSettings, PaymentMethod } from '../../types';
import { Modal } from '../common/Modal';
import { EmptyState } from '../common/EmptyState';
import { formatCurrency, formatDate, getNowISO, generateId } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { checkPermission } from '../../permissions';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { logActivity, softDeleteRecord } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';

interface ExpensesViewProps {
  expenses: Expense[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

const EXPENSE_CATEGORIES = [
  'Office Rent',
  'Utilities (Electricity, Internet, Water)',
  'Staff Conveyance / TA-DA',
  'Salaries & Allowances',
  'Packaging & Delivery',
  'Office Stationery & Supplies',
  'Repairs & Maintenance',
  'Marketing & Promotions',
  'Miscellaneous',
];

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses = [],
  currentUser,
  settings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  // Create / Edit modal
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    category: EXPENSE_CATEGORIES[0],
    amount: 0,
    paymentMethod: 'Cash' as PaymentMethod,
    referenceNumber: '',
    recipient: '',
    note: '',
    date: new Date().toISOString().split('T')[0],
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canCreate = checkPermission(currentUser, 'expense.create');
  const canEdit = checkPermission(currentUser, 'expense.edit');
  const canDelete = checkPermission(currentUser, 'expense.delete');

  const currencySymbol = settings.currencySymbol || '৳';

  // Filtered Expenses
  const filteredExpenses = useMemo(() => {
    let list = expenses;

    if (categoryFilter !== 'ALL') {
      list = list.filter((e) => e.category === categoryFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (e) =>
          e.title.toLowerCase().includes(q) ||
          e.category.toLowerCase().includes(q) ||
          (e.recipient && e.recipient.toLowerCase().includes(q)) ||
          (e.referenceNumber && e.referenceNumber.toLowerCase().includes(q))
      );
    }

    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenses, categoryFilter, searchQuery]);

  // Aggregate stats
  const totalAmount = useMemo(() => {
    return filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  }, [filteredExpenses]);

  const currentMonthTotal = useMemo(() => {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
    return expenses
      .filter((e) => (e.date || '').startsWith(currentMonth))
      .reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const handleOpenCreate = () => {
    setFormData({
      title: '',
      category: EXPENSE_CATEGORIES[0],
      amount: 0,
      paymentMethod: 'Cash',
      referenceNumber: `EXP-${Date.now().toString().slice(-4)}`,
      recipient: '',
      note: '',
      date: new Date().toISOString().split('T')[0],
    });
    setError(null);
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (exp: Expense) => {
    setEditingExpense(exp);
    setFormData({
      title: exp.title,
      category: exp.category,
      amount: exp.amount,
      paymentMethod: exp.paymentMethod,
      referenceNumber: exp.referenceNumber || '',
      recipient: exp.recipient || '',
      note: exp.note || '',
      date: exp.date.split('T')[0],
    });
    setError(null);
  };

  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.title.trim() || formData.amount <= 0) {
      setError('শিরোনাম এবং খরচের পরিমাণ সঠিক প্রদান করুন');
      return;
    }

    setLoading(true);
    try {
      const now = getNowISO();

      if (editingExpense) {
        const expRef = doc(db, 'expenses', editingExpense.id);
        const updated: Partial<Expense> = {
          title: formData.title.trim(),
          category: formData.category,
          amount: Number(formData.amount),
          paymentMethod: formData.paymentMethod,
          referenceNumber: formData.referenceNumber.trim(),
          recipient: formData.recipient.trim(),
          note: formData.note.trim(),
          date: formData.date,
          updatedAt: now,
        };

        await updateDoc(expRef, updated);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'EXPENSE_UPDATED',
          module: 'expenses',
          recordId: editingExpense.id,
          newData: updated,
        });

        setEditingExpense(null);
      } else {
        const expId = generateId('EXP');
        const expRef = doc(db, 'expenses', expId);
        const newExpense: Expense = {
          id: expId,
          expenseId: expId,
          title: formData.title.trim(),
          description: formData.title.trim(),
          category: formData.category,
          amount: Number(formData.amount),
          paymentMethod: formData.paymentMethod,
          referenceNumber: formData.referenceNumber.trim(),
          recipient: formData.recipient.trim(),
          note: formData.note.trim(),
          date: formData.date,
          addedBy: currentUser.uid,
          addedByName: currentUser.name,
          createdBy: currentUser.uid,
          createdByName: currentUser.name,
          createdAt: now,
        };

        await setDoc(expRef, newExpense);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'EXPENSE_CREATED',
          module: 'expenses',
          recordId: expId,
          newData: newExpense,
        });

        setIsCreateOpen(false);
      }
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!expenseToDelete) return;
    setLoading(true);
    try {
      await softDeleteRecord({
        collectionName: 'expenses',
        recordId: expenseToDelete.id,
        deleteReason: deleteReason || 'Deleted by admin',
        user: currentUser,
      });
      setExpenseToDelete(null);
      setDeleteReason('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    const data = filteredExpenses.map((e) => ({
      'Expense ID': e.id,
      Date: formatDate(e.date),
      Title: e.title,
      Category: e.category,
      Amount: e.amount,
      'Payment Method': e.paymentMethod,
      Recipient: e.recipient || '',
      Reference: e.referenceNumber || '',
      'Created By': e.createdByName,
      Note: e.note || '',
    }));
    exportToCSV(data, 'Expenses_Log_Export');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Receipt className="w-5 h-5 text-rose-600" />
            ব্যবসায়িক ব্যয় ট্র্যাকিং (Operational Expenses)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Log overhead costs, office utilities, staff conveyance, and operational vouchers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>

          {canCreate && (
            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              নতুন খরচ এন্ট্রি (Add Expense)
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Filtered Total Expense</p>
          <p className="text-2xl font-bold text-rose-600 font-mono mt-1">
            {formatCurrency(totalAmount, currencySymbol)}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">This Month Expenses</p>
          <p className="text-2xl font-bold text-slate-900 font-mono mt-1">
            {formatCurrency(currentMonthTotal, currencySymbol)}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Total Entries</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{filteredExpenses.length}</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search title, recipient, voucher #..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Expense Categories</option>
            {EXPENSE_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Expense Title & Voucher</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Paid To / Recipient</th>
                <th className="px-4 py-3">Method</th>
                <th className="px-4 py-3 text-right">Amount</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan={7}>
                    <EmptyState
                      title="কোনো খরচের রেকর্ড পাওয়া যায়নি"
                      description="No expense vouchers matching your criteria."
                      actionText={canCreate ? 'নতুন খরচ যোগ করুন' : undefined}
                      onAction={canCreate ? handleOpenCreate : undefined}
                    />
                  </td>
                </tr>
              ) : (
                filteredExpenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 text-slate-500 font-mono">{formatDate(exp.date)}</td>

                    <td className="px-4 py-3 font-semibold text-slate-900">
                      <div>{exp.title}</div>
                      {exp.referenceNumber && (
                        <span className="text-[10px] text-slate-400 font-mono font-normal">
                          Voucher: {exp.referenceNumber}
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-slate-600 font-medium">{exp.category}</td>

                    <td className="px-4 py-3 text-slate-700">{exp.recipient || 'N/A'}</td>

                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {exp.paymentMethod}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-right font-mono font-bold text-rose-600 text-sm">
                      {formatCurrency(exp.amount, currencySymbol)}
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {canEdit && (
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(exp)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-100 transition-colors"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => setExpenseToDelete(exp)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT EXPENSE MODAL */}
      {(isCreateOpen || editingExpense) && (
        <Modal
          isOpen={true}
          onClose={() => {
            setIsCreateOpen(false);
            setEditingExpense(null);
          }}
          title={editingExpense ? 'খরচ সংশোধন (Edit Expense)' : 'নতুন খরচ এন্ট্রি (Add Expense)'}
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => {
                  setIsCreateOpen(false);
                  setEditingExpense(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleSaveExpense}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                {loading ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handleSaveExpense} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">খরচের শিরোনাম (Title)*</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="যেমন: জানুয়ারি মাসের বিদ্যুৎ বিল"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">ক্যাটাগরি*</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  {EXPENSE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">টাকার পরিমাণ (Amount - ৳)*</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold font-mono text-rose-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">পেমেন্ট মাধ্যম*</label>
                <select
                  value={formData.paymentMethod}
                  onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  <option value="Cash">Cash (নগদ)</option>
                  <option value="bKash">bKash (বিকাশ)</option>
                  <option value="Nagad">Nagad (নগদ)</option>
                  <option value="Bank">Bank Transfer (ব্যাংক)</option>
                  <option value="Cheque">Cheque (চেক)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">তারিখ*</label>
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">ভাউচার / স্লিপ নম্বর</label>
                <input
                  type="text"
                  value={formData.referenceNumber}
                  onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">প্রাপক / Paid To</label>
                <input
                  type="text"
                  value={formData.recipient}
                  onChange={(e) => setFormData({ ...formData, recipient: e.target.value })}
                  placeholder="যেমন: ডেসকো / পিকআপ চালক"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">মন্তব্য / বিবরণ</label>
              <textarea
                rows={2}
                value={formData.note}
                onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                placeholder="অতিরিক্ত বিস্তারিত বিবরণ..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}

      {/* DELETE MODAL */}
      {expenseToDelete && (
        <Modal
          isOpen={true}
          onClose={() => setExpenseToDelete(null)}
          title="খরচ ডিলিট নিশ্চিতকরণ"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setExpenseToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleDeleteConfirm}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                {loading ? 'মুছে ফেলা হচ্ছে...' : 'ডিলিট করুন'}
              </button>
            </>
          }
        >
          <div className="space-y-3 text-xs">
            <p className="text-slate-600">
              আপনি কি নিশ্চিত যে <span className="font-bold text-slate-900">{expenseToDelete.title}</span> ({formatCurrency(expenseToDelete.amount, currencySymbol)}) খরচের ভাউচারটি ডিলিট করতে চান?
            </p>
            <div>
              <label className="font-bold text-slate-700 block mb-1">ডিলিট করার কারণ*</label>
              <textarea
                rows={2}
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="ডিলিট করার কারণ..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
