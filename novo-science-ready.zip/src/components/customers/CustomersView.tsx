import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Filter,
  CreditCard,
  Edit2,
  Trash2,
  Phone,
  MapPin,
  FileSpreadsheet,
  AlertCircle,
  Eye,
  CheckCircle,
} from 'lucide-react';
import { Customer, Area, UserProfile, SystemSettings, PaymentMethod } from '../../types';
import { Modal } from '../common/Modal';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { EmptyState } from '../common/EmptyState';
import { formatCurrency, formatDate, getNowISO, generateId } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { checkPermission } from '../../permissions';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { logActivity, softDeleteRecord, recordPaymentCollection } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';

interface CustomersViewProps {
  customers: Customer[];
  areas: Area[];
  currentUser: UserProfile;
  settings: SystemSettings;
  onOpenCollectDue?: (customer: Customer) => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  customers = [],
  areas = [],
  currentUser,
  settings,
  onOpenCollectDue,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [areaFilter, setAreaFilter] = useState('ALL');
  const [dueFilter, setDueFilter] = useState<'ALL' | 'HAS_DUE' | 'NO_DUE'>('ALL');

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  // Collect Due inline modal
  const [collectingCustomer, setCollectingCustomer] = useState<Customer | null>(null);
  const [collectAmount, setCollectAmount] = useState<number>(0);
  const [collectMethod, setCollectMethod] = useState<PaymentMethod>('Cash');
  const [collectReference, setCollectReference] = useState('');
  const [collectNote, setCollectNote] = useState('');

  // Form fields
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    phone: '',
    email: '',
    areaId: '',
    address: '',
    creditLimit: 50000,
    openingDue: 0,
    status: 'active' as Customer['status'],
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canCreate = checkPermission(currentUser, 'customer.create');
  const canEdit = checkPermission(currentUser, 'customer.edit');
  const canDelete = checkPermission(currentUser, 'customer.delete');
  const canCollectDue = checkPermission(currentUser, 'customer.collectDue');

  const currencySymbol = settings.currencySymbol || '৳';

  // Area Map
  const areaMap = useMemo(() => {
    const map: Record<string, Area> = {};
    areas.forEach((a) => {
      map[a.id] = a;
    });
    return map;
  }, [areas]);

  // Filtered Customers
  const filteredCustomers = useMemo(() => {
    let list = customers;

    // Staff Area scoping
    if (currentUser.role === 'staff' && !currentUser.permissions?.VIEW_ALL_AREAS) {
      list = list.filter(
        (c) =>
          (currentUser.assignedAreas && currentUser.assignedAreas.includes(c.areaId)) ||
          c.createdBy === currentUser.uid
      );
    }

    if (areaFilter !== 'ALL') {
      list = list.filter((c) => c.areaId === areaFilter);
    }

    if (dueFilter === 'HAS_DUE') {
      list = list.filter((c) => (c.currentDue || 0) > 0);
    } else if (dueFilter === 'NO_DUE') {
      list = list.filter((c) => (c.currentDue || 0) <= 0);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.businessName && c.businessName.toLowerCase().includes(q)) ||
          c.phone.includes(q) ||
          (c.address && c.address.toLowerCase().includes(q))
      );
    }

    return list.sort((a, b) => (b.currentDue || 0) - (a.currentDue || 0));
  }, [customers, areaFilter, dueFilter, searchQuery, currentUser]);

  const totalDueAmount = useMemo(() => {
    return filteredCustomers.reduce((sum, c) => sum + (c.currentDue || 0), 0);
  }, [filteredCustomers]);

  const handleOpenCreate = () => {
    setFormData({
      name: '',
      businessName: '',
      phone: '',
      email: '',
      areaId: areas[0]?.id || '',
      address: '',
      creditLimit: 50000,
      openingDue: 0,
      status: 'active',
    });
    setError(null);
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (c: Customer) => {
    if (!canEdit) {
      setError('আপনার কাস্টমার তথ্য সম্পাদনা করার অনুমতি নেই।');
      return;
    }
    setEditingCustomer(c);
    setFormData({
      name: c.name,
      businessName: c.businessName || '',
      phone: c.phone,
      email: c.email || '',
      areaId: c.areaId,
      address: c.address,
      creditLimit: c.creditLimit || 50000,
      openingDue: c.openingDue || 0,
      status: c.status,
    });
    setError(null);
  };

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!editingCustomer && !canCreate) {
      setError('আপনার নতুন কাস্টমার যুক্ত করার অনুমতি নেই। অনুগ্রহ করে সুপার অ্যাডমিনের অনুমতি গ্রহণ করুন।');
      return;
    }

    if (!formData.name.trim() || !formData.phone.trim() || !formData.areaId) {
      setError('নাম, মোবাইল নম্বর এবং এলাকা আবশ্যক (Name, phone, and area are required)');
      return;
    }

    setLoading(true);
    try {
      const now = getNowISO();
      const area = areaMap[formData.areaId];
      const areaName = area ? area.name : 'Unknown';

      if (editingCustomer) {
        const custRef = doc(db, 'customers', editingCustomer.id);
        const updated: Partial<Customer> = {
          name: formData.name.trim(),
          businessName: formData.businessName.trim(),
          phone: formData.phone.trim(),
          email: formData.email.trim(),
          areaId: formData.areaId,
          areaName,
          address: formData.address.trim(),
          creditLimit: Number(formData.creditLimit) || 0,
          status: formData.status,
          updatedAt: now,
        };

        await updateDoc(custRef, updated);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'CUSTOMER_UPDATED',
          module: 'customers',
          recordId: editingCustomer.id,
          newData: updated,
        });

        setEditingCustomer(null);
      } else {
        const custId = generateId('CUST');
        const custRef = doc(db, 'customers', custId);
        const newCustomer: Customer = {
          id: custId,
          customerId: custId,
          name: formData.name.trim(),
          businessName: formData.businessName.trim(),
          phone: formData.phone.trim(),
          email: formData.email.trim(),
          areaId: formData.areaId,
          areaName,
          address: formData.address.trim(),
          creditLimit: Number(formData.creditLimit) || 0,
          currentDue: Number(formData.openingDue) || 0,
          openingDue: Number(formData.openingDue) || 0,
          totalPurchases: 0,
          totalPaid: 0,
          status: formData.status,
          createdBy: currentUser.uid,
          createdAt: now,
        };

        await setDoc(custRef, newCustomer);
        await logActivity({
          userId: currentUser.uid,
          userName: currentUser.name,
          action: 'CUSTOMER_CREATED',
          module: 'customers',
          recordId: custId,
          newData: newCustomer,
        });

        setIsCreateOpen(false);
      }
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!customerToDelete) return;
    setLoading(true);
    try {
      await softDeleteRecord({
        collectionName: 'customers',
        recordId: customerToDelete.id,
        deleteReason: deleteReason || 'Deleted by authorized staff/admin',
        user: currentUser,
      });
      setCustomerToDelete(null);
      setDeleteReason('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  // Submit Due collection
  const handleCollectDueSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectingCustomer) return;
    if (collectAmount <= 0) {
      setError('পেমেন্টের পরিমাণ শূন্যের বেশি হতে হবে (Amount must be greater than zero)');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await recordPaymentCollection({
        customerId: collectingCustomer.id,
        amount: Number(collectAmount),
        method: collectMethod,
        reference: collectReference,
        note: collectNote,
        user: currentUser,
      });
      setCollectingCustomer(null);
      setCollectAmount(0);
      setCollectReference('');
      setCollectNote('');
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    const data = filteredCustomers.map((c) => ({
      'Customer ID': c.customerId,
      Name: c.name,
      Business: c.businessName || '',
      Phone: c.phone,
      Email: c.email || '',
      Area: c.areaName,
      Address: c.address,
      'Current Due': c.currentDue,
      'Total Purchases': c.totalPurchases || 0,
      'Total Paid': c.totalPaid || 0,
      'Credit Limit': c.creditLimit || 0,
      Status: c.status,
    }));
    exportToCSV(data, 'Customers_List_Export');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            গ্রাহক ও পার্টি তথ্য (Customer Management)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Registered distributors, retailers, territory mappings, and credit ledger monitoring.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>

          {canCreate && (
            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              নতুন কাস্টমার (Add Customer)
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Total Customers</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{filteredCustomers.length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Customers with Due</p>
          <p className="text-xl font-bold text-amber-600 mt-1">
            {filteredCustomers.filter((c) => (c.currentDue || 0) > 0).length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Total Due Outstanding</p>
          <p className="text-xl font-bold text-rose-600 mt-1">
            {formatCurrency(totalDueAmount, currencySymbol)}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Active Accounts</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">
            {filteredCustomers.filter((c) => c.status === 'active').length}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Name, Business, Phone, Area..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <select
            value={areaFilter}
            onChange={(e) => setAreaFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Territories (সব এলাকা)</option>
            {areas.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name} ({a.division})
              </option>
            ))}
          </select>

          <select
            value={dueFilter}
            onChange={(e) => setDueFilter(e.target.value as any)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Due Statuses</option>
            <option value="HAS_DUE">বাকি আছে (Has Due)</option>
            <option value="NO_DUE">বাকি নেই (No Due / Clear)</option>
          </select>
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Customer Name</th>
                <th className="px-4 py-3">Contact & Phone</th>
                <th className="px-4 py-3">Territory</th>
                <th className="px-4 py-3 text-right">Current Due</th>
                <th className="px-4 py-3 text-right">Total Purchases</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7}>
                    <EmptyState
                      title="কোনো কাস্টমার পাওয়া যায়নি (No customers found)"
                      description="No records matched your search or filters."
                      actionText={canCreate ? 'নতুন কাস্টমার যোগ করুন' : undefined}
                      onAction={canCreate ? handleOpenCreate : undefined}
                    />
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => (
                  <tr key={cust.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-bold text-slate-900">{cust.name}</p>
                      {cust.businessName && (
                        <p className="text-[11px] text-slate-500">{cust.businessName}</p>
                      )}
                    </td>

                    <td className="px-4 py-3">
                      <p className="font-semibold text-slate-800 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {cust.phone}
                      </p>
                      {cust.address && <p className="text-[11px] text-slate-400 truncate max-w-xs">{cust.address}</p>}
                    </td>

                    <td className="px-4 py-3">
                      <span className="font-medium text-slate-700 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {cust.areaName}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-right font-mono font-bold">
                      <span className={(cust.currentDue || 0) > 0 ? 'text-rose-600' : 'text-emerald-600'}>
                        {formatCurrency(cust.currentDue || 0, currencySymbol)}
                      </span>
                      {(cust.currentDue || 0) > 0 && (cust.dueStaffName || cust.salesStaffName) && (
                        <div className="text-[10px] text-blue-700 font-sans font-medium mt-0.5">
                          স্টাফ: {cust.dueStaffName || cust.salesStaffName}
                        </div>
                      )}
                    </td>

                    <td className="px-4 py-3 text-right font-mono text-slate-700">
                      {formatCurrency(cust.totalPurchases || 0, currencySymbol)}
                    </td>

                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          cust.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {cust.status}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Collect Due Button */}
                        {(cust.currentDue || 0) > 0 && canCollectDue && (
                          <button
                            type="button"
                            onClick={() => {
                              setCollectingCustomer(cust);
                              setCollectAmount(cust.currentDue || 0);
                            }}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <CreditCard className="w-3 h-3" />
                            বাকি আদায়
                          </button>
                        )}

                        {/* View Details */}
                        <button
                          type="button"
                          onClick={() => setViewingCustomer(cust)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                          title="বিস্তারিত"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Edit */}
                        {canEdit && (
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(cust)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-100 transition-colors"
                            title="এডিট"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}

                        {/* Delete */}
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => setCustomerToDelete(cust)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT CUSTOMER MODAL */}
      {(isCreateOpen || editingCustomer) && (
        <Modal
          isOpen={true}
          onClose={() => {
            setIsCreateOpen(false);
            setEditingCustomer(null);
          }}
          title={editingCustomer ? 'কাস্টমার তথ্য সংশোধন (Edit Customer)' : 'নতুন কাস্টমার নিবন্ধন (Add Customer)'}
          maxWidth="lg"
          footer={
            <>
              <button
                type="button"
                onClick={() => {
                  setIsCreateOpen(false);
                  setEditingCustomer(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleSaveCustomer}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5"
              >
                {loading ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন (Save)'}
              </button>
            </>
          }
        >
          <form onSubmit={handleSaveCustomer} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">কাস্টমারের নাম (Customer Name)*</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="যেমন: হাজী মোঃ রহিম"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">প্রতিষ্ঠানের নাম (Business Name)</label>
                <input
                  type="text"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  placeholder="যেমন: রহিম ট্রেডার্স"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">মোবাইল নম্বর (Phone)*</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="যেমন: 01711223344"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">এলাকা / টেরিটরি (Area)*</label>
                <select
                  value={formData.areaId}
                  onChange={(e) => setFormData({ ...formData, areaId: e.target.value })}
                  required
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  <option value="">-- এলাকা সিলেক্ট করুন --</option>
                  {areas.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({a.division})
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">ঠিকানা (Address)</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="যেমন: দোকান নং ১২, চকবাজার, চট্টগ্রাম"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              {!editingCustomer && (
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    প্রারম্ভিক বাকি (Opening Due - ৳)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.openingDue}
                    onChange={(e) => setFormData({ ...formData, openingDue: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono font-bold text-rose-600"
                  />
                </div>
              )}

              <div>
                <label className="font-bold text-slate-700 block mb-1">ক্রেডিট লিমিট (Credit Limit - ৳)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.creditLimit}
                  onChange={(e) => setFormData({ ...formData, creditLimit: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">স্ট্যাটাস (Status)</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  <option value="active">Active (সক্রিয়)</option>
                  <option value="inactive">Inactive (নিষ্ক্রিয়)</option>
                </select>
              </div>
            </div>
          </form>
        </Modal>
      )}

      {/* COLLECT DUE MODAL */}
      {collectingCustomer && (
        <Modal
          isOpen={true}
          onClose={() => setCollectingCustomer(null)}
          title={`বাকি আদায়: ${collectingCustomer.name}`}
          subtitle={`Current Due: ${formatCurrency(collectingCustomer.currentDue || 0, currencySymbol)}`}
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setCollectingCustomer(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading || collectAmount <= 0}
                onClick={handleCollectDueSubmit}
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-1.5"
              >
                {loading ? 'প্রক্রিয়াকরণ...' : 'পেমেন্ট জমা করুন (Record Payment)'}
              </button>
            </>
          }
        >
          <form onSubmit={handleCollectDueSubmit} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 flex items-center justify-between">
              <div>
                <p className="text-[11px] text-amber-800 font-medium">কাস্টমারের মোট বাকি:</p>
                <p className="text-base font-bold text-amber-900 font-mono">
                  {formatCurrency(collectingCustomer.currentDue || 0, currencySymbol)}
                </p>
              </div>
              <div>
                <p className="text-[11px] text-amber-800 font-medium">পরিশোধের পর বাকি থাকবে:</p>
                <p className="text-base font-bold text-emerald-800 font-mono">
                  {formatCurrency(
                    Math.max(0, (collectingCustomer.currentDue || 0) - (Number(collectAmount) || 0)),
                    currencySymbol
                  )}
                </p>
              </div>
            </div>

            {(collectingCustomer.dueStaffName || collectingCustomer.salesStaffName) && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-2.5 flex items-center justify-between text-xs">
                <span className="text-blue-800 font-medium">বাকি যে স্টাফের মাধ্যমে গেছে:</span>
                <span className="font-bold text-blue-950 font-mono">
                  {collectingCustomer.dueStaffName || collectingCustomer.salesStaffName}
                </span>
              </div>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">আদায়কৃত টাকার পরিমাণ (Amount - ৳)*</label>
              <input
                type="number"
                min="1"
                max={collectingCustomer.currentDue || 9999999}
                value={collectAmount}
                onChange={(e) => setCollectAmount(Number(e.target.value))}
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold font-mono text-emerald-700 focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">পেমেন্ট মাধ্যম (Payment Method)*</label>
              <select
                value={collectMethod}
                onChange={(e) => setCollectMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
              >
                <option value="Cash">Cash (নগদ গ্রহণ)</option>
                <option value="bKash">bKash (বিকাশ)</option>
                <option value="Nagad">Nagad (নগদ অ্যাপ)</option>
                <option value="Bank">Bank Deposit / Transfer (ব্যাংক)</option>
                <option value="Cheque">Cheque (চেক)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">রেফারেন্স / ট্রানজ্যাকশন আইডি</label>
              <input
                type="text"
                value={collectReference}
                onChange={(e) => setCollectReference(e.target.value)}
                placeholder="যেমন: TrxID / ব্যাংক স্লিপ নং / চেক নং..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">নোট / মন্তব্য</label>
              <textarea
                rows={2}
                value={collectNote}
                onChange={(e) => setCollectNote(e.target.value)}
                placeholder="কোনো অতিরিক্ত মন্তব্য থাকলে লিখুন..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}

      {/* VIEW CUSTOMER PROFILE MODAL */}
      {viewingCustomer && (
        <Modal
          isOpen={true}
          onClose={() => setViewingCustomer(null)}
          title={`গ্রাহক প্রোফাইল: ${viewingCustomer.name}`}
          maxWidth="md"
          footer={
            <button
              type="button"
              onClick={() => setViewingCustomer(null)}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
            >
              বন্ধ করুন
            </button>
          }
        >
          <div className="space-y-4 text-xs">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Customer ID:</span>
                <span className="font-mono font-bold text-slate-800">{viewingCustomer.customerId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Business Name:</span>
                <span className="font-semibold text-slate-900">{viewingCustomer.businessName || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mobile:</span>
                <span className="font-semibold text-slate-800">{viewingCustomer.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Territory:</span>
                <span className="font-semibold text-slate-800">{viewingCustomer.areaName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Address:</span>
                <span className="text-slate-800">{viewingCustomer.address || 'N/A'}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 font-mono">
              <div className="bg-rose-50 p-3 rounded-xl border border-rose-200">
                <p className="text-[11px] text-rose-700 font-semibold font-sans">Current Due</p>
                <p className="text-base font-bold text-rose-800 mt-0.5">
                  {formatCurrency(viewingCustomer.currentDue || 0, currencySymbol)}
                </p>
                {(viewingCustomer.dueStaffName || viewingCustomer.salesStaffName) && (
                  <p className="text-[10px] text-rose-900 font-sans mt-1">
                    বাকি স্টাফ: {viewingCustomer.dueStaffName || viewingCustomer.salesStaffName}
                  </p>
                )}
              </div>

              <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <p className="text-[11px] text-emerald-700 font-semibold font-sans">Total Paid</p>
                <p className="text-base font-bold text-emerald-800 mt-0.5">
                  {formatCurrency(viewingCustomer.totalPaid || 0, currencySymbol)}
                </p>
              </div>

              <div className="bg-blue-50 p-3 rounded-xl border border-blue-200">
                <p className="text-[11px] text-blue-700 font-semibold font-sans">Total Purchases</p>
                <p className="text-base font-bold text-blue-800 mt-0.5">
                  {formatCurrency(viewingCustomer.totalPurchases || 0, currencySymbol)}
                </p>
              </div>

              <div className="bg-slate-100 p-3 rounded-xl border border-slate-200">
                <p className="text-[11px] text-slate-600 font-semibold font-sans">Credit Limit</p>
                <p className="text-base font-bold text-slate-800 mt-0.5">
                  {formatCurrency(viewingCustomer.creditLimit || 0, currencySymbol)}
                </p>
              </div>
            </div>

            {viewingCustomer.lastPurchaseAt && (
              <p className="text-[11px] text-slate-400 text-center">
                সর্বশেষ ক্রয়: {formatDate(viewingCustomer.lastPurchaseAt)}
              </p>
            )}
          </div>
        </Modal>
      )}

      {/* DELETE DIALOG */}
      {customerToDelete && (
        <Modal
          isOpen={true}
          onClose={() => setCustomerToDelete(null)}
          title="কাস্টমার ডিলিট নিশ্চিতকরণ (Soft Delete)"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleDeleteConfirm}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                {loading ? 'মুছে ফেলা হচ্ছে...' : 'ডিলিট করুন (Confirm Delete)'}
              </button>
            </>
          }
        >
          <div className="space-y-3 text-xs">
            <p className="text-slate-600">
              আপনি কি নিশ্চিত যে <span className="font-bold text-slate-900">{customerToDelete.name}</span> কে ডিলিট করতে চান?
              এটি ডিলিট হিস্ট্রিতে সংরক্ষিত থাকবে এবং সুপার অ্যাডমিন পরবর্তীতে রিস্টোর করতে পারবেন।
            </p>
            <div>
              <label className="font-bold text-slate-700 block mb-1">ডিলিট করার কারণ (Delete Reason)*</label>
              <textarea
                rows={2}
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="ডিলিট করার কারণ উল্লেখ করুন..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
