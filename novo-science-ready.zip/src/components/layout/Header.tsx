import React, { useState } from 'react';
import { userHandle } from '../../services/username';
import {
  Menu,
  Plus,
  DollarSign,
  Bell,
  CheckCircle2,
  AlertTriangle,
  User as UserIcon,
  Shield,
  KeyRound,
  ExternalLink,
  LogOut,
} from 'lucide-react';
import { useAuth } from '../../services/authContext';
import { Notification, UserRole } from '../../types';
import { NavItemKey } from './Sidebar';
import { formatDate } from '../../utils/formatters';

interface HeaderProps {
  onToggleMobileMenu: () => void;
  onOpenCreateOrder: () => void;
  onOpenDuePayment: () => void;
  onNavigate: (tab: NavItemKey) => void;
  notifications: Notification[];
  onMarkNotificationRead?: (id: string) => void;
  onOpenChangePassword: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleMobileMenu,
  onOpenCreateOrder,
  onOpenDuePayment,
  onNavigate,
  notifications = [],
  onMarkNotificationRead,
  onOpenChangePassword,
}) => {
  const { currentUser, logout } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const safeNotifications = notifications || [];
  const unreadNotifs = safeNotifications.filter((n) => !n.read);

  return (
    <header className="h-14 sm:h-16 bg-white border-b border-slate-200 sticky top-0 z-30 flex items-center justify-between px-3 sm:px-6 lg:px-8 shrink-0 safe-top">
      {/* Left: menu button (mobile) */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onToggleMobileMenu}
          aria-label="মেনু"
          className="p-2 -ml-2 rounded-lg text-slate-600 hover:bg-slate-100 lg:hidden"
        >
          <Menu className="w-6 h-6" />
        </button>
        <span className="font-bold text-slate-800 text-sm truncate lg:hidden">Novo Science</span>
      </div>

      {/* Right: Quick Actions, Role Demo Switcher, Notifications, User Profile */}
      <div className="flex items-center gap-1.5 sm:gap-4">
        {/* Quick Order Button (phone: icon only) */}
        <button
          type="button"
          onClick={onOpenCreateOrder}
          aria-label="নতুন অর্ডার"
          className="sm:hidden p-2 rounded-lg bg-blue-600 text-white shadow"
        >
          <Plus className="w-5 h-5" />
        </button>
        <button
          type="button"
          onClick={onOpenCreateOrder}
          className="hidden sm:inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm font-bold text-white shadow-md transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Create New Order</span>
        </button>

        {/* Quick Due Payment Button */}
        <button
          type="button"
          onClick={onOpenDuePayment}
          className="hidden lg:inline-flex items-center gap-1.5 bg-white border border-slate-200 px-4 py-2 rounded-lg text-sm font-medium text-slate-600 shadow-sm hover:bg-slate-50 transition-colors cursor-pointer"
        >
          <DollarSign className="w-4 h-4 text-emerald-600" />
          <span>বাকি আদায় (Due)</span>
        </button>

        {/* Notifications Popover Trigger */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 relative cursor-pointer flex items-center gap-1 text-xs font-bold uppercase"
          >
            <Bell className="w-4 h-4" />
            <span className="hidden md:inline">Notifications</span>
            {unreadNotifs.length > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white animate-pulse" />
            )}
          </button>

          {showNotifications && (
            <div className="fixed left-2 right-2 top-14 sm:absolute sm:left-auto sm:right-0 sm:top-auto sm:mt-2 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50">
              <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  বিজ্ঞপ্তি (Notifications) ({unreadNotifs.length})
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setShowNotifications(false);
                    onNavigate('notifications');
                  }}
                  className="text-[11px] text-blue-600 hover:underline font-semibold cursor-pointer"
                >
                  সব দেখুন (View All)
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-50">
                {safeNotifications.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-6">কোনো নতুন বিজ্ঞপ্তি নেই</p>
                ) : (
                  safeNotifications.slice(0, 5).map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        if (onMarkNotificationRead && !n.read) onMarkNotificationRead(n.id);
                        if (n.link) {
                          setShowNotifications(false);
                          if (n.link.includes('orders')) onNavigate('orders');
                          else if (n.link.includes('invoices')) onNavigate('invoices');
                          else if (n.link.includes('product-requests')) onNavigate('product-requests');
                        }
                      }}
                      className={`p-3 text-xs hover:bg-slate-50 cursor-pointer transition-colors ${
                        !n.read ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <span className="shrink-0 mt-0.5">
                          {n.type.includes('APPROVED') ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          ) : n.type.includes('LOW_STOCK') ? (
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                          ) : (
                            <Bell className="w-3.5 h-3.5 text-blue-500" />
                          )}
                        </span>
                        <div>
                          <p className="font-semibold text-slate-800">{n.title}</p>
                          <p className="text-slate-600 mt-0.5 line-clamp-2">{n.message}</p>
                          <p className="text-[10px] text-slate-400 mt-1">{formatDate(n.createdAt)}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Staff / User ID Badge */}
        <div className="hidden sm:inline-block px-3.5 py-1.5 bg-blue-50 text-blue-700 rounded-md text-xs font-bold border border-blue-100/80">
          ID: {currentUser?.staffId || '-'}
        </div>

        {/* User Menu Trigger */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-blue-300 uppercase bg-blue-500/20">
              {currentUser?.name ? currentUser.name.slice(0, 2) : 'SA'}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-xs font-bold text-slate-800 leading-tight truncate max-w-[120px]">
                {currentUser?.name}
              </p>
              <p className="text-[10px] text-slate-500 capitalize">{currentUser?.role?.replace('_', ' ')}</p>
            </div>
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-60 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 text-xs">
              <div className="px-3 py-2 border-b border-slate-100">
                <p className="font-bold text-slate-800">{currentUser?.name}</p>
                <p className="text-slate-500 text-[11px] truncate">@{userHandle(currentUser)}</p>
                <p className="text-[10px] text-blue-600 font-semibold mt-1">ID: {currentUser?.staffId}</p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setShowUserMenu(false);
                  onOpenChangePassword();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-slate-700 hover:bg-slate-50 text-left font-medium"
              >
                <KeyRound className="w-3.5 h-3.5 text-slate-400" />
                <span>পাসওয়ার্ড পরিবর্তন (Change Password)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowUserMenu(false);
                  onNavigate('settings');
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-slate-700 hover:bg-slate-50 text-left font-medium"
              >
                <Shield className="w-3.5 h-3.5 text-slate-400" />
                <span>সিস্টেম সেটিংস (System Settings)</span>
              </button>

              <div className="border-t border-slate-100 my-1"></div>

              <button
                type="button"
                onClick={() => {
                  setShowUserMenu(false);
                  logout();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-rose-600 hover:bg-rose-50 text-left font-medium"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-500" />
                <span>লগআউট (Log Out)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
