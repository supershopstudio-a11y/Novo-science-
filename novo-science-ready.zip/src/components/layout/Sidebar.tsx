import React from 'react';
import { userHandle } from '../../services/username';
import {
  LayoutDashboard,
  ShoppingCart,
  Receipt,
  Users,
  CreditCard,
  Package,
  Boxes,
  GitPullRequest,
  FileBarChart2,
  DollarSign,
  UserCheck,
  MapPin,
  ShieldCheck,
  Bell,
  History,
  Trash2,
  Settings,
  LogOut,
  X,
  Building2,
  Lock,
} from 'lucide-react';
import { useAuth } from '../../services/authContext';
import { checkPermission } from '../../permissions';

export type NavItemKey =
  | 'dashboard'
  | 'sales'
  | 'orders'
  | 'customers'
  | 'due'
  | 'invoices'
  | 'products'
  | 'inventory'
  | 'product-requests'
  | 'expenses'
  | 'reports'
  | 'staff'
  | 'areas'
  | 'permissions'
  | 'notifications'
  | 'activity-logs'
  | 'delete-history'
  | 'settings';

interface SidebarProps {
  currentTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  pendingOrdersCount?: number;
  unreadNotificationsCount?: number;
  pendingRequestsCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpenMobile,
  onCloseMobile,
  pendingOrdersCount = 0,
  unreadNotificationsCount = 0,
  pendingRequestsCount = 0,
}) => {
  const { currentUser, logout } = useAuth();

  const handleNavClick = (tab: NavItemKey) => {
    onSelectTab(tab);
    if (isOpenMobile) onCloseMobile();
  };

  const navGroups: {
    title: string;
    items: {
      key: NavItemKey;
      label: string;
      icon: any;
      permission?: any;
      badge?: number;
      badgeColor?: string;
    }[];
  }[] = [
    {
      title: 'Overview',
      items: [
        { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, permission: 'order.view' },
      ],
    },
    {
      title: 'Sales & Orders',
      items: [
        { key: 'orders', label: 'Orders', icon: ShoppingCart, permission: 'order.view', badge: pendingOrdersCount, badgeColor: 'bg-amber-500 text-white' },
        { key: 'sales', label: 'Sales Records', icon: Receipt, permission: 'sales.view' },
        { key: 'invoices', label: 'Invoices', icon: Receipt, permission: 'invoice.view' },
        { key: 'customers', label: 'Customers', icon: Users, permission: 'customer.view' },
        { key: 'due', label: 'Customer Due', icon: CreditCard, permission: 'customer.viewDue' },
      ],
    },
    {
      title: 'Inventory & Catalog',
      items: [
        { key: 'products', label: 'Products', icon: Package, permission: 'product.view' },
        { key: 'inventory', label: 'Inventory Stock', icon: Boxes, permission: 'inventory.view' },
        { key: 'product-requests', label: 'Product Requests', icon: GitPullRequest, permission: 'product.view', badge: pendingRequestsCount, badgeColor: 'bg-blue-600 text-white' },
      ],
    },
    {
      title: 'Finance & Analytics',
      items: [
        { key: 'reports', label: 'Reports', icon: FileBarChart2, permission: 'report.view' },
        { key: 'expenses', label: 'Expenses', icon: DollarSign, permission: 'expense.view' },
      ],
    },
    {
      title: 'Organization',
      items: [
        { key: 'staff', label: 'Staff Management', icon: UserCheck, permission: 'staff.view' },
        { key: 'areas', label: 'Areas & Territories', icon: MapPin, permission: 'staff.view' },
        { key: 'permissions', label: 'Permission Matrix', icon: ShieldCheck, permission: 'staff.managePermissions' },
      ],
    },
    {
      title: 'Audit & Governance',
      items: [
        { key: 'notifications', label: 'Notifications', icon: Bell, badge: unreadNotificationsCount, badgeColor: 'bg-rose-500 text-white' },
        { key: 'activity-logs', label: 'Activity Logs', icon: History, permission: 'settings.view' },
        { key: 'delete-history', label: 'Delete History', icon: Trash2, permission: 'settings.view' },
      ],
    },
    {
      title: 'System',
      items: [
        { key: 'settings', label: 'Settings & Guide', icon: Settings, permission: 'settings.view' },
      ],
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`print:hidden fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-900 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo Header */}
        <div className="p-4 sm:p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center p-1 shadow-md shrink-0">
              <svg viewBox="0 0 160 110" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 15 H48 V52 L78 15 H106 V95 H78 V58 L48 95 H20 V15 Z" fill="#111827" />
                <path d="M74 15 H118 C136 15 148 24 148 38 C148 48 140 54 130 57 C143 60 152 68 152 80 C152 95 138 95 118 95 H74 V72 H114 C122 72 128 71 128 65 C128 59 121 58 114 58 H88 V46 H114 C120 46 125 45 125 39 C125 33 119 32 112 32 H74 V15 Z" fill="#F97316" />
                <path d="M32 90 C68 66 112 40 152 24 C140 34 85 68 40 94 Z" fill="#EA580C" />
              </svg>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-black tracking-tight text-white leading-tight truncate">
                NEOVENTIS BIOTECH
              </span>
              <span className="text-[9px] font-bold text-orange-400 tracking-widest uppercase">
                NUTRACEUTICALS
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Navigation */}
        <nav className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          {navGroups.map((group) => {
            // Filter items based on user permissions
            const visibleItems = group.items.filter((item) => {
              if (!item.permission) return true;
              return checkPermission(currentUser, item.permission);
            });

            if (visibleItems.length === 0) return null;

            return (
              <div key={group.title} className="space-y-1">
                <p className="px-4 text-[11px] font-bold tracking-wider uppercase text-slate-500">
                  {group.title}
                </p>
                {visibleItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => handleNavClick(item.key)}
                      className={`w-full px-4 py-2.5 rounded-lg flex items-center justify-between text-sm font-medium transition-colors cursor-pointer ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-3 truncate">
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge !== undefined && item.badge > 0 && (
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                            item.badgeColor || 'bg-blue-500 text-white'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* User Card Footer */}
        {currentUser && (
          <div className="p-6 border-t border-slate-800 shrink-0 bg-slate-900 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full bg-slate-700 overflow-hidden shrink-0">
                <div className="w-full h-full flex items-center justify-center bg-blue-500/20 text-blue-400 text-xs font-bold uppercase">
                  {currentUser.name ? currentUser.name.slice(0, 2) : 'SA'}
                </div>
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-white truncate">{currentUser.name || 'Super Admin'}</p>
                <p className="text-[11px] text-slate-500 truncate">@{userHandle(currentUser)}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={logout}
              title="লগআউট (Sign Out)"
              className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </aside>
    </>
  );
};
