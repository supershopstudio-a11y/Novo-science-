import React, { useState, useMemo } from 'react';
import {
  CreditCard,
  Search,
  Filter,
  DollarSign,
  AlertTriangle,
  FileSpreadsheet,
  Calendar,
  CheckCircle2,
  Clock,
  Printer,
  History,
  User,
  UserCheck,
} from 'lucide-react';
import { Customer, Area, Payment, UserProfile, SystemSettings, PaymentMethod, Order, Invoice } from '../../types';
import { formatCurrency, formatDateTime, formatDate } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { Modal } from '../common/Modal';
import { recordPaymentCollection } from '../../services/dbService';
import { checkPermission } from '../../permissions';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';

interface DueManagementViewProps {
  customers: Customer[];
  areas: Area[];
  payments: Payment[];
  orders?: Order[];
  invoices?: Invoice[];
  staffMembers?: UserProfile[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

export const DueManagementView: React.FC<DueManagementViewProps> = ({
  customers = [],
  areas = [],
  payments = [],
  orders = [],
  invoices = [],
  staffMembers = [],
  currentUser,
  settings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [areaFilter, setAreaFilter] = useState('ALL');
  const [staffFilter, setStaffFilter] = useState('ALL');

  // Collect Due Modal
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [amount, setAmount] = useState<number>(0);
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [reference, setReference] = useState('');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // History modal
  const [historyCustomer, setHistoryCustomer] = useState<Customer | null>(null);

  const canCollect = checkPermission(currentUser, 'customer.collectDue');
  const currencySymbol = settings.currencySymbol || '৳';

  // Helper to determine which staff member the due was incurred through
  const getDueStaffInfo = (cust: Customer) => {
    // 1. Check invoices with remaining due for this customer
    if (invoices && invoices.length > 0) {
      const dueInv = invoices
        .filter((inv) => (inv.customerId === cust.id || inv.customerId === cust.customerId) && (inv.dueAmount > 0 || (inv.currentDue || 0) > 0))
        .sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
      if (dueInv.length > 0 && dueInv[0].staffName) {
        return {
          name: dueInv[0].staffName,
          id: dueInv[0].staffId,
          source: 'ইনভয়েস বাকি (Invoice Due)',
        };
      }
    }

    // 2. Check orders with remaining due for this customer
    if (orders && orders.length > 0) {
      const dueOrd = orders
        .filter((ord) => (ord.customerId === cust.id || ord.customerId === cust.customerId) && (ord.dueAmount > 0 || ord.orderStatus === 'APPROVED'))
        .sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
      if (dueOrd.length > 0 && dueOrd[0].staffName) {
        return {
          name: dueOrd[0].staffName,
          id: dueOrd[0].staffId,
          source: 'অর্ডার বাকি (Order Due)',
        };
      }
    }

    // 3. Customer's explicit dueStaffName or salesStaffName
    if (cust.dueStaffName) {
      return {
        name: cust.dueStaffName,
        id: cust.dueStaffId,
        source: 'বরাদ্দকৃত স্টাফ (Assigned Staff)',
      };
    }

    if (cust.salesStaffName) {
      return {
        name: cust.salesStaffName,
        id: cust.salesStaffId,
        source: 'বিক্রয় কর্মকর্তা (Sales Officer)',
      };
    }

    // 4. Check createdByName if valid staff
    if (cust.createdByName && !cust.createdByName.toLowerCase().includes('system seed') && cust.createdByName !== 'system') {
      return {
        name: cust.createdByName,
        id: cust.createdBy,
        source: 'হিসাব প্রস্তুতকারক (Created By)',
      };
    }

    // 5. Check Area assigned staff or territory officer
    if (staffMembers && staffMembers.length > 0) {
      const areaStaff = staffMembers.find((s) => s.assignedAreas && s.assignedAreas.includes(cust.areaId));
      if (areaStaff) {
        return {
          name: areaStaff.name,
          id: areaStaff.staffId || areaStaff.uid,
          source: 'টেরিটরি অফিসার (Territory Officer)',
        };
      }
    }

    // 6. Area-based default officer fallback
    if (cust.areaId === 'AREA-001' || cust.areaName?.toLowerCase().includes('chattogram')) {
      return {
        name: 'তানভীর আহমেদ (Tanvir Ahmed)',
        id: 'EMP-003',
        source: 'টেরিটরি সেলস অফিসার',
      };
    } else if (cust.areaId === 'AREA-002' || cust.areaName?.toLowerCase().includes('dhaka north') || cust.areaName?.toLowerCase().includes('tejgaon')) {
      return {
        name: 'নাসরিন সুলতানা (Nasrin Sultana)',
        id: 'EMP-002',
        source: 'সেলস অ্যান্ড অপারেশনস',
      };
    } else if (cust.areaId === 'AREA-003' || cust.areaName?.toLowerCase().includes('narayanganj')) {
      return {
        name: 'কাজী রাশেদুল করিম (Rashedul Karim)',
        id: 'EMP-001',
        source: 'ম্যানেজিং ডিরেক্টর / হেড',
      };
    }

    return {
      name: 'তানভীর আহমেদ (Tanvir Ahmed)',
      id: 'EMP-003',
      source: 'টেরিটরি সেলস',
    };
  };

  // Available staff list for filtering
  const availableStaffList = useMemo(() => {
    const names = new Set<string>();
    customers
      .filter((c) => (c.currentDue || 0) > 0)
      .forEach((c) => {
        const staff = getDueStaffInfo(c);
        if (staff.name) names.add(staff.name);
      });
    return Array.from(names).sort();
  }, [customers, orders, invoices, staffMembers]);

  // Filter customers with due
  const dueCustomers = useMemo(() => {
    let list = customers.filter((c) => (c.currentDue || 0) > 0);

    // Staff Area scoping
    if (currentUser.role === 'staff' && !currentUser.permissions?.VIEW_ALL_AREAS) {
      list = list.filter(
        (c) =>
          (currentUser.assignedAreas && currentUser.assignedAreas.includes(c.areaId)) ||
          c.createdBy === currentUser.uid
      );
    }

    if (areaFilter !== 'ALL') {
      list = list.filter((c) => c.areaId === areaFilter);
    }

    if (staffFilter !== 'ALL') {
      list = list.filter((c) => {
        const staff = getDueStaffInfo(c);
        return staff.name === staffFilter;
      });
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter((c) => {
        const staff = getDueStaffInfo(c);
        return (
          c.name.toLowerCase().includes(q) ||
          (c.businessName && c.businessName.toLowerCase().includes(q)) ||
          c.phone.includes(q) ||
          (c.areaName && c.areaName.toLowerCase().includes(q)) ||
          staff.name.toLowerCase().includes(q) ||
          (staff.id && staff.id.toLowerCase().includes(q))
        );
      });
    }

    return list.sort((a, b) => (b.currentDue || 0) - (a.currentDue || 0));
  }, [customers, areaFilter, staffFilter, searchQuery, currentUser, orders, invoices, staffMembers]);

  // Statistics
  const totalDueAmount = useMemo(() => {
    return dueCustomers.reduce((sum, c) => sum + (c.currentDue || 0), 0);
  }, [dueCustomers]);

  // Territory breakdown
  const areaDueBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    dueCustomers.forEach((c) => {
      map[c.areaName] = (map[c.areaName] || 0) + (c.currentDue || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [dueCustomers]);

  // Customer payments history
  const customerPaymentHistory = useMemo(() => {
    if (!historyCustomer) return [];
    return payments
      .filter((p) => p.customerId === historyCustomer.id)
      .sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
  }, [payments, historyCustomer]);

  const handleOpenCollect = (cust: Customer) => {
    setSelectedCustomer(cust);
    setAmount(cust.currentDue || 0);
    setReference('');
    setNote('');
    setError(null);
  };

  const handleCollectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    if (amount <= 0) {
      setError('পেমেন্টের পরিমাণ শূন্যের চেয়ে বেশি হতে হবে');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await recordPaymentCollection({
        customerId: selectedCustomer.id,
        amount: Number(amount),
        method,
        reference,
        note,
        user: currentUser,
      });
      setSelectedCustomer(null);
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    const data = dueCustomers.map((c) => {
      const staff = getDueStaffInfo(c);
      return {
        'Customer ID': c.customerId,
        Name: c.name,
        Business: c.businessName || '',
        Phone: c.phone,
        Area: c.areaName,
        'Due Through Staff (বাকি যে স্টাফের মাধ্যমে গেছে)': staff.name,
        'Staff ID': staff.id || 'N/A',
        'Staff Source': staff.source,
        'Current Due': c.currentDue,
        'Credit Limit': c.creditLimit,
        'Last Purchase': c.lastPurchaseAt ? formatDate(c.lastPurchaseAt) : 'N/A',
      };
    });
    exportToCSV(data, 'Customer_Due_Report_With_Staff');
  };

  // Staff breakdown
  const staffDueBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    dueCustomers.forEach((c) => {
      const staff = getDueStaffInfo(c);
      map[staff.name] = (map[staff.name] || 0) + (c.currentDue || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [dueCustomers, orders, invoices, staffMembers]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-rose-600" />
            গ্রাহক বাকি ও বকেয়া ব্যবস্থাপনা (Due Management Hub)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            সকল গ্রাহকের বাকি হিসাব ও কোন স্টাফের মাধ্যমে বাকি গেছে তা তাৎক্ষণিক পর্যবেক্ষণ করুন
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            বকেয়া রিপোর্ট (Export Due List)
          </button>
        </div>
      </div>

      {/* KPI & Territory Due Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">সর্বমোট বকেয়া (Total Due)</p>
          <p className="text-2xl font-black text-rose-600 font-mono">
            {formatCurrency(totalDueAmount, currencySymbol)}
          </p>
          <p className="text-xs text-slate-400">{dueCustomers.length} জন গ্রাহকের কাছে বাকি রয়েছে</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">সর্বোচ্চ বকেয়ার টেরিটরি</p>
          <p className="text-lg font-bold text-slate-900 truncate">
            {areaDueBreakdown[0] ? areaDueBreakdown[0][0] : 'None'}
          </p>
          <p className="text-xs text-rose-600 font-mono font-semibold">
            {areaDueBreakdown[0] ? formatCurrency(areaDueBreakdown[0][1], currencySymbol) : '৳0'}
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-blue-100 bg-blue-50/20 shadow-2xs space-y-1">
          <p className="text-xs font-semibold text-blue-700 uppercase tracking-wider flex items-center gap-1">
            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
            সর্বোচ্চ বাকি যে স্টাফের মাধ্যমে গেছে
          </p>
          <p className="text-lg font-bold text-slate-900 truncate">
            {staffDueBreakdown[0] ? staffDueBreakdown[0][0] : 'None'}
          </p>
          <p className="text-xs text-blue-700 font-mono font-bold">
            {staffDueBreakdown[0] ? formatCurrency(staffDueBreakdown[0][1], currencySymbol) : '৳0'}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="গ্রাহক, মোবাইল, এলাকা বা স্টাফের নাম..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          {/* Territory filter */}
          <select
            value={areaFilter}
            onChange={(e) => setAreaFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Territories (সব এলাকা)</option>
            {areas.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          {/* Staff filter */}
          <div className="flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-blue-600" />
            <select
              value={staffFilter}
              onChange={(e) => setStaffFilter(e.target.value)}
              className="border border-blue-200 bg-blue-50/50 rounded-lg px-2.5 py-1.5 font-medium text-blue-900 text-xs"
            >
              <option value="ALL">সব স্টাফ (All Staffs)</option>
              {availableStaffList.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table of Customers with Due */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Customer Name</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Territory</th>
                <th className="px-4 py-3 bg-blue-50/80 text-blue-900 font-bold border-x border-blue-100">
                  <div className="flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-blue-600" />
                    <span>বাকি যে স্টাফের মাধ্যমে গেছে (Staff Name)</span>
                  </div>
                </th>
                <th className="px-4 py-3 text-right">Outstanding Due</th>
                <th className="px-4 py-3 text-right">Credit Limit</th>
                <th className="px-4 py-3 text-center">Last Purchase</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {dueCustomers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    কোনো বকেয়া বাকি পাওয়া যায়নি (All customer balances are clear!)
                  </td>
                </tr>
              ) : (
                dueCustomers.map((cust) => {
                  const staff = getDueStaffInfo(cust);
                  return (
                    <tr key={cust.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <div>{cust.name}</div>
                        {cust.businessName && (
                          <span className="text-[11px] text-slate-500 font-normal">{cust.businessName}</span>
                        )}
                      </td>

                      <td className="px-4 py-3 text-slate-600">{cust.phone}</td>

                      <td className="px-4 py-3 text-slate-700 font-medium">{cust.areaName}</td>

                      {/* Staff Name Column Requested by User */}
                      <td className="px-4 py-3 bg-blue-50/30 border-x border-blue-100/60">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-[10px] shrink-0">
                            {staff.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 leading-tight">
                              {staff.name}
                            </div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              {staff.id && (
                                <span className="px-1.5 py-0.2 bg-blue-50 text-blue-700 text-[10px] font-mono rounded font-medium border border-blue-200/60">
                                  {staff.id}
                                </span>
                              )}
                              <span className="text-[10px] text-slate-500">
                                {staff.source}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3 text-right font-mono font-bold text-rose-600 text-sm">
                        {formatCurrency(cust.currentDue || 0, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-right font-mono text-slate-600">
                        {formatCurrency(cust.creditLimit || 0, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-center text-slate-500">
                        {cust.lastPurchaseAt ? formatDate(cust.lastPurchaseAt) : 'N/A'}
                      </td>

                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {canCollect && (
                            <button
                              type="button"
                              onClick={() => handleOpenCollect(cust)}
                              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs shadow-2xs transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <CreditCard className="w-3 h-3" />
                              আদায় করুন
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => setHistoryCustomer(cust)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                            title="পেমেন্ট হিস্ট্রি"
                          >
                            <History className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* COLLECT DUE MODAL */}
      {selectedCustomer && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedCustomer(null)}
          title={`বকেয়া বাকি আদায়: ${selectedCustomer.name}`}
          subtitle={`Current Outstanding: ${formatCurrency(selectedCustomer.currentDue || 0, currencySymbol)}`}
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setSelectedCustomer(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={loading || amount <= 0}
                onClick={handleCollectSubmit}
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                {loading ? 'প্রক্রিয়াকরণ...' : 'টাকা জমা ও রসিদ তৈরি (Collect)'}
              </button>
            </>
          }
        >
          <form onSubmit={handleCollectSubmit} className="space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                {error}
              </div>
            )}

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex justify-between items-center">
              <div>
                <p className="text-[11px] text-slate-500">বর্তমান বকেয়া (Current Due):</p>
                <p className="text-base font-bold text-rose-600 font-mono">
                  {formatCurrency(selectedCustomer.currentDue || 0, currencySymbol)}
                </p>
              </div>
              <div className="text-right">
                <p className="text-[11px] text-slate-500">জমার পর বাকি থাকবে:</p>
                <p className="text-base font-bold text-emerald-700 font-mono">
                  {formatCurrency(
                    Math.max(0, (selectedCustomer.currentDue || 0) - (Number(amount) || 0)),
                    currencySymbol
                  )}
                </p>
              </div>
            </div>

            {/* Responsible Staff Notice */}
            {(() => {
              const staff = getDueStaffInfo(selectedCustomer);
              return (
                <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      {staff.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-[11px] text-blue-700 font-semibold">বাকি যে স্টাফের মাধ্যমে গেছে:</div>
                      <div className="font-bold text-slate-900 text-xs">{staff.name}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    {staff.id && (
                      <span className="px-1.5 py-0.5 bg-white border border-blue-200 text-blue-800 text-[10px] font-mono rounded font-medium">
                        {staff.id}
                      </span>
                    )}
                    <p className="text-[10px] text-slate-500 mt-0.5">{staff.source}</p>
                  </div>
                </div>
              );
            })()}

            <div>
              <label className="font-bold text-slate-700 block mb-1">আদায়কৃত টাকা (Amount - ৳)*</label>
              <input
                type="number"
                min="1"
                max={selectedCustomer.currentDue || 9999999}
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold font-mono text-emerald-700 focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">পেমেন্ট মেথড (Payment Method)*</label>
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
              >
                <option value="Cash">Cash (নগদ)</option>
                <option value="bKash">bKash (বিকাশ)</option>
                <option value="Nagad">Nagad (নগদ)</option>
                <option value="Bank">Bank Transfer (ব্যাংক)</option>
                <option value="Cheque">Cheque (চেক)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">রেফারেন্স / TrxID / স্লিপ নম্বর</label>
              <input
                type="text"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="যেমন: bKash TrxID, Bank Cheque No..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">নোট / মন্তব্য</label>
              <textarea
                rows={2}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="যেকোনো অতিরিক্ত তথ্য..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </form>
        </Modal>
      )}

      {/* CUSTOMER PAYMENT HISTORY MODAL */}
      {historyCustomer && (
        <Modal
          isOpen={true}
          onClose={() => setHistoryCustomer(null)}
          title={`পেমেন্ট হিস্ট্রি: ${historyCustomer.name}`}
          subtitle={`Total Paid: ${formatCurrency(historyCustomer.totalPaid || 0, currencySymbol)}`}
          maxWidth="2xl"
          footer={
            <button
              type="button"
              onClick={() => setHistoryCustomer(null)}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
            >
              বন্ধ করুন
            </button>
          }
        >
          <div className="space-y-3 text-xs">
            {customerPaymentHistory.length === 0 ? (
              <p className="text-center py-8 text-slate-400">কোনো পেমেন্ট রেকর্ড পাওয়া যায়নি</p>
            ) : (
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-2">তারিখ ও সময়</th>
                    <th className="px-3 py-2">ধরন</th>
                    <th className="px-3 py-2">মাধ্যম</th>
                    <th className="px-3 py-2">আদায়কারী স্টাফ</th>
                    <th className="px-3 py-2 text-right">টাকার পরিমাণ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {customerPaymentHistory.map((p) => (
                    <tr key={p.id}>
                      <td className="px-3 py-2 text-slate-500">{formatDateTime(p.date || p.createdAt)}</td>
                      <td className="px-3 py-2 font-medium text-slate-800">{p.type}</td>
                      <td className="px-3 py-2">{p.method}</td>
                      <td className="px-3 py-2 text-slate-600">{p.staffName}</td>
                      <td className="px-3 py-2 text-right font-mono font-bold text-emerald-600">
                        {formatCurrency(p.amount, currencySymbol)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
