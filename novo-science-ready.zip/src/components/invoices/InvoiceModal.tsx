import React, { useRef } from 'react';
import { Printer, Download, X } from 'lucide-react';
import { Invoice, SystemSettings } from '../../types';
import { Modal } from '../common/Modal';
import { formatCurrency, formatDateTime } from '../../utils/formatters';
import { StatusBadge } from '../common/Badge';
import { CompanyBrandHeader } from '../common/CompanyBrandHeader';

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  settings: SystemSettings;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  isOpen,
  onClose,
  invoice,
  settings,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const currencySymbol = settings.currencySymbol || '৳';

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`ইনভয়েস প্রিভিউ: ${invoice.invoiceNumber}`}
      subtitle={`Order #${invoice.orderId} • Generated on ${formatDateTime(invoice.createdAt)}`}
      maxWidth="3xl"
      footer={
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Status:</span>
            <StatusBadge status={invoice.status} />
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
            >
              বন্ধ করুন (Close)
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              প্রিন্ট ইনভয়েস (Print Invoice)
            </button>
          </div>
        </div>
      }
    >
      {/* Printable Invoice Container */}
      <div
        ref={printRef}
        id="invoice-print-area"
        className="bg-white text-slate-900 p-4 sm:p-8 rounded-lg border border-slate-200 print:border-0 print:p-0"
      >
        {/* Official Brand Header (Neoventis Biotech & Partner) */}
        <CompanyBrandHeader settings={settings} variant="letterhead" className="mb-4" />

        {/* Invoice Meta Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between py-3 border-b border-slate-200 gap-3">
          <div className="flex items-center gap-3">
            <span
              className={`inline-block px-3 py-1 text-xs font-extrabold tracking-wider rounded uppercase ${
                invoice.status === 'CASH' || invoice.status === 'PAID'
                  ? 'bg-emerald-100 text-emerald-800'
                  : invoice.status === 'PARTIAL'
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-rose-100 text-rose-800'
              }`}
            >
              {invoice.status} INVOICE
            </span>
            <span className="text-xs text-slate-500 font-medium">
              অর্ডার নং: <span className="font-semibold text-slate-800">#{invoice.orderId}</span>
            </span>
          </div>

          <div className="text-left sm:text-right text-xs text-slate-600 space-y-0.5">
            <p className="text-sm font-bold text-slate-900">
              ইনভয়েস নং: <span className="font-mono text-base text-blue-700">{invoice.invoiceNumber}</span>
            </p>
            <p>তারিখ: {formatDateTime(invoice.date || invoice.createdAt)}</p>
            <p>
              সেলস অফিসার: <span className="font-semibold text-slate-800">{invoice.staffName}</span>
            </p>
          </div>
        </div>

        {/* Bill To & Territory Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              গ্রাহকের তথ্য (Bill To):
            </p>
            <p className="text-sm font-bold text-slate-900">{invoice.customerName}</p>
            <p className="text-xs text-slate-600">মোবাইল: {invoice.customerPhone || 'N/A'}</p>
            {invoice.customerAddress && (
              <p className="text-xs text-slate-600">ঠিকানা: {invoice.customerAddress}</p>
            )}
          </div>
          <div className="sm:text-right">
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              ডেলিভারি টেরিটরি (Area):
            </p>
            <p className="text-xs font-semibold text-slate-800">{invoice.areaName}</p>
            <p className="text-xs text-slate-600 mt-1">
              পেমেন্ট মেথড:{' '}
              <span className="font-semibold text-slate-800">{invoice.paymentMethod || 'Cash'}</span>
            </p>
          </div>
        </div>

        {/* Items Table */}
        <table className="w-full text-xs text-left mb-6 border border-slate-200 rounded-lg overflow-hidden">
          <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase">
            <tr>
              <th className="px-4 py-2.5 w-12 text-center">ক্রম</th>
              <th className="px-4 py-2.5">পণ্যের বিবরণ (Item Description)</th>
              <th className="px-4 py-2.5 w-24 text-center">পরিমাণ (Qty)</th>
              <th className="px-4 py-2.5 w-28 text-right">একক মূল্য (Rate)</th>
              <th className="px-4 py-2.5 w-32 text-right">মোট টাকা (Amount)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {(invoice.items || []).map((item, index) => (
              <tr key={index}>
                <td className="px-4 py-2.5 text-center text-slate-500 font-medium">{index + 1}</td>
                <td className="px-4 py-2.5">
                  <p className="font-semibold text-slate-900">{item.productName}</p>
                  {item.sku && <p className="text-[10px] text-slate-400">SKU: {item.sku}</p>}
                </td>
                <td className="px-4 py-2.5 text-center font-semibold text-slate-800">
                  {item.quantity} {item.unit || 'pcs'}
                </td>
                <td className="px-4 py-2.5 text-right font-mono">
                  {formatCurrency(item.unitPrice, currencySymbol)}
                </td>
                <td className="px-4 py-2.5 text-right font-bold font-mono text-slate-900">
                  {formatCurrency(item.subtotal, currencySymbol)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Financial Summary Calculation (Including Previous Due, Current Due, Total Due) */}
        <div className="flex flex-col sm:flex-row justify-between gap-6 mb-8">
          <div className="sm:max-w-xs space-y-3">
            <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <p className="font-bold text-slate-800 mb-1">শর্তাবলী (Terms & Conditions):</p>
              <p className="text-[11px] leading-relaxed text-slate-500">
                {invoice.terms ||
                  settings.terms ||
                  '১. বিক্রিত পণ্য ফেরতযোগ্য নহে। ২. কোনো সমস্যা থাকলে ৩ দিনের মধ্যে জানাতে হবে। ৩. চেক ক্লিয়ারেন্স সাপেক্ষে পরিশোধ গণ্য হবে।'}
              </p>
            </div>
          </div>

          <div className="w-full sm:w-80 space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-600">সাবটোটাল (Subtotal):</span>
              <span className="font-semibold font-mono">{formatCurrency(invoice.subtotal, currencySymbol)}</span>
            </div>

            {invoice.discountAmount > 0 && (
              <div className="flex justify-between py-1 border-b border-slate-100 text-emerald-700">
                <span>ডিসকাউন্ট (Discount):</span>
                <span className="font-semibold font-mono">
                  - {formatCurrency(invoice.discountAmount, currencySymbol)}
                </span>
              </div>
            )}

            <div className="flex justify-between py-1 border-b border-slate-200 text-sm font-bold text-slate-900">
              <span>ইনভয়েস মোট (Invoice Total):</span>
              <span className="font-mono text-blue-700">{formatCurrency(invoice.grandTotal, currencySymbol)}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-600">পরিশোধ (Paid Amount):</span>
              <span className="font-semibold font-mono text-emerald-700">
                {formatCurrency(invoice.paidAmount, currencySymbol)}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-600">বর্তমান বাকি (Current Due):</span>
              <span className="font-semibold font-mono text-rose-600">
                {formatCurrency(invoice.currentDue !== undefined ? invoice.currentDue : invoice.dueAmount, currencySymbol)}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100 text-slate-500">
              <span>পূর্বের বাকি (Previous Due):</span>
              <span className="font-mono">{formatCurrency(invoice.previousDue || 0, currencySymbol)}</span>
            </div>

            <div className="flex justify-between py-2 border-t-2 border-slate-900 text-sm font-extrabold text-slate-900 bg-slate-50 px-2 rounded">
              <span>মোট বাকি (Total Outstanding Due):</span>
              <span className="font-mono text-rose-700">
                {formatCurrency(
                  invoice.totalDue !== undefined ? invoice.totalDue : (invoice.previousDue || 0) + invoice.dueAmount,
                  currencySymbol
                )}
              </span>
            </div>
          </div>
        </div>

        {/* Signatures Section */}
        <div className="mt-16 pt-8 border-t border-slate-300 grid grid-cols-2 text-center text-xs">
          <div>
            <div className="w-44 border-b border-dashed border-slate-400 mx-auto mb-2" />
            <p className="font-semibold text-slate-700">গ্রাহকের স্বাক্ষর (Customer Signature)</p>
          </div>
          <div>
            <div className="w-44 border-b border-dashed border-slate-400 mx-auto mb-2" />
            <p className="font-semibold text-slate-700">কর্তৃপক্ষের স্বাক্ষর (Authorized Signature)</p>
          </div>
        </div>

        {/* Invoice Footer note */}
        <div className="mt-8 text-center text-[10px] text-slate-400 border-t border-slate-100 pt-3">
          This is an electronically generated invoice generated by the company ERP system.
        </div>
      </div>
    </Modal>
  );
};
