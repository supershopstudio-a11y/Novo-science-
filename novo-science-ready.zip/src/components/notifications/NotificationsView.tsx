import React from 'react';
import { Bell, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Notification } from '../../types';
import { formatDateTime } from '../../utils/formatters';

interface Props {
  notifications: Notification[];
  onMarkRead: (id: string) => void;
}

export const NotificationsView: React.FC<Props> = ({ notifications, onMarkRead }) => {
  const unread = notifications.filter((n) => !n.read);

  return (
    <div className="max-w-3xl space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
          <Bell className="w-5 h-5 text-blue-600" /> বিজ্ঞপ্তি
          {unread.length > 0 && (
            <span className="text-xs font-bold bg-rose-500 text-white px-2 py-0.5 rounded-full">{unread.length}</span>
          )}
        </h2>
        {unread.length > 0 && (
          <button
            type="button"
            onClick={() => unread.forEach((n) => onMarkRead(n.id))}
            className="text-xs font-semibold text-blue-600 hover:underline"
          >
            সব পড়া হয়েছে
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-400">
          কোনো বিজ্ঞপ্তি নেই
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100 overflow-hidden">
          {notifications.slice(0, 100).map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => !n.read && onMarkRead(n.id)}
              className={`w-full text-left p-4 flex items-start gap-3 hover:bg-slate-50 ${!n.read ? 'bg-blue-50/40' : ''}`}
            >
              <span className="mt-0.5 shrink-0">
                {n.type.includes('APPROVED') ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                ) : n.type.includes('LOW_STOCK') ? (
                  <AlertTriangle className="w-4 h-4 text-rose-500" />
                ) : (
                  <Bell className="w-4 h-4 text-blue-500" />
                )}
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-semibold text-slate-800">{n.title}</span>
                <span className="block text-xs text-slate-600 mt-0.5 break-words">{n.message}</span>
                <span className="block text-[11px] text-slate-400 mt-1">{formatDateTime(n.createdAt)}</span>
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
