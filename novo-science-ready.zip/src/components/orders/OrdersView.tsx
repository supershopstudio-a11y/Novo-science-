import React, { useState, useMemo } from 'react';
import {
  ShoppingCart,
  CheckCircle2,
  XCircle,
  Clock,
  Printer,
  FileSpreadsheet,
  FileDown,
  Plus,
  Search,
  Filter,
  Eye,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { Order, Invoice, Customer, Product, Area, UserProfile, SystemSettings, OrderStatus } from '../../types';
import { StatusBadge } from '../common/Badge';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { Modal } from '../common/Modal';
import { EmptyState } from '../common/EmptyState';
import { DateRangeSelector } from '../common/DateRangeSelector';
import {
  formatCurrency,
  formatDateTime,
  DateFilterType,
  DateRange,
  getDateRange,
  isDateInRange,
} from '../../utils/formatters';
import { approveOrder, rejectOrder, cancelOrder } from '../../services/dbService';
import { exportToCSV } from '../../utils/export';
import { exportOrdersReportPDF } from '../../utils/pdfExport';
import { checkPermission, canViewAllSales } from '../../permissions';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';

interface OrdersViewProps {
  orders: Order[];
  invoices: Invoice[];
  customers: Customer[];
  products: Product[];
  areas: Area[];
  staffMembers: UserProfile[];
  currentUser: UserProfile;
  settings: SystemSettings;
  onOpenCreateOrder: () => void;
  onViewInvoice: (invoice: Invoice) => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({
  orders = [],
  invoices = [],
  customers = [],
  products = [],
  areas = [],
  staffMembers = [],
  currentUser,
  settings,
  onOpenCreateOrder,
  onViewInvoice,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [areaFilter, setAreaFilter] = useState<string>('ALL');
  const [staffFilter, setStaffFilter] = useState<string>('ALL');
  const [dateFilterType, setDateFilterType] = useState<DateFilterType>('all');
  const [customDateRange, setCustomDateRange] = useState<DateRange>({ startDate: '', endDate: '' });

  // Selected Order for Details Modal
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null);

  // Approval & Rejection dialog states
  const [orderToApprove, setOrderToApprove] = useState<Order | null>(null);
  const [orderToReject, setOrderToReject] = useState<Order | null>(null);
  const [orderToCancel, setOrderToCancel] = useState<Order | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [cancellationReason, setCancellationReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const canApprove = checkPermission(currentUser, 'order.approve');
  const canReject = checkPermission(currentUser, 'order.reject');
  const canCancel = checkPermission(currentUser, 'order.cancel');
  const canCreate = checkPermission(currentUser, 'order.create');
  const seeAllSales = canViewAllSales(currentUser);

  // Filtered orders list
  const filteredOrders = useMemo(() => {
    let list = orders;

    // Without "View All Sales" a user sees only the orders they made themselves
    if (!seeAllSales) {
      list = list.filter((o) => o.staffId === currentUser.uid);
    }

    // Status filter
    if (statusFilter !== 'ALL') {
      list = list.filter((o) => o.orderStatus === statusFilter);
    }

    // Area filter
    if (areaFilter !== 'ALL') {
      list = list.filter((o) => o.areaId === areaFilter);
    }

    // Staff filter
    if (staffFilter !== 'ALL') {
      list = list.filter((o) => o.staffId === staffFilter);
    }

    // Date range filter
    const activeRange = dateFilterType === 'custom' ? customDateRange : getDateRange(dateFilterType);
    list = list.filter((o) => isDateInRange(o.date || o.createdAt, activeRange));

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (o) =>
          o.orderId.toLowerCase().includes(q) ||
          o.customerName.toLowerCase().includes(q) ||
          (o.customerPhone && o.customerPhone.includes(q)) ||
          (o.invoiceNumber && o.invoiceNumber.toLowerCase().includes(q)) ||
          o.staffName.toLowerCase().includes(q) ||
          o.areaName.toLowerCase().includes(q)
      );
    }

    // Sort by created descending
    return list.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [
    orders,
    currentUser,
    seeAllSales,
    statusFilter,
    areaFilter,
    staffFilter,
    dateFilterType,
    customDateRange,
    searchQuery,
  ]);

  // Statistics
  const stats = useMemo(() => {
    const totalCount = filteredOrders.length;
    const pendingCount = filteredOrders.filter((o) => o.orderStatus === 'PENDING').length;
    const approvedTotal = filteredOrders
      .filter((o) => o.orderStatus === 'APPROVED')
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    const pendingTotal = filteredOrders
      .filter((o) => o.orderStatus === 'PENDING')
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);

    return { totalCount, pendingCount, approvedTotal, pendingTotal };
  }, [filteredOrders]);

  const currencySymbol = settings.currencySymbol || '৳';

  // Order Approval
  const handleConfirmApprove = async () => {
    if (!orderToApprove) return;
    setActionLoading(true);
    setActionError(null);
    try {
      const invoiceNumber = await approveOrder(orderToApprove.id, currentUser);
      setOrderToApprove(null);

      // Find the generated invoice and optionally open it
      const foundInv = invoices.find((inv) => inv.invoiceNumber === invoiceNumber);
      if (foundInv) {
        onViewInvoice(foundInv);
      }
    } catch (err: any) {
      console.error(err);
      setActionError(getFriendlyErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  // Order Rejection
  const handleConfirmReject = async () => {
    if (!orderToReject) return;
    setActionLoading(true);
    setActionError(null);
    try {
      await rejectOrder(orderToReject.id, rejectionReason || 'Administrator rejected this order', currentUser);
      setOrderToReject(null);
      setRejectionReason('');
    } catch (err: any) {
      console.error(err);
      setActionError(getFriendlyErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  // Order Cancellation
  const handleConfirmCancel = async () => {
    if (!orderToCancel) return;
    setActionLoading(true);
    setActionError(null);
    try {
      await cancelOrder(orderToCancel.id, cancellationReason || 'Cancelled by staff/admin', currentUser);
      setOrderToCancel(null);
      setCancellationReason('');
    } catch (err: any) {
      console.error(err);
      setActionError(getFriendlyErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  // Export
  const handleExportCSV = () => {
    const data = filteredOrders.map((o) => ({
      'Order ID': o.orderId,
      'Invoice #': o.invoiceNumber || 'N/A',
      Date: formatDateTime(o.date || o.createdAt),
      Customer: o.customerName,
      Phone: o.customerPhone || '',
      Area: o.areaName,
      Staff: o.staffName,
      'Items Count': o.items.length,
      Subtotal: o.subtotal,
      Discount: o.discountAmount,
      'Grand Total': o.grandTotal,
      Paid: o.paidAmount,
      Due: o.dueAmount,
      Method: o.paymentMethod,
      'Order Status': o.orderStatus,
      'Payment Status': o.paymentStatus,
    }));
    exportToCSV(data, 'Sales_Orders_Export');
  };

  const [pdfBusy, setPdfBusy] = useState(false);
  const handleGeneratePDF = () => {
    setPdfBusy(true);
    try {
      const parts: string[] = [];
      if (statusFilter !== 'ALL') parts.push(`Status: ${statusFilter}`);
      if (areaFilter !== 'ALL') parts.push(`Area: ${areas.find((a) => a.id === areaFilter)?.name || areaFilter}`);
      if (staffFilter !== 'ALL' && seeAllSales) parts.push(`Staff: ${staffMembers.find((m) => m.uid === staffFilter)?.name || staffFilter}`);
      const range = dateFilterType === 'custom' ? customDateRange : getDateRange(dateFilterType);
      if (dateFilterType === 'custom' && range.startDate) {
        parts.push(`${range.startDate} to ${range.endDate || range.startDate}`);
      } else if (dateFilterType !== 'all') {
        parts.push(`Period: ${dateFilterType}`);
      }
      if (!seeAllSales) parts.push(`Staff: ${currentUser.name}`);
      exportOrdersReportPDF(filteredOrders, settings, parts.length ? parts.join('  |  ') : 'All orders', seeAllSales);
    } finally {
      setPdfBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Metrics Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-blue-600" />
            সেলস অর্ডার ব্যবস্থাপনা (Sales Orders)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage field orders, customer bookings, admin approvals, and automatic invoice generation.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট (Export)
          </button>

          <button
            type="button"
            onClick={handleGeneratePDF}
            disabled={pdfBusy || filteredOrders.length === 0}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <FileDown className="w-3.5 h-3.5 text-blue-600" />
            Generate Report PDF
          </button>

          {canCreate && (
            <button
              type="button"
              onClick={onOpenCreateOrder}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              নতুন অর্ডার (New Order)
            </button>
          )}
        </div>
      </div>

      {/* Action Error Banner */}
      {actionError && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-xs text-rose-700 rounded-xl flex items-center justify-between">
          <span>{actionError}</span>
          <button type="button" onClick={() => setActionError(null)} className="font-bold underline ml-3">
            Dismiss
          </button>
        </div>
      )}

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Filtered Orders</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{stats.totalCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Pending Approval</p>
          <p className="text-xl font-bold text-amber-600 mt-1">{stats.pendingCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Approved Volume</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">
            {formatCurrency(stats.approvedTotal, currencySymbol)}
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-xs font-semibold text-slate-500">Pending Value</p>
          <p className="text-xl font-bold text-blue-600 mt-1">
            {formatCurrency(stats.pendingTotal, currencySymbol)}
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          {/* Search */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search Order ID, Customer, Phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Statuses</option>
            <option value="PENDING">Pending (অপেক্ষমাণ)</option>
            <option value="APPROVED">Approved (অনুমোদিত)</option>
            <option value="REJECTED">Rejected (প্রত্যাখ্যাত)</option>
            <option value="CANCELLED">Cancelled (বাতিল)</option>
          </select>

          {/* Area Filter */}
          <select
            value={areaFilter}
            onChange={(e) => setAreaFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Areas (সব এলাকা)</option>
            {areas.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          {/* Staff Filter (only for users who may see everyone's sales) */}
          {seeAllSales && (
            <select
              value={staffFilter}
              onChange={(e) => setStaffFilter(e.target.value)}
              className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
            >
              <option value="ALL">All Staff (সব কর্মকর্তা)</option>
              {staffMembers.map((s) => (
                <option key={s.uid} value={s.uid}>
                  {s.name} ({s.staffId})
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Date Filter */}
        <DateRangeSelector
          filterType={dateFilterType}
          onFilterChange={setDateFilterType}
          customRange={customDateRange}
          onCustomRangeChange={setCustomDateRange}
        />
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Order ID</th>
                <th className="px-4 py-3">Customer & Area</th>
                <th className="px-4 py-3">Staff</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3 text-right">Grand Total</th>
                <th className="px-4 py-3 text-right">Paid / Due</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={8}>
                    <EmptyState
                      title="কোনো অর্ডার পাওয়া যায়নি (No orders found)"
                      description="No orders match your chosen filters or search query."
                      actionText={canCreate ? 'নতুন অর্ডার তৈরি করুন' : undefined}
                      onAction={canCreate ? onOpenCreateOrder : undefined}
                    />
                  </td>
                </tr>
              ) : (
                filteredOrders.map((ord) => {
                  const hasInvoice = !!ord.invoiceNumber;
                  const matchingInvoice = hasInvoice
                    ? invoices.find((inv) => inv.invoiceNumber === ord.invoiceNumber)
                    : null;

                  return (
                    <tr key={ord.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <div>#{ord.orderId}</div>
                        {ord.invoiceNumber && (
                          <button
                            type="button"
                            onClick={() => matchingInvoice && onViewInvoice(matchingInvoice)}
                            className="text-[10px] text-blue-600 font-mono font-bold hover:underline flex items-center gap-1 mt-0.5"
                          >
                            <Printer className="w-3 h-3" />
                            {ord.invoiceNumber}
                          </button>
                        )}
                      </td>

                      <td className="px-4 py-3">
                        <p className="font-semibold text-slate-900">{ord.customerName}</p>
                        <p className="text-[11px] text-slate-400">
                          {ord.areaName} {ord.customerPhone ? `&bull; ${ord.customerPhone}` : ''}
                        </p>
                      </td>

                      <td className="px-4 py-3 text-slate-600">
                        <span className="font-medium text-slate-800">{ord.staffName}</span>
                      </td>

                      <td className="px-4 py-3 text-slate-500">
                        {formatDateTime(ord.date || ord.createdAt)}
                      </td>

                      <td className="px-4 py-3 text-right font-bold text-slate-900 font-mono">
                        {formatCurrency(ord.grandTotal, currencySymbol)}
                      </td>

                      <td className="px-4 py-3 text-right font-mono">
                        <span className="text-emerald-600 font-medium">
                          Paid: {formatCurrency(ord.paidAmount, currencySymbol)}
                        </span>
                        <br />
                        <span className="text-rose-600 font-medium">
                          Due: {formatCurrency(ord.dueAmount, currencySymbol)}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-center">
                        <StatusBadge status={ord.orderStatus} />
                      </td>

                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* View details */}
                          <button
                            type="button"
                            onClick={() => setViewingOrder(ord)}
                            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="বিস্তারিত দেখুন (View Details)"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Print invoice button if approved */}
                          {matchingInvoice && (
                            <button
                              type="button"
                              onClick={() => onViewInvoice(matchingInvoice)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                              title="ইনভয়েস প্রিন্ট করুন (Print Invoice)"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                          )}

                          {/* Admin: Approve Order */}
                          {ord.orderStatus === 'PENDING' && canApprove && (
                            <button
                              type="button"
                              onClick={() => setOrderToApprove(ord)}
                              className="px-2 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-semibold rounded-md text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                              title="অনুমোদন করুন (Approve Order)"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              অনুমোদন
                            </button>
                          )}

                          {/* Admin: Reject Order */}
                          {ord.orderStatus === 'PENDING' && canReject && (
                            <button
                              type="button"
                              onClick={() => setOrderToReject(ord)}
                              className="px-2 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 font-semibold rounded-md text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                              title="প্রত্যাখ্যান করুন (Reject Order)"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              প্রত্যাখ্যান
                            </button>
                          )}

                          {/* Cancel Order */}
                          {(ord.orderStatus === 'PENDING' || ord.orderStatus === 'APPROVED') && canCancel && (
                            <button
                              type="button"
                              onClick={() => setOrderToCancel(ord)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                              title="অর্ডার বাতিল (Cancel Order)"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ORDER DETAILS MODAL */}
      {viewingOrder && (
        <Modal
          isOpen={true}
          onClose={() => setViewingOrder(null)}
          title={`অর্ডার বিস্তারিত: #${viewingOrder.orderId}`}
          subtitle={`Created on ${formatDateTime(viewingOrder.createdAt)} by ${viewingOrder.staffName}`}
          maxWidth="2xl"
          footer={
            <div className="flex items-center justify-between w-full">
              <StatusBadge status={viewingOrder.orderStatus} />
              <button
                type="button"
                onClick={() => setViewingOrder(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                বন্ধ করুন
              </button>
            </div>
          }
        >
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <p className="text-slate-500 font-medium">গ্রাহক (Customer):</p>
                <p className="font-bold text-slate-900 text-sm">{viewingOrder.customerName}</p>
                <p className="text-slate-600">{viewingOrder.customerPhone}</p>
                <p className="text-slate-600">এলাকা: {viewingOrder.areaName}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-500 font-medium">পেমেন্ট মেথড:</p>
                <p className="font-bold text-slate-800">{viewingOrder.paymentMethod}</p>
                {viewingOrder.invoiceNumber && (
                  <p className="text-blue-600 font-bold font-mono mt-1">
                    ইনভয়েস: {viewingOrder.invoiceNumber}
                  </p>
                )}
              </div>
            </div>

            {/* Items List */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-slate-100 font-semibold text-slate-700 border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-2">পণ্য (Item)</th>
                    <th className="px-3 py-2 text-center">পরিমাণ</th>
                    <th className="px-3 py-2 text-right">মূল্য</th>
                    <th className="px-3 py-2 text-right">মোট</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(viewingOrder.items || []).map((item, idx) => (
                    <tr key={idx}>
                      <td className="px-3 py-2">
                        <span className="font-semibold text-slate-900">{item.productName}</span>
                        {item.sku && <span className="text-[10px] text-slate-400 block">{item.sku}</span>}
                      </td>
                      <td className="px-3 py-2 text-center font-medium">
                        {item.quantity} {item.unit || 'pcs'}
                      </td>
                      <td className="px-3 py-2 text-right font-mono">
                        {formatCurrency(item.unitPrice, currencySymbol)}
                      </td>
                      <td className="px-3 py-2 text-right font-bold font-mono">
                        {formatCurrency(item.subtotal, currencySymbol)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Calculations */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-600">Subtotal:</span>
                <span>{formatCurrency(viewingOrder.subtotal, currencySymbol)}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>Discount:</span>
                <span>- {formatCurrency(viewingOrder.discountAmount, currencySymbol)}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900 text-sm border-t border-slate-200 pt-1">
                <span>Grand Total:</span>
                <span>{formatCurrency(viewingOrder.grandTotal, currencySymbol)}</span>
              </div>
              <div className="flex justify-between text-emerald-600">
                <span>Paid Amount:</span>
                <span>{formatCurrency(viewingOrder.paidAmount, currencySymbol)}</span>
              </div>
              <div className="flex justify-between text-rose-600 font-bold">
                <span>Due Amount:</span>
                <span>{formatCurrency(viewingOrder.dueAmount, currencySymbol)}</span>
              </div>
            </div>

            {viewingOrder.notes && (
              <div className="p-2.5 bg-blue-50/50 rounded-lg border border-blue-100 text-slate-700">
                <span className="font-bold">নোট:</span> {viewingOrder.notes}
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* APPROVE CONFIRMATION DIALOG */}
      {orderToApprove && (
        <ConfirmDialog
          isOpen={true}
          onClose={() => setOrderToApprove(null)}
          onConfirm={handleConfirmApprove}
          title="অর্ডার অনুমোদন নিশ্চিতকরণ (Approve Order)"
          message={`আপনি কি #${orderToApprove.orderId} অর্ডারটি অনুমোদন করতে চান? এটি ইনভেন্টরি থেকে পণ্যের স্টক কমিয়ে দেবে, ইনভয়েস ইস্যু করবে এবং কাস্টমারের বাকি আপডেট করবে।`}
          confirmText="অনুমোদন করুন (Approve)"
          type="success"
          loading={actionLoading}
        />
      )}

      {/* REJECT CONFIRMATION DIALOG */}
      {orderToReject && (
        <Modal
          isOpen={true}
          onClose={() => setOrderToReject(null)}
          title="অর্ডার প্রত্যাখ্যান করুন (Reject Order)"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setOrderToReject(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={actionLoading}
                onClick={handleConfirmReject}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                {actionLoading ? 'অপেক্ষা করুন...' : 'প্রত্যাখ্যান করুন (Reject)'}
              </button>
            </>
          }
        >
          <div className="space-y-3">
            <p className="text-xs text-slate-600">
              #{orderToReject.orderId} অর্ডারটি প্রত্যাখ্যান করার কারণ উল্লেখ করুন:
            </p>
            <textarea
              rows={3}
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="যেমন: স্টক ঘাটতি / গ্রাহকের অনুরোধ / মুল্য পরিবর্তন..."
              className="w-full p-2.5 border border-slate-300 rounded-lg text-xs"
            />
          </div>
        </Modal>
      )}

      {/* CANCEL CONFIRMATION DIALOG */}
      {orderToCancel && (
        <Modal
          isOpen={true}
          onClose={() => setOrderToCancel(null)}
          title="অর্ডার বাতিল করুন (Cancel Order)"
          maxWidth="md"
          footer={
            <>
              <button
                type="button"
                onClick={() => setOrderToCancel(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={actionLoading}
                onClick={handleConfirmCancel}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                {actionLoading ? 'অপেক্ষা করুন...' : 'বাতিল নিশ্চিত করুন (Cancel Order)'}
              </button>
            </>
          }
        >
          <div className="space-y-3">
            <p className="text-xs text-slate-600">
              #{orderToCancel.orderId} অর্ডারটি বাতিল করা হলে পূর্বে অনুমোদিত স্টক ফেরত দেওয়া হবে এবং কাস্টমারের বাকি সমন্বয় করা হবে।
            </p>
            <textarea
              rows={3}
              value={cancellationReason}
              onChange={(e) => setCancellationReason(e.target.value)}
              placeholder="বাতিল করার কারণ..."
              className="w-full p-2.5 border border-slate-300 rounded-lg text-xs"
            />
          </div>
        </Modal>
      )}
    </div>
  );
};
