import React, { useState, useEffect } from 'react';
import { Plus, Trash2, AlertCircle, ShoppingCart, UserPlus, Search, X } from 'lucide-react';
import { Customer, Product, Area, OrderItem, PaymentMethod, UserStock, UserProfile, SystemSettings } from '../../types';
import { Modal } from '../common/Modal';
import { formatCurrency, getNowISO } from '../../utils/formatters';
import { createOrder } from '../../services/dbService';
import { useAuth } from '../../services/authContext';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { checkPermission } from '../../permissions';

interface CreateOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  products: Product[];
  areas: Area[];
  userStocks?: UserStock[];
  currentUser?: UserProfile;
  settings?: SystemSettings;
  onOrderCreated: (orderId: string) => void;
  onOpenCreateCustomer?: () => void;
  currencySymbol?: string;
  allowNegativeStock?: boolean;
}

export const CreateOrderModal: React.FC<CreateOrderModalProps> = ({
  isOpen,
  onClose,
  customers = [],
  products = [],
  areas = [],
  userStocks = [],
  currentUser: propUser,
  settings,
  onOrderCreated,
  onOpenCreateCustomer,
  currencySymbol = '৳',
  allowNegativeStock = false,
}) => {
  const { currentUser: authUser } = useAuth();
  const currentUser = propUser || authUser;

  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [customerQuery, setCustomerQuery] = useState('');
  const [selectedAreaId, setSelectedAreaId] = useState('');
  const [items, setItems] = useState<
    {
      productId: string;
      productName: string;
      sku: string;
      unit: string;
      quantity: number;
      unitPrice: number;
      purchasePrice: number;
      subtotal: number;
    }[]
  >([]);

  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Selected Customer details
  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);

  // Customers matching the search text (name, shop name, phone, customer id)
  const customerMatches = React.useMemo(() => {
    const q = customerQuery.trim().toLowerCase();
    const list = q
      ? customers.filter((c) =>
          [c.name, c.businessName, c.phone, c.customerId]
            .filter(Boolean)
            .some((v) => String(v).toLowerCase().includes(q))
        )
      : customers;
    return list.slice(0, 50);
  }, [customers, customerQuery]);

  // When customer changes, update area automatically
  useEffect(() => {
    if (selectedCustomer) {
      setSelectedAreaId(selectedCustomer.areaId);
    }
  }, [selectedCustomer]);

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
  const grandTotal = Math.max(0, subtotal - (Number(discountAmount) || 0));
  const dueAmount = Math.max(0, grandTotal - (Number(paidAmount) || 0));

  const handleAddItem = () => {
    // Pick first product that has stock
    const defaultProduct = products.find((p) => p.currentStock > 0) || products[0];
    if (!defaultProduct) return;

    setItems([
      ...items,
      {
        productId: defaultProduct.id,
        productName: defaultProduct.name,
        sku: defaultProduct.sku,
        unit: defaultProduct.unit,
        quantity: 1,
        unitPrice: defaultProduct.salePrice,
        purchasePrice: defaultProduct.purchasePrice,
        subtotal: defaultProduct.salePrice,
      },
    ]);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleProductChange = (index: number, newProductId: string) => {
    const prod = products.find((p) => p.id === newProductId);
    if (!prod) return;

    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      productId: prod.id,
      productName: prod.name,
      sku: prod.sku,
      unit: prod.unit,
      unitPrice: prod.salePrice,
      purchasePrice: prod.purchasePrice,
      subtotal: newItems[index].quantity * prod.salePrice,
    };
    setItems(newItems);
  };

  const handleQuantityChange = (index: number, qty: number) => {
    const val = Math.max(1, qty);
    const item = items[index];
    const prod = products.find((p) => p.id === item.productId);

    if (!allowNegativeStock && prod && val > prod.currentStock) {
      setError(`Warning: "${prod.name}" has only ${prod.currentStock} in stock.`);
    } else {
      setError(null);
    }

    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      quantity: val,
      subtotal: val * newItems[index].unitPrice,
    };
    setItems(newItems);
  };

  const handlePriceChange = (index: number, price: number) => {
    const val = Math.max(0, price);
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      unitPrice: val,
      subtotal: newItems[index].quantity * val,
    };
    setItems(newItems);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setError(null);

    if (!selectedCustomerId || !selectedCustomer) {
      setError('অনুগ্রহ করে কাস্টমার সিলেক্ট করুন (Please select a customer)');
      return;
    }

    if (items.length === 0) {
      setError('অন্তত একটি পণ্য যোগ করুন (Please add at least one item)');
      return;
    }

    // Stock validation
    if (!allowNegativeStock) {
      for (const item of items) {
        const prod = products.find((p) => p.id === item.productId);
        if (prod && item.quantity > prod.currentStock) {
          setError(
            `স্টকে পর্যাপ্ত পণ্য নেই: "${prod.name}" আছে ${prod.currentStock} টি, প্রয়োজন ${item.quantity} টি।`
          );
          return;
        }
      }
    }

    setLoading(true);
    try {
      const area = areas.find((a) => a.id === selectedAreaId);

      const orderItems: OrderItem[] = items.map((i) => ({
        productId: i.productId,
        productName: i.productName,
        sku: i.sku,
        quantity: i.quantity,
        unitPrice: i.unitPrice,
        purchasePrice: i.purchasePrice,
        total: i.subtotal,
      }));

      const paymentStatus = dueAmount === 0 ? 'PAID' : paidAmount > 0 ? 'PARTIAL' : 'DUE';

      const orderId = await createOrder(
        {
          staffId: currentUser.uid,
          staffName: currentUser.name,
          customerId: selectedCustomer.id,
          customerName: selectedCustomer.name,
          customerPhone: selectedCustomer.phone,
          areaId: selectedAreaId,
          areaName: area ? area.name : 'Unassigned',
          date: getNowISO(),
          items: orderItems,
          subtotal,
          discountType: 'fixed',
          discountValue: Number(discountAmount) || 0,
          discountAmount: Number(discountAmount) || 0,
          grandTotal,
          paidAmount: Number(paidAmount) || 0,
          dueAmount,
          paymentMethod,
          paymentStatus,
          notes,
        },
        currentUser
      );

      // Reset state & inform parent
      setSelectedCustomerId('');
      setCustomerQuery('');
      setItems([]);
      setDiscountAmount(0);
      setPaidAmount(0);
      setNotes('');
      onOrderCreated(orderId);
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="নতুন সেলস অর্ডার তৈরি করুন (Create Sales Order)"
      subtitle="Orders will be saved as PENDING until approved by an administrator"
      maxWidth="4xl"
      footer={
        <>
          <button
            type="button"
            disabled={loading}
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            বাতিল (Cancel)
          </button>
          <button
            type="button"
            disabled={loading || items.length === 0}
            onClick={handleSubmit}
            className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {loading ? 'প্রক্রিয়াকরণ হচ্ছে...' : 'অর্ডার সংরক্ষণ করুন (Save Order)'}
          </button>
        </>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Section 1: Customer & Area */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700">কাস্টমার নির্বাচন (Customer)*</label>
              {onOpenCreateCustomer && checkPermission(currentUser, 'customer.create') && (
                <button
                  type="button"
                  onClick={onOpenCreateCustomer}
                  className="text-[11px] text-blue-600 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3 h-3" />
                  নতুন কাস্টমার
                </button>
              )}
            </div>
            {selectedCustomer ? (
              <div className="flex items-center justify-between gap-2 bg-white border border-blue-300 rounded-lg px-3 py-2">
                <div className="min-w-0 text-xs font-semibold text-slate-800 truncate">
                  {selectedCustomer.name}
                  {selectedCustomer.businessName ? ` (${selectedCustomer.businessName})` : ''}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCustomerId('');
                    setCustomerQuery('');
                  }}
                  className="shrink-0 text-[11px] text-blue-600 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <X className="w-3 h-3" />
                  পরিবর্তন
                </button>
              </div>
            ) : (
              <div>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={customerQuery}
                    onChange={(e) => setCustomerQuery(e.target.value)}
                    placeholder="নাম, দোকানের নাম বা ফোন লিখে খুঁজুন..."
                    autoComplete="off"
                    className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
                <div className="mt-1 max-h-48 overflow-y-auto border border-slate-200 rounded-lg bg-white divide-y divide-slate-100">
                  {customerMatches.length === 0 ? (
                    <div className="px-3 py-3 text-[11px] text-slate-400 text-center">
                      কোনো কাস্টমার পাওয়া যায়নি
                    </div>
                  ) : (
                    customerMatches.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => {
                          setSelectedCustomerId(c.id);
                          setCustomerQuery('');
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-blue-50 active:bg-blue-100 cursor-pointer"
                      >
                        <div className="text-xs font-semibold text-slate-800">
                          {c.name}
                          {c.businessName ? ` (${c.businessName})` : ''}
                        </div>
                        <div className="text-[11px] text-slate-500">{c.phone}</div>
                      </button>
                    ))
                  )}
                </div>
              </div>
            )}

            {selectedCustomer && (
              <div className="mt-2 text-[11px] text-slate-600 space-y-0.5">
                <p>ফোন: {selectedCustomer.phone}</p>
                <p className="font-semibold text-rose-600">
                  বর্তমান বাকি (Current Due): {formatCurrency(selectedCustomer.currentDue || 0, currencySymbol)}
                </p>
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">এলাকা / টেরিটরি (Area)*</label>
            <select
              value={selectedAreaId}
              onChange={(e) => setSelectedAreaId(e.target.value)}
              required
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            >
              <option value="">-- এলাকা নির্বাচন করুন --</option>
              {areas.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.division})
                </option>
              ))}
            </select>

            <div className="mt-2 text-[11px] text-slate-500">
              অর্ডারকারী স্টাফ: <span className="font-semibold text-slate-800">{currentUser?.name}</span> ({currentUser?.staffId})
            </div>
          </div>
        </div>

        {/* Section 2: Order Items Table */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <ShoppingCart className="w-4 h-4 text-blue-600" />
              অর্ডারের পণ্যসমূহ (Order Items)
            </h4>
            <button
              type="button"
              onClick={handleAddItem}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              পণ্য যোগ করুন (Add Item)
            </button>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5">পণ্য (Product)</th>
                  <th className="px-3 py-2.5 w-24 text-center">স্টক (Stock)</th>
                  <th className="px-3 py-2.5 w-24 text-center">পরিমাণ (Qty)</th>
                  <th className="px-3 py-2.5 w-28 text-right">মূল্য (Price)</th>
                  <th className="px-3 py-2.5 w-28 text-right">মোট (Total)</th>
                  <th className="px-2 py-2.5 w-10 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-6 text-slate-400">
                      কোনো পণ্য যোগ করা হয়নি। &ldquo;পণ্য যোগ করুন&rdquo; বাটনে ক্লিক করুন।
                    </td>
                  </tr>
                ) : (
                  items.map((item, index) => {
                    const prod = products.find((p) => p.id === item.productId);
                    const stock = prod ? prod.currentStock : 0;
                    const isLow = stock <= (prod?.minimumStock || 5);
                    const isOut = stock <= 0;

                    return (
                      <tr key={index} className="hover:bg-slate-50/50">
                        <td className="px-3 py-2">
                          <select
                            value={item.productId}
                            onChange={(e) => handleProductChange(index, e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs font-medium text-slate-800"
                          >
                            {products.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name} ({p.sku}) &bull; Stock: {p.currentStock} {p.unit}
                              </option>
                            ))}
                          </select>
                        </td>

                        <td className="px-3 py-2 text-center font-semibold">
                          {(() => {
                            const myUserStock = userStocks.find(
                              (u) => u.userId === currentUser?.uid && u.productId === item.productId
                            );
                            return (
                              <div className="flex flex-col items-center gap-0.5">
                                <span
                                  className={`px-2 py-0.5 rounded text-[11px] ${
                                    isOut
                                      ? 'bg-rose-100 text-rose-700'
                                      : isLow
                                      ? 'bg-amber-100 text-amber-700'
                                      : 'bg-emerald-100 text-emerald-700'
                                  }`}
                                  title="সেন্ট্রাল গুদাম স্টক"
                                >
                                  {stock} {item.unit}
                                </span>
                                {myUserStock !== undefined && (
                                  <span
                                    className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-medium"
                                    title="আপনার বর্তমান ব্যক্তিগত স্টক"
                                  >
                                    আপনার: {myUserStock.quantity}
                                  </span>
                                )}
                              </div>
                            );
                          })()}
                        </td>

                        <td className="px-3 py-2 text-center">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleQuantityChange(index, Number(e.target.value))}
                            className="w-20 text-center bg-white border border-slate-200 rounded-lg py-1 px-2 text-xs font-semibold"
                          />
                        </td>

                        <td className="px-3 py-2 text-right">
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.unitPrice}
                            onChange={(e) => handlePriceChange(index, Number(e.target.value))}
                            className="w-24 text-right bg-white border border-slate-200 rounded-lg py-1 px-2 text-xs font-semibold"
                          />
                        </td>

                        <td className="px-3 py-2 text-right font-bold text-slate-900">
                          {formatCurrency(item.subtotal, currencySymbol)}
                        </td>

                        <td className="px-2 py-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(index)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 3: Summary, Discounts & Payments */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">পেমেন্ট মেথড (Payment Method)</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800"
              >
                <option value="Cash">Cash (নগদ)</option>
                <option value="bKash">bKash (বিকাশ)</option>
                <option value="Nagad">Nagad (নগদ অ্যাপ)</option>
                <option value="Bank">Bank Transfer (ব্যাংক)</option>
                <option value="Cheque">Cheque (চেক)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">নোট / মন্তব্য (Notes)</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                placeholder="অর্ডারের বিশেষ নির্দেশনা বা মন্তব্য..."
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="space-y-2 bg-white p-3 rounded-lg border border-slate-200 text-xs">
            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="text-slate-600">সাবটোটাল (Subtotal):</span>
              <span className="font-semibold text-slate-900">{formatCurrency(subtotal, currencySymbol)}</span>
            </div>

            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="text-slate-600">ডিসকাউন্ট (Discount):</span>
              <div className="flex items-center gap-1">
                <span className="text-slate-400">{currencySymbol}</span>
                <input
                  type="number"
                  min="0"
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(Number(e.target.value))}
                  className="w-24 text-right bg-slate-50 border border-slate-200 rounded py-0.5 px-1.5 text-xs font-semibold"
                />
              </div>
            </div>

            <div className="flex justify-between items-center py-1 border-b border-slate-100 text-sm font-bold">
              <span className="text-slate-800">সর্বমোট (Grand Total):</span>
              <span className="text-blue-600">{formatCurrency(grandTotal, currencySymbol)}</span>
            </div>

            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="text-slate-600">পরিশোধের পরিমাণ (Paid):</span>
              <div className="flex items-center gap-1">
                <span className="text-slate-400">{currencySymbol}</span>
                <input
                  type="number"
                  min="0"
                  max={grandTotal}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(Number(e.target.value))}
                  className="w-24 text-right bg-emerald-50 text-emerald-800 border border-emerald-300 rounded py-0.5 px-1.5 text-xs font-bold"
                />
              </div>
            </div>

            <div className="flex justify-between items-center py-1 text-sm font-bold">
              <span className="text-slate-800">অবশিষ্ট বাকি (Due Amount):</span>
              <span className={dueAmount > 0 ? 'text-rose-600' : 'text-emerald-600'}>
                {formatCurrency(dueAmount, currencySymbol)}
              </span>
            </div>
          </div>
        </div>
      </form>
    </Modal>
  );
};
