import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  History,
  Trash2,
  RotateCcw,
  Search,
  Filter,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  User,
} from 'lucide-react';
import { ActivityLog, DeletedRecord, UserProfile, SystemSettings } from '../../types';
import { formatDateTime, formatDate } from '../../utils/formatters';
import { exportToCSV } from '../../utils/export';
import { restoreDeletedRecord } from '../../services/dbService';
import { getFriendlyErrorMessage } from '../../utils/errorHandler';
import { isSuperAdminUser } from '../../permissions';

interface AuditLogsViewProps {
  activityLogs: ActivityLog[];
  deletedRecords: DeletedRecord[];
  currentUser: UserProfile;
  settings: SystemSettings;
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({
  activityLogs = [],
  deletedRecords = [],
  currentUser,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<'activity_logs' | 'delete_history'>('activity_logs');
  const [searchQuery, setSearchQuery] = useState('');
  const [moduleFilter, setModuleFilter] = useState('ALL');

  const [loadingRestoreId, setLoadingRestoreId] = useState<string | null>(null);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canRestore = isSuperAdminUser(currentUser) || currentUser.role === 'admin';

  // Filter Activity Logs
  const filteredLogs = useMemo(() => {
    let list = activityLogs;

    if (moduleFilter !== 'ALL') {
      list = list.filter((l) => l.module === moduleFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (l) =>
          l.userName.toLowerCase().includes(q) ||
          l.action.toLowerCase().includes(q) ||
          l.module.toLowerCase().includes(q) ||
          (l.recordId && l.recordId.toLowerCase().includes(q))
      );
    }

    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [activityLogs, moduleFilter, searchQuery]);

  // Filter Deleted Records
  const filteredDeleted = useMemo(() => {
    let list = deletedRecords;

    if (moduleFilter !== 'ALL') {
      list = list.filter((d) => d.collectionName === moduleFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (d) =>
          d.recordId.toLowerCase().includes(q) ||
          d.deletedByName.toLowerCase().includes(q) ||
          d.deleteReason.toLowerCase().includes(q)
      );
    }

    return list.sort((a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime());
  }, [deletedRecords, moduleFilter, searchQuery]);

  const handleRestore = async (deletedRec: DeletedRecord) => {
    if (!canRestore) return;
    setLoadingRestoreId(deletedRec.id);
    setError(null);
    setRestoreMessage(null);

    try {
      await restoreDeletedRecord({
        deletedRecordId: deletedRec.id,
        user: currentUser,
      });
      setRestoreMessage(`Record #${deletedRec.recordId} successfully restored to active database!`);
      setTimeout(() => setRestoreMessage(null), 4000);
    } catch (err: any) {
      console.error(err);
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoadingRestoreId(null);
    }
  };

  const handleExportLogsCSV = () => {
    const data = filteredLogs.map((l) => ({
      Timestamp: formatDateTime(l.createdAt),
      User: l.userName,
      Action: l.action,
      Module: l.module,
      'Record ID': l.recordId || '',
      IP: l.ipAddress || 'Client',
    }));
    exportToCSV(data, 'System_Audit_Logs_Export');
  };

  const handleExportDeletedCSV = () => {
    const data = filteredDeleted.map((d) => ({
      'Deleted Date': formatDateTime(d.deletedAt),
      Collection: d.collectionName,
      'Record ID': d.recordId,
      'Deleted By': d.deletedByName,
      Reason: d.deleteReason,
      Restored: d.restored ? 'Yes' : 'No',
    }));
    exportToCSV(data, 'Delete_History_Export');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            অডিট ট্রেইল ও ডিলিট হিস্ট্রি (Audit & Soft Delete)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable transaction event logs and safe data recovery mechanism with one-click restore.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={activeTab === 'activity_logs' ? handleExportLogsCSV : handleExportDeletedCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            CSV এক্সপোর্ট
          </button>
        </div>
      </div>

      {restoreMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl flex items-center gap-2 text-xs">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{restoreMessage}</span>
        </div>
      )}

      {error && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2 text-xs">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          type="button"
          onClick={() => setActiveTab('activity_logs')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'activity_logs'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          অ্যাক্টিভিটি লগ (Activity Trail)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('delete_history')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'delete_history'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Trash2 className="w-4 h-4 text-rose-500" />
          ডিলিট হিস্ট্রি ও রিস্টোর (Delete History & Restore)
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3 grow">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search user, action, record ID, reason..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <select
            value={moduleFilter}
            onChange={(e) => setModuleFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700"
          >
            <option value="ALL">All Modules (সকল মডিউল)</option>
            <option value="orders">Orders (অর্ডার)</option>
            <option value="customers">Customers (কাস্টমার)</option>
            <option value="products">Products (পণ্য)</option>
            <option value="payments">Payments (পেমেন্ট)</option>
            <option value="expenses">Expenses (খরচ)</option>
            <option value="inventory">Inventory (ইনভেন্টরি)</option>
            <option value="auth">Authentication</option>
          </select>
        </div>
      </div>

      {/* TAB 1: ACTIVITY LOGS */}
      {activeTab === 'activity_logs' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Action</th>
                  <th className="px-4 py-3">Module</th>
                  <th className="px-4 py-3">Record ID</th>
                  <th className="px-4 py-3">Metadata</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLogs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-slate-400">
                      কোনো লগ রেকর্ড পাওয়া যায়নি
                    </td>
                  </tr>
                ) : (
                  filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-2.5 font-mono text-slate-500 whitespace-nowrap">
                        {formatDateTime(log.createdAt)}
                      </td>

                      <td className="px-4 py-2.5 font-semibold text-slate-800 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        {log.userName}
                      </td>

                      <td className="px-4 py-2.5">
                        <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[11px] font-mono">
                          {log.action}
                        </span>
                      </td>

                      <td className="px-4 py-2.5 text-slate-600 uppercase text-[10px] font-bold">
                        {log.module}
                      </td>

                      <td className="px-4 py-2.5 font-mono font-medium text-blue-600">
                        {log.recordId ? `#${log.recordId}` : '—'}
                      </td>

                      <td className="px-4 py-2.5 text-slate-400 text-[10px] truncate max-w-xs">
                        {log.newData ? JSON.stringify(log.newData).slice(0, 50) + '...' : 'System event'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: DELETE HISTORY & RESTORE */}
      {activeTab === 'delete_history' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Deletion Time</th>
                  <th className="px-4 py-3">Module / Collection</th>
                  <th className="px-4 py-3">Record ID</th>
                  <th className="px-4 py-3">Deleted By</th>
                  <th className="px-4 py-3">Reason For Deletion</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredDeleted.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-slate-400">
                      কোনো ডিলিট রেকর্ড নেই (No soft-deleted records)
                    </td>
                  </tr>
                ) : (
                  filteredDeleted.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-mono text-slate-500 whitespace-nowrap">
                        {formatDateTime(rec.deletedAt)}
                      </td>

                      <td className="px-4 py-3 uppercase text-[10px] font-bold text-slate-700">
                        {rec.collectionName}
                      </td>

                      <td className="px-4 py-3 font-mono font-semibold text-rose-600">
                        #{rec.recordId}
                      </td>

                      <td className="px-4 py-3 font-medium text-slate-800">{rec.deletedByName}</td>

                      <td className="px-4 py-3 text-slate-600 italic">{rec.deleteReason}</td>

                      <td className="px-4 py-3 text-right">
                        {rec.restored ? (
                          <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            Restored
                          </span>
                        ) : canRestore ? (
                          <button
                            type="button"
                            disabled={loadingRestoreId === rec.id}
                            onClick={() => handleRestore(rec)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs shadow-2xs transition-colors inline-flex items-center gap-1 cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            {loadingRestoreId === rec.id ? 'রিস্টোর হচ্ছে...' : 'রিস্টোর করুন (Restore)'}
                          </button>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Admin only</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
