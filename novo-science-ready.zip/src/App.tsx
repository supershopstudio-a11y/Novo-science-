import React, { Suspense, lazy, useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot, doc } from 'firebase/firestore';
import { db } from './services/firebase';
import { AuthProvider, useAuth } from './services/authContext';
import {
  Order,
  Customer,
  Product,
  Category,
  Area,
  Expense,
  Payment,
  Invoice,
  InventoryTransaction,
  ProductRequest,
  UserStock,
  Notification,
  ActivityLog,
  DeletedRecord,
  UserProfile,
  SystemSettings,
} from './types';
import { Sidebar, NavItemKey } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { LoginView } from './components/auth/LoginView';
import { Modal } from './components/common/Modal';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { markNotificationAsRead } from './services/dbService';
import { DEFAULT_SYSTEM_SETTINGS } from './services/seed';
import { checkPermission, isSuperAdminUser } from './permissions';
import { Loader2 } from 'lucide-react';

// Every screen is loaded only when it is opened (much smaller first download on mobile data).
const named = <T extends Record<string, any>>(load: () => Promise<T>, key: keyof T) =>
  lazy(() => load().then((m) => ({ default: m[key] as React.ComponentType<any> })));

const AdminDashboard = named(() => import('./components/dashboard/AdminDashboard'), 'AdminDashboard');
const StaffDashboard = named(() => import('./components/dashboard/StaffDashboard'), 'StaffDashboard');
const OrdersView = named(() => import('./components/orders/OrdersView'), 'OrdersView');
const CustomersView = named(() => import('./components/customers/CustomersView'), 'CustomersView');
const ProductsView = named(() => import('./components/products/ProductsView'), 'ProductsView');
const InventoryView = named(() => import('./components/inventory/InventoryView'), 'InventoryView');
const ProductRequestsView = named(() => import('./components/products/ProductRequestsView'), 'ProductRequestsView');
const DueManagementView = named(() => import('./components/due/DueManagementView'), 'DueManagementView');
const ExpensesView = named(() => import('./components/expenses/ExpensesView'), 'ExpensesView');
const ReportsView = named(() => import('./components/reports/ReportsView'), 'ReportsView');
const StaffManagementView = named(() => import('./components/staff/StaffManagementView'), 'StaffManagementView');
const AreasView = named(() => import('./components/areas/AreasView'), 'AreasView');
const AuditLogsView = named(() => import('./components/audit/AuditLogsView'), 'AuditLogsView');
const SettingsView = named(() => import('./components/settings/SettingsView'), 'SettingsView');
const NotificationsView = named(() => import('./components/notifications/NotificationsView'), 'NotificationsView');
const CreateOrderModal = named(() => import('./components/orders/CreateOrderModal'), 'CreateOrderModal');
const InvoiceModal = named(() => import('./components/invoices/InvoiceModal'), 'InvoiceModal');

const ViewLoader: React.FC = () => (
  <div className="flex items-center justify-center py-20">
    <Loader2 className="w-7 h-7 text-blue-500 animate-spin" />
  </div>
);

/**
 * Live Firestore collection. `enabled` lets screens that do not need a collection
 * skip it entirely (fewer reads = faster app and lower Firebase usage).
 */
function useCollection<T>(
  name: string,
  enabled: boolean,
  options: { idField?: 'id' | 'uid'; hideDeleted?: boolean } = {}
): T[] {
  const { idField = 'id', hideDeleted = false } = options;
  const [items, setItems] = useState<T[]>([]);

  useEffect(() => {
    if (!enabled) {
      setItems([]);
      return;
    }
    return onSnapshot(
      collection(db, name),
      (snap) => {
        const list = snap.docs.map((d) => ({ ...d.data(), [idField]: d.id }) as unknown as T);
        setItems(hideDeleted ? list.filter((x) => !(x as { isDeleted?: boolean }).isDeleted) : list);
      },
      (err) => console.warn(`Firestore sync notice (${name}):`, err?.message || err)
    );
  }, [name, enabled, idField, hideDeleted]);

  return items;
}

/** Which screens a user may open. */
function canSeeTab(user: UserProfile, tab: NavItemKey): boolean {
  if (isSuperAdminUser(user)) return true;
  const can = (p: string) => checkPermission(user, p as any);
  switch (tab) {
    case 'dashboard':
      return can('order.view') || can('sales.view');
    case 'orders':
      return can('order.view');
    case 'sales':
      return can('sales.view');
    case 'invoices':
      return can('invoice.view');
    case 'customers':
      return can('customer.view');
    case 'due':
      return can('customer.viewDue');
    case 'products':
    case 'product-requests':
      return can('product.view');
    case 'inventory':
      return can('inventory.view');
    case 'expenses':
      return can('expense.view');
    case 'reports':
      return can('report.view');
    case 'staff':
    case 'permissions':
      return can('staff.view');
    case 'areas':
      return can('staff.view') || can('VIEW_ALL_AREAS');
    case 'activity-logs':
    case 'delete-history':
    case 'settings':
      return can('settings.view');
    default:
      return true; // notifications
  }
}

const MainApp: React.FC = () => {
  const { currentUser, loading, updateUserPassword } = useAuth();

  // Navigation State
  const [currentTab, setCurrentTab] = useState<NavItemKey>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Send the user to a screen they are allowed to see
  useEffect(() => {
    if (!currentUser || canSeeTab(currentUser, currentTab)) return;
    const fallback: NavItemKey[] = ['products', 'customers', 'orders'];
    setCurrentTab(fallback.find((t) => canSeeTab(currentUser, t)) ?? 'notifications');
  }, [currentUser, currentTab]);

  // Modals
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState<{
    order: Order;
    customer: Customer;
    invoice?: Invoice;
  } | null>(null);

  // Change Password Modal
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);

  // Firestore live data. Subscriptions restart only when the person changes (uid), not on every profile update.
  const uid = currentUser?.uid;
  const signedIn = Boolean(uid);
  const orders = useCollection<Order>('orders', signedIn, { hideDeleted: true });
  const customers = useCollection<Customer>('customers', signedIn, { hideDeleted: true });
  const products = useCollection<Product>('products', signedIn, { hideDeleted: true });
  const categories = useCollection<Category>('categories', signedIn);
  const areas = useCollection<Area>('areas', signedIn, { hideDeleted: true });
  const expenses = useCollection<Expense>('expenses', signedIn, { hideDeleted: true });
  const payments = useCollection<Payment>('payments', signedIn);
  const invoices = useCollection<Invoice>('invoices', signedIn);
  const productRequests = useCollection<ProductRequest>('productRequests', signedIn);
  const userStocks = useCollection<UserStock>('userStocks', signedIn);
  const rawNotifications = useCollection<Notification>('notifications', signedIn);
  const staffMembers = useCollection<UserProfile>('users', signedIn, { idField: 'uid' });
  // Heavy, rarely used collections are loaded only on the screens that show them
  const inventoryTransactions = useCollection<InventoryTransaction>(
    'inventoryTransactions',
    signedIn && currentTab === 'inventory'
  );
  const auditTab = currentTab === 'activity-logs' || currentTab === 'delete-history';
  const activityLogs = useCollection<ActivityLog>('activityLogs', signedIn && auditTab);
  const deletedRecords = useCollection<DeletedRecord>('deletedRecords', signedIn && auditTab);

  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SYSTEM_SETTINGS);
  useEffect(() => {
    if (!uid) return;
    return onSnapshot(
      doc(db, 'settings', 'global'),
      (snap) => {
        if (!snap.exists()) return;
        const data = snap.data() as SystemSettings;
        const D = DEFAULT_SYSTEM_SETTINGS;
        setSettings({
          ...D,
          ...data,
          companyName: !data.companyName || data.companyName.includes('Apex Chemical') ? D.companyName : data.companyName,
          headOfficeAddress: data.headOfficeAddress || D.headOfficeAddress,
          regionalOfficeAddress: data.regionalOfficeAddress || D.regionalOfficeAddress,
          telephone: data.telephone || D.telephone,
          tagline: data.tagline || D.tagline,
          partnerName: data.partnerName || D.partnerName,
          partnerTagline: data.partnerTagline || D.partnerTagline,
        });
      },
      (err) => console.warn('Firestore sync notice (settings):', err?.message || err)
    );
  }, [uid]);

  // Notifications for this user, newest first
  const userNotifications = useMemo(() => {
    if (!currentUser) return [];
    return rawNotifications
      .filter((n) => {
        if (n.targetUserId && n.targetUserId !== currentUser.uid) return false;
        if (n.targetRole && currentUser.role !== 'super_admin' && n.targetRole !== currentUser.role) return false;
        return true;
      })
      .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  }, [rawNotifications, currentUser]);

  // Loading state
  if (loading) {
    return (
      <div className="min-h-dvh bg-slate-900 flex flex-col items-center justify-center space-y-4">
        <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
        <p className="text-sm font-semibold text-slate-300">সিস্টেম লোড হচ্ছে...</p>
      </div>
    );
  }

  // Not logged in -> Show Login
  if (!currentUser) {
    return <LoginView />;
  }

  const pendingOrdersCount = orders.filter((o) => o.orderStatus === 'PENDING').length;
  const pendingRequestsCount = productRequests.filter((r) => r.status === 'PENDING').length;
  const unreadNotificationsCount = userNotifications.filter((n) => !n.read).length;

  const handleOpenInvoice = (order: Order) => {
    const cust = customers.find((c) => c.id === order.customerId) || {
      id: order.customerId,
      customerId: order.customerId,
      name: order.customerName,
      phone: order.customerPhone,
      areaId: order.areaId,
      areaName: order.areaName,
      address: '',
      currentDue: order.dueAmount,
      status: 'active',
      createdAt: '',
    };
    const inv = invoices.find((i) => i.orderId === order.id || i.orderId === order.orderId);
    setViewingInvoice({
      order,
      customer: cust,
      invoice: inv,
    });
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      setPasswordMessage('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      return;
    }

    setPasswordLoading(true);
    setPasswordMessage(null);
    try {
      await updateUserPassword(newPassword);
      setPasswordMessage('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
      setTimeout(() => {
        setIsPasswordModalOpen(false);
        setPasswordMessage(null);
        setNewPassword('');
      }, 2000);
    } catch (err: any) {
      setPasswordMessage(err.message || 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে');
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <div className="flex h-dvh bg-slate-50 text-slate-800 overflow-hidden print:block print:h-auto print:overflow-visible">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        isOpenMobile={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        pendingOrdersCount={pendingOrdersCount}
        unreadNotificationsCount={unreadNotificationsCount}
        pendingRequestsCount={pendingRequestsCount}
      />

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden lg:pl-64 print:block print:overflow-visible print:pl-0">
        {/* Top Header */}
        <Header
          onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
          onOpenCreateOrder={() => setIsCreateOrderOpen(true)}
          onOpenDuePayment={() => setCurrentTab('due')}
          onNavigate={(tab) => setCurrentTab(tab)}
          notifications={userNotifications}
          onMarkNotificationRead={(id) => markNotificationAsRead(id)}
          onOpenChangePassword={() => setIsPasswordModalOpen(true)}
        />

        {/* Scrollable View Container */}
        <main className="flex-1 overflow-y-auto overscroll-contain p-3 sm:p-6 lg:p-8 safe-bottom print:overflow-visible print:p-0">
          <ErrorBoundary key={currentTab}>
          <Suspense fallback={<ViewLoader />}>
          {/* 1. DASHBOARD */}
          {currentTab === 'dashboard' &&
            (currentUser.role === 'staff' ? (
              <StaffDashboard
                currentUser={currentUser}
                orders={orders}
                customers={customers}
                products={products}
                payments={payments}
                productRequests={productRequests}
                userStocks={userStocks}
                settings={settings}
                onOpenCreateOrder={() => setIsCreateOrderOpen(true)}
                onOpenProductRequest={() => setCurrentTab('product-requests')}
                onNavigate={(tab) => setCurrentTab(tab)}
                onViewOrderDetails={handleOpenInvoice}
                onOpenCustomerDue={() => setCurrentTab('due')}
              />
            ) : (
              <AdminDashboard
                orders={orders}
                customers={customers}
                products={products}
                expenses={expenses}
                payments={payments}
                productRequests={productRequests}
                staffMembers={staffMembers}
                areas={areas}
                currentUser={currentUser}
                settings={settings}
                onOpenCreateOrder={() => setIsCreateOrderOpen(true)}
                onViewOrderDetails={handleOpenInvoice}
                onNavigateToTab={setCurrentTab}
                onNavigate={(tab) => setCurrentTab(tab)}
              />
            ))}

          {/* 2. ORDERS & SALES */}
          {(currentTab === 'orders' || currentTab === 'sales' || currentTab === 'invoices') && (
            <OrdersView
              orders={orders}
              invoices={invoices}
              customers={customers}
              products={products}
              areas={areas}
              staffMembers={staffMembers}
              currentUser={currentUser}
              settings={settings}
              onOpenCreateOrder={() => setIsCreateOrderOpen(true)}
              onViewInvoice={handleOpenInvoice}
            />
          )}

          {/* 3. CUSTOMERS */}
          {currentTab === 'customers' && (
            <CustomersView
              customers={customers}
              areas={areas}
              currentUser={currentUser}
              settings={settings}
              onOpenCollectDue={() => setCurrentTab('due')}
            />
          )}

          {/* 4. DUE MANAGEMENT */}
          {currentTab === 'due' && (
            <DueManagementView
              customers={customers}
              areas={areas}
              payments={payments}
              orders={orders}
              invoices={invoices}
              staffMembers={staffMembers}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 5. PRODUCTS */}
          {currentTab === 'products' && (
            <ProductsView
              products={products}
              categories={categories}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 6. INVENTORY */}
          {currentTab === 'inventory' && (
            <InventoryView
              products={products}
              transactions={inventoryTransactions}
              userStocks={userStocks}
              staffMembers={staffMembers}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 7. PRODUCT REQUESTS */}
          {currentTab === 'product-requests' && (
            <ProductRequestsView
              productRequests={productRequests}
              products={products}
              areas={areas}
              userStocks={userStocks}
              staffMembers={staffMembers}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 8. EXPENSES */}
          {currentTab === 'expenses' && (
            <ExpensesView
              expenses={expenses}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 9. REPORTS */}
          {currentTab === 'reports' && (
            <ReportsView
              orders={orders}
              customers={customers}
              products={products}
              expenses={expenses}
              payments={payments}
              staffMembers={staffMembers}
              areas={areas}
              settings={settings}
            />
          )}

          {/* 10. STAFF & PERMISSIONS */}
          {(currentTab === 'staff' || currentTab === 'permissions') && (
            <StaffManagementView
              staffMembers={staffMembers}
              areas={areas}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 11. AREAS */}
          {currentTab === 'areas' && (
            <AreasView
              areas={areas}
              customers={customers}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 12. AUDIT LOGS & DELETE HISTORY */}
          {(currentTab === 'activity-logs' || currentTab === 'delete-history') && (
            <AuditLogsView
              activityLogs={activityLogs}
              deletedRecords={deletedRecords}
              currentUser={currentUser}
              settings={settings}
            />
          )}

          {/* 13. SETTINGS */}
          {currentTab === 'settings' && (
            <SettingsView settings={settings} currentUser={currentUser} />
          )}

          {/* 14. NOTIFICATIONS */}
          {currentTab === 'notifications' && (
            <NotificationsView
              notifications={userNotifications}
              onMarkRead={(id: string) => markNotificationAsRead(id)}
            />
          )}
          </Suspense>
          </ErrorBoundary>
        </main>
      </div>

      {/* CREATE SALES ORDER MODAL */}
      <Suspense fallback={null}>
      {isCreateOrderOpen && (
        <CreateOrderModal
          isOpen={true}
          onClose={() => setIsCreateOrderOpen(false)}
          customers={customers}
          products={products}
          areas={areas}
          userStocks={userStocks}
          currentUser={currentUser}
          settings={settings}
          onOrderCreated={(order) => {
            setIsCreateOrderOpen(false);
            // Optionally open invoice preview
            handleOpenInvoice(order);
          }}
        />
      )}

      {/* INVOICE & PRINT RECEIPT MODAL */}
      {viewingInvoice && (
        <InvoiceModal
          isOpen={true}
          onClose={() => setViewingInvoice(null)}
          order={viewingInvoice.order}
          customer={viewingInvoice.customer}
          invoice={viewingInvoice.invoice}
          settings={settings}
        />
      )}
      </Suspense>

      {/* CHANGE PASSWORD MODAL */}
      {isPasswordModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => {
            setIsPasswordModalOpen(false);
            setPasswordMessage(null);
          }}
          title="পাসওয়ার্ড পরিবর্তন (Change Password)"
          maxWidth="sm"
          footer={
            <>
              <button
                type="button"
                onClick={() => setIsPasswordModalOpen(false)}
                className="px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={passwordLoading}
                onClick={handlePasswordSubmit}
                className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg disabled:opacity-60"
              >
                {passwordLoading ? 'পরিবর্তন হচ্ছে...' : 'পাসওয়ার্ড সংরক্ষণ করুন'}
              </button>
            </>
          }
        >
          <form onSubmit={handlePasswordSubmit} className="space-y-3 text-xs">
            {passwordMessage && (
              <div className="p-3 bg-blue-50 text-blue-800 rounded-lg">{passwordMessage}</div>
            )}
            <div>
              <label className="font-bold text-slate-700 block mb-1">নতুন পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)</label>
              <input
                type="password"
                autoComplete="new-password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
