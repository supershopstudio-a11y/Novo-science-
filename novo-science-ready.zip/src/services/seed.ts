import { collection, getDocs, setDoc, doc, getDoc } from 'firebase/firestore';
import { db, auth } from './firebase';
import { Area, Category, Product, Customer, SystemSettings } from '../types';
import { getNowISO } from '../utils/formatters';

export const DEFAULT_SETTINGS: SystemSettings = {
  companyName: 'NEOVENTIS BIOTECH',
  tagline: 'NUTRACEUTICALS',
  partnerName: 'Novo Science International Ltd.',
  partnerTagline: 'Marketing & Distribution Partner',
  logoUrl: '',
  address: 'Neoventis House, 98/4/A, Jafrabad (Pulper, Shankar), Mohammadpur, Dhaka 1207.',
  companyAddress: 'Neoventis House, 98/4/A, Jafrabad (Pulper, Shankar), Mohammadpur, Dhaka 1207.',
  headOfficeAddress: 'Neoventis House, 98/4/A, Jafrabad (Pulper, Shankar), Mohammadpur, Dhaka 1207.',
  regionalOfficeAddress: 'Holding # 101, Uttar Chartna, Cumilla-3500.',
  phone: '+880 1511-812080',
  companyPhone: '+880 1511-812080',
  telephone: '+88-02-9696576',
  email: 'info@biotech.neoventisgrp.com',
  companyEmail: 'info@biotech.neoventisgrp.com',
  website: 'www.biotech.neoventisgrp.com',

  invoicePrefix: 'INV-',
  startingNumber: 1,
  invoiceFooter: 'Thank you for your business. Quality and reliability guaranteed.',
  terms: '1. Goods sold are subject to delivery terms.\n2. In case of damaged seal, report within 24 hours.\n3. Outstanding dues must be settled as per agreed credit period.',
  signatureUrl: '',

  currency: 'BDT',
  currencySymbol: '৳',
  timezone: 'Asia/Dhaka',
  dateFormat: 'DD/MM/YYYY',
  taxPercentage: 0,
  defaultDiscount: 0,

  allowNegativeStock: false,
  lowStockThreshold: 10,
};

export const DEFAULT_SYSTEM_SETTINGS = DEFAULT_SETTINGS;

export const DEFAULT_AREAS: Omit<Area, 'id'>[] = [
  {
    areaId: 'AREA-001',
    name: 'Chattogram Port & Industrial',
    description: 'Port zone, Export processing zone and Agrabad business district',
    status: 'active',
    assignedStaff: [],
    createdAt: getNowISO(),
  },
  {
    areaId: 'AREA-002',
    name: 'Dhaka North (Tejgaon & Gazipur)',
    description: 'Manufacturing hubs, RMG clusters and central depot',
    status: 'active',
    assignedStaff: [],
    createdAt: getNowISO(),
  },
  {
    areaId: 'AREA-003',
    name: 'Dhaka South (Narayanganj & Old Dhaka)',
    description: 'Chemical wholesale district and river terminal',
    status: 'active',
    assignedStaff: [],
    createdAt: getNowISO(),
  },
  {
    areaId: 'AREA-004',
    name: 'Sylhet Division',
    description: 'Tea processing and northeast distribution area',
    status: 'active',
    assignedStaff: [],
    createdAt: getNowISO(),
  },
];

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'CAT-01', name: 'Tablets & Capsules (ট্যাবলেট ও ক্যাপসুল)', description: 'Pharmaceutical & Nutraceutical Tablets and Capsules' },
  { id: 'CAT-02', name: 'Creams & Topicals (ক্রিম ও মলম)', description: 'Topical Analgesic & Therapeutic Creams' },
  { id: 'CAT-03', name: 'Injectables & Joint Care (ইনজেকশন ও জয়েন্ট কেয়ার)', description: 'Sterile Injectable Formulations and Joint Care' },
  { id: 'CAT-04', name: 'Nutraceuticals (নিউট্রাসিউটিক্যালস)', description: 'Nutraceutical and wellness dietary supplements' },
];

export const DEFAULT_PRODUCTS: Omit<Product, 'id'>[] = [
  {
    productId: 'PROD-OXIALPHA',
    name: 'Tab-Oxialpha',
    sku: 'TAB-OXIALPHA',
    categoryId: 'CAT-01',
    categoryName: 'Tablets & Capsules (ট্যাবলেট ও ক্যাপসুল)',
    brand: 'Neoventis Biotech',
    unit: 'Box (30 Tabs)',
    purchasePrice: 360,
    salePrice: 480,
    currentStock: 150,
    minimumStock: 20,
    status: 'active',
    createdAt: getNowISO(),
  },
  {
    productId: 'PROD-CURQ',
    name: 'Tab-Cur-Q',
    sku: 'TAB-CUR-Q',
    categoryId: 'CAT-01',
    categoryName: 'Tablets & Capsules (ট্যাবলেট ও ক্যাপসুল)',
    brand: 'Neoventis Biotech',
    unit: 'Box (30 Tabs)',
    purchasePrice: 450,
    salePrice: 600,
    currentStock: 120,
    minimumStock: 20,
    status: 'active',
    createdAt: getNowISO(),
  },
  {
    productId: 'PROD-DEPHEAT',
    name: 'Depheat Cream',
    sku: 'DEPHEAT-CRM',
    categoryId: 'CAT-02',
    categoryName: 'Creams & Topicals (ক্রিম ও মলম)',
    brand: 'Neoventis Biotech',
    unit: 'Tube (30g)',
    purchasePrice: 150,
    salePrice: 210,
    currentStock: 90,
    minimumStock: 15,
    status: 'active',
    createdAt: getNowISO(),
  },
  {
    productId: 'PROD-SECJOINT',
    name: 'Inj-Secjoint',
    sku: 'INJ-SECJOINT',
    categoryId: 'CAT-03',
    categoryName: 'Injectables & Joint Care (ইনজেকশন ও জয়েন্ট কেয়ার)',
    brand: 'Neoventis Biotech',
    unit: 'Vial (1 Amp)',
    purchasePrice: 1200,
    salePrice: 1650,
    currentStock: 40,
    minimumStock: 10,
    status: 'active',
    createdAt: getNowISO(),
  },
];

export const DEFAULT_CUSTOMERS: Omit<Customer, 'id'>[] = [
  {
    customerId: 'CUST-001',
    name: 'Mr. Rafiqul Islam',
    businessName: 'Popular Pharma & Drug House',
    phone: '+880 1711-234567',
    address: 'Khatungonj Wholesale Market, Chattogram',
    areaId: 'AREA-001',
    areaName: 'Chattogram Port & Industrial',
    openingDue: 200,
    creditLimit: 50000,
    currentDue: 200,
    status: 'active',
    notes: 'Long-standing wholesale pharmacy client in Chattogram.',
    createdBy: 'system',
    createdByName: 'তানভীর আহমেদ (Tanvir Ahmed)',
    dueStaffName: 'তানভীর আহমেদ (Tanvir Ahmed)',
    dueStaffId: 'EMP-003',
    salesStaffName: 'তানভীর আহমেদ',
    salesStaffId: 'EMP-003',
    totalPurchases: 200,
    totalPaid: 0,
    createdAt: getNowISO(),
  },
  {
    customerId: 'CUST-002',
    name: 'Dr. Mahbubur Rahman',
    businessName: 'Horizon Medical & Health Complex',
    phone: '+880 1819-876543',
    address: 'Tejgaon Industrial Area, Dhaka',
    areaId: 'AREA-002',
    areaName: 'Dhaka North (Tejgaon & Gazipur)',
    openingDue: 1500,
    creditLimit: 150000,
    currentDue: 1500,
    status: 'active',
    notes: 'Healthcare & clinical unit. High volume purchases.',
    createdBy: 'system',
    createdByName: 'নাসরিন সুলতানা (Nasrin Sultana)',
    dueStaffName: 'নাসরিন সুলতানা (Nasrin Sultana)',
    dueStaffId: 'EMP-002',
    salesStaffName: 'নাসরিন সুলতানা',
    salesStaffId: 'EMP-002',
    totalPurchases: 1500,
    totalPaid: 0,
    createdAt: getNowISO(),
  },
  {
    customerId: 'CUST-003',
    name: 'Tanvir Hossain',
    businessName: 'Care Diagnostic & Pharmacy',
    phone: '+880 1912-345678',
    address: 'Chashara, Narayanganj',
    areaId: 'AREA-003',
    areaName: 'Dhaka South (Narayanganj & Old Dhaka)',
    openingDue: 0,
    creditLimit: 80000,
    currentDue: 0,
    status: 'active',
    notes: 'Prompt payer via mobile banking/cash.',
    createdBy: 'system',
    createdByName: 'System Seed',
    totalPurchases: 0,
    totalPaid: 0,
    createdAt: getNowISO(),
  },
];

/**
 * Adds the default categories and the Neoventis products that are still missing.
 * It only CREATES; it never edits or restores anything an admin changed or deleted.
 */
export async function syncNeoventisProducts(): Promise<{ count: number; message: string }> {
  if (!auth.currentUser) {
    return { count: 0, message: 'ব্যবহারকারী লগইন অবস্থায় নেই।' };
  }

  try {
    const [catSnap, prodSnap] = await Promise.all([
      getDocs(collection(db, 'categories')),
      getDocs(collection(db, 'products')),
    ]);

    const existingCategoryIds = new Set(catSnap.docs.map((d) => d.id));
    for (const cat of DEFAULT_CATEGORIES) {
      if (!existingCategoryIds.has(cat.id)) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }
    }

    // Deleted (soft) products still count as "existing" so they are not brought back.
    const known = prodSnap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, any>) }));
    let created = 0;
    for (const prod of DEFAULT_PRODUCTS) {
      const exists = known.some(
        (p) =>
          p.id === prod.productId ||
          p.productId === prod.productId ||
          (p.sku || '').toLowerCase().trim() === prod.sku.toLowerCase().trim() ||
          (p.name || '').toLowerCase().trim() === prod.name.toLowerCase().trim()
      );
      if (!exists) {
        await setDoc(doc(db, 'products', prod.productId), {
          ...prod,
          id: prod.productId,
          createdAt: getNowISO(),
          updatedAt: getNowISO(),
        });
        created++;
      }
    }

    return { count: created, message: 'পণ্য তালিকা সিঙ্ক হয়েছে।' };
  } catch (err: any) {
    console.warn('Sync products notice:', err);
    return { count: 0, message: err?.message || 'পণ্য সিঙ্ক করতে সমস্যা হয়েছে।' };
  }
}

/**
 * First-run setup (called once, when the owner signs in for the first time):
 * default settings, areas, categories, products and sample customers.
 */
export async function initializeSeedData(): Promise<void> {
  if (!auth.currentUser) return;

  try {
    const settingsRef = doc(db, 'settings', 'global');
    if (!(await getDoc(settingsRef)).exists()) {
      await setDoc(settingsRef, DEFAULT_SETTINGS);
    }

    const areasSnap = await getDocs(collection(db, 'areas'));
    if (areasSnap.empty) {
      for (const area of DEFAULT_AREAS) {
        await setDoc(doc(db, 'areas', area.areaId), area);
      }
    }

    await syncNeoventisProducts();

    const custSnap = await getDocs(collection(db, 'customers'));
    if (custSnap.empty) {
      for (const cust of DEFAULT_CUSTOMERS) {
        await setDoc(doc(db, 'customers', cust.customerId), cust);
      }
    }
  } catch (err) {
    console.warn('Seed initialization notice:', err);
  }
}
