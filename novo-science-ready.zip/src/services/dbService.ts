import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  runTransaction,
} from 'firebase/firestore';
import { db } from './firebase';
import {
  Order,
  Invoice,
  Customer,
  Product,
  InventoryTransaction,
  Payment,
  Expense,
  ProductRequest,
  UserStock,
  ActivityLog,
  DeleteLog,
  Notification,
  SystemSettings,
  UserProfile,
  Area,
  Category,
  InventoryTransactionType,
} from '../types';
import { getNowISO, generateId } from '../utils/formatters';
import { DEFAULT_SETTINGS } from './seed';
import { checkPermission, isSuperAdminUser } from '../permissions';

// Real-time collection listener helper
export function subscribeToCollection<T>(
  collectionName: string,
  callback: (data: T[]) => void,
  filterDeleted: boolean = true
) {
  const colRef = collection(db, collectionName);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const items: T[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        if (filterDeleted && data.deleted) {
          return;
        }
        items.push({ id: d.id, ...data } as unknown as T);
      });
      callback(items);
    },
    (err) => {
      console.error(`Error subscribing to ${collectionName}:`, err);
    }
  );
}

// Activity Logging Helper (Immutable)
export function cleanFirestoreData<T extends Record<string, any>>(data: T): Record<string, any> {
  const clean: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined) {
      if (value !== null && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date)) {
        clean[key] = cleanFirestoreData(value);
      } else {
        clean[key] = value;
      }
    }
  }
  return clean;
}

export async function logActivity(params: {
  userId: string;
  userName: string;
  action: string;
  module: string;
  recordId: string;
  oldData?: any;
  newData?: any;
}): Promise<void> {
  try {
    const logId = `LOG-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const logRef = doc(db, 'activityLogs', logId);
    const log: ActivityLog = {
      id: logId,
      logId,
      userId: params.userId,
      userName: params.userName,
      action: params.action,
      module: params.module,
      recordId: params.recordId,
      oldData: params.oldData ?? null,
      newData: params.newData ?? null,
      timestamp: getNowISO(),
    };
    await setDoc(logRef, cleanFirestoreData(log));
  } catch (err) {
    console.error('Failed to write activity log:', err);
  }
}

// Notification Helper
export async function createNotification(params: {
  title: string;
  message: string;
  type: Notification['type'];
  targetUserId?: string;
  targetRole?: string;
  link?: string;
}): Promise<void> {
  try {
    const notifId = `NOTIF-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const notifRef = doc(db, 'notifications', notifId);
    const notif: Record<string, any> = {
      id: notifId,
      title: params.title,
      message: params.message,
      type: params.type,
      read: false,
      createdAt: getNowISO(),
    };
    if (params.targetUserId) {
      notif.targetUserId = params.targetUserId;
    }
    if (params.targetRole) {
      notif.targetRole = params.targetRole;
    }
    if (params.link) {
      notif.link = params.link;
    }
    await setDoc(notifRef, notif);
  } catch (err) {
    console.error('Failed to create notification:', err);
  }
}

// System Settings Helper
export async function getSystemSettings(): Promise<SystemSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'global'));
    if (snap.exists()) {
      return { ...DEFAULT_SETTINGS, ...snap.data() } as SystemSettings;
    }
  } catch (err) {
    console.error('Error loading settings:', err);
  }
  return DEFAULT_SETTINGS;
}

export async function saveSystemSettings(settings: SystemSettings, user: UserProfile): Promise<void> {
  const settingsRef = doc(db, 'settings', 'global');
  const oldSnap = await getDoc(settingsRef);
  const oldData = oldSnap.exists() ? oldSnap.data() : null;
  const { lastInvoiceNumber: _keep, ...toSave } = settings as SystemSettings & { lastInvoiceNumber?: number };
  await setDoc(settingsRef, toSave, { merge: true });
  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'SETTINGS_UPDATED',
    module: 'settings',
    recordId: 'global',
    oldData,
    newData: settings,
  });
}

// ==========================================
// ORDER OPERATIONS
// ==========================================

export async function createOrder(
  orderData: Omit<Order, 'id' | 'orderId' | 'createdAt' | 'orderStatus'>,
  user: UserProfile
): Promise<string> {
  const settings = await getSystemSettings();

  // 1. Validation
  if (!orderData.items || orderData.items.length === 0) {
    throw new Error('Please add at least one product to the order.');
  }

  // Verify stock availability if negative stock not allowed
  if (!settings.allowNegativeStock) {
    for (const item of orderData.items) {
      const prodSnap = await getDoc(doc(db, 'products', item.productId));
      if (!prodSnap.exists()) {
        throw new Error(`Product ${item.productName} not found.`);
      }
      const prodData = prodSnap.data() as Product;
      if (prodData.currentStock < item.quantity) {
        throw new Error(
          `Insufficient stock for "${item.productName}". Available: ${prodData.currentStock}, Requested: ${item.quantity}`
        );
      }
    }
  }

  const orderId = generateId('ORD');
  const orderRef = doc(db, 'orders', orderId);

  const fullOrder: Order = {
    ...orderData,
    id: orderId,
    orderId,
    orderStatus: 'PENDING',
    createdAt: getNowISO(),
  };

  await setDoc(orderRef, fullOrder);

  // Activity Log
  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'ORDER_CREATED',
    module: 'orders',
    recordId: orderId,
    newData: fullOrder,
  });

  // Notify Admins
  await createNotification({
    title: 'New Pending Order',
    message: `${user.name} created order #${orderId} for customer ${orderData.customerName} (${settings.currencySymbol}${orderData.grandTotal})`,
    type: 'NEW_ORDER',
    link: `/orders?id=${orderId}`,
  });

  return orderId;
}

/**
 * ATOMIC ORDER APPROVAL WORKFLOW:
 * - Checks status is PENDING
 * - Atomically decreases stock for all items
 * - Creates inventory transaction audit records
 * - Generates unique Invoice Number
 * - Creates Invoice document
 * - Records Payment if paidAmount > 0
 * - Updates customer due & purchase statistics
 * - Updates order status to APPROVED
 * - Logs activity & triggers notifications
 */
export async function approveOrder(orderId: string, adminUser: UserProfile): Promise<string> {
  const approved = await runTransaction(db, async (transaction) => {
    const orderRef = doc(db, 'orders', orderId);
    const orderSnap = await transaction.get(orderRef);

    if (!orderSnap.exists()) {
      throw new Error('Order does not exist.');
    }

    const order = orderSnap.data() as Order;
    if (order.orderStatus !== 'PENDING') {
      throw new Error(`Order cannot be approved. Current status: ${order.orderStatus}`);
    }

    // NOTE: Firestore requires every transaction read to happen BEFORE the first write.
    const settingsRef = doc(db, 'settings', 'global');
    const settingsSnap = await transaction.get(settingsRef);
    const settingsRaw = (settingsSnap.exists() ? settingsSnap.data() : {}) as Partial<SystemSettings> & {
      lastInvoiceNumber?: number;
    };
    const settings: SystemSettings = { ...DEFAULT_SETTINGS, ...settingsRaw };

    // 1. Verify and read all products
    const productDocs: { ref: any; data: Product; item: any }[] = [];
    for (const item of order.items) {
      const prodRef = doc(db, 'products', item.productId);
      const prodSnap = await transaction.get(prodRef);
      if (!prodSnap.exists()) {
        throw new Error(`Product ${item.productName} no longer exists.`);
      }
      const prod = prodSnap.data() as Product;
      if (!settings.allowNegativeStock && prod.currentStock < item.quantity) {
        throw new Error(
          `Insufficient stock to approve. Product "${prod.name}" has only ${prod.currentStock} left, but order requires ${item.quantity}.`
        );
      }
      productDocs.push({ ref: prodRef, data: prod, item });
    }

    // 2. Read customer
    const customerRef = doc(db, 'customers', order.customerId);
    const customerSnap = await transaction.get(customerRef);
    if (!customerSnap.exists()) {
      throw new Error('Customer associated with this order was not found.');
    }
    const customer = customerSnap.data() as Customer;
    const previousDue = customer.currentDue || 0;
    const currentDue = order.dueAmount;
    const totalDue = previousDue + currentDue;

    // Staff personal stock documents (read now, write later)
    const userStockReads = new Map<string, { ref: any; snap: any }>();
    for (const { item } of productDocs) {
      const ref = doc(db, 'userStocks', `${order.staffId}_${item.productId}`);
      userStockReads.set(item.productId, { ref, snap: await transaction.get(ref) });
    }

    // 3. Sequential invoice number (INV-00001, INV-00002 ...), safe inside the transaction
    const startFrom = Math.max(0, (Number(settings.startingNumber) || 1) - 1);
    const nextNumber = Math.max(Number(settingsRaw.lastInvoiceNumber) || 0, startFrom) + 1;
    const invoiceNumber = `${settings.invoicePrefix || 'INV-'}${String(nextNumber).padStart(5, '0')}`;
    const invoiceId = generateId('INV');
    const invoiceRef = doc(db, 'invoices', invoiceId);

    // Determine invoice status
    let invoiceStatus: Invoice['status'] = 'DUE';
    if (order.paidAmount >= order.grandTotal) {
      invoiceStatus = order.paymentMethod === 'Cash' ? 'CASH' : 'PAID';
    } else if (order.paidAmount > 0) {
      invoiceStatus = 'PARTIAL';
    }

    const now = getNowISO();

    const invoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      orderId: order.orderId,
      date: order.date || now,
      staffId: order.staffId,
      staffName: order.staffName,
      areaId: order.areaId,
      areaName: order.areaName,
      customerId: order.customerId,
      customerName: order.customerName,
      customerPhone: order.customerPhone || customer.phone,
      customerAddress: customer.address,
      items: order.items,
      subtotal: order.subtotal,
      discountAmount: order.discountAmount,
      grandTotal: order.grandTotal,
      paidAmount: order.paidAmount,
      dueAmount: order.dueAmount,
      previousDue,
      currentDue,
      totalDue,
      paymentMethod: order.paymentMethod,
      status: invoiceStatus,
      terms: settings.terms,
      createdAt: now,
    };

    // 4. Update products & create stock audit records
    for (const { ref, data, item } of productDocs) {
      // 4. Update catalog stock
      const newStock = data.currentStock - item.quantity;
      transaction.update(ref, {
        currentStock: newStock,
        updatedAt: now,
      });

      // Deduct from staff personal stock if tracked
      const userStockRead = userStockReads.get(item.productId);
      if (userStockRead && userStockRead.snap.exists()) {
        const uStock = userStockRead.snap.data() as UserStock;
        const currentUQty = uStock.quantity || 0;
        transaction.update(userStockRead.ref, {
          quantity: Math.max(0, currentUQty - item.quantity),
          lastUpdated: now,
        });
      }

      const transId = generateId('TRANS');
      const transRef = doc(db, 'inventoryTransactions', transId);
      const invTrans: InventoryTransaction = {
        id: transId,
        transactionId: transId,
        productId: data.productId || item.productId,
        productName: data.name,
        sku: data.sku,
        type: 'SALE_DEDUCTION',
        quantity: item.quantity,
        previousStock: data.currentStock,
        newStock,
        referenceId: invoiceNumber,
        reason: `Sold in Order #${order.orderId}`,
        performedBy: adminUser.uid,
        performedByName: adminUser.name,
        createdAt: now,
      };
      transaction.set(transRef, invTrans);
    }

    // 5. Create invoice and remember the last used number
    transaction.set(invoiceRef, invoice);
    transaction.set(settingsRef, { lastInvoiceNumber: nextNumber }, { merge: true });

    // 6. Record payment if paidAmount > 0
    if (order.paidAmount > 0) {
      const paymentId = `PAY-${Date.now()}`;
      const paymentRef = doc(db, 'payments', paymentId);
      const paymentRecord: Payment = {
        id: paymentId,
        paymentId,
        orderId: order.orderId,
        invoiceId: invoiceNumber,
        customerId: order.customerId,
        customerName: order.customerName,
        staffId: order.staffId,
        staffName: order.staffName,
        amount: order.paidAmount,
        method: order.paymentMethod,
        reference: `Initial payment for Order #${order.orderId}`,
        date: order.date || now,
        type: 'ORDER_PAYMENT',
        createdAt: now,
      };
      transaction.set(paymentRef, paymentRecord);
    }

    // 7. Update customer statistics
    transaction.update(customerRef, {
      currentDue: totalDue,
      dueStaffName: order.dueAmount > 0 ? order.staffName : (customer.dueStaffName || order.staffName),
      dueStaffId: order.dueAmount > 0 ? order.staffId : (customer.dueStaffId || order.staffId),
      salesStaffName: order.staffName,
      salesStaffId: order.staffId,
      totalPurchases: (customer.totalPurchases || 0) + order.grandTotal,
      totalPaid: (customer.totalPaid || 0) + order.paidAmount,
      lastPurchaseAt: now,
      ...(order.paidAmount > 0 ? { lastPaymentAt: now } : {}),
      updatedAt: now,
    });

    // 8. Update Order
    transaction.update(orderRef, {
      orderStatus: 'APPROVED',
      invoiceId,
      invoiceNumber,
      approvedBy: adminUser.uid,
      approvedByName: adminUser.name,
      approvedAt: now,
      updatedAt: now,
    });

    return { invoiceNumber, totalDue, order };
  });

  // Logs and notifications only after the transaction really committed
  await logActivity({
    userId: adminUser.uid,
    userName: adminUser.name,
    action: 'ORDER_APPROVED',
    module: 'orders',
    recordId: approved.order.orderId,
    newData: {
      invoiceNumber: approved.invoiceNumber,
      totalDue: approved.totalDue,
      grandTotal: approved.order.grandTotal,
    },
  });
  await createNotification({
    title: 'Order Approved',
    message: `Your order #${approved.order.orderId} for ${approved.order.customerName} has been approved. Invoice ${approved.invoiceNumber} issued.`,
    type: 'ORDER_APPROVED',
    targetUserId: approved.order.staffId,
    link: `/invoices?number=${approved.invoiceNumber}`,
  });

  return approved.invoiceNumber;
}

export async function rejectOrder(orderId: string, reason: string, adminUser: UserProfile): Promise<void> {
  const orderRef = doc(db, 'orders', orderId);
  const snap = await getDoc(orderRef);
  if (!snap.exists()) throw new Error('Order not found.');
  const order = snap.data() as Order;

  if (order.orderStatus !== 'PENDING') {
    throw new Error(`Only pending orders can be rejected. Current status: ${order.orderStatus}`);
  }

  const now = getNowISO();
  await updateDoc(orderRef, {
    orderStatus: 'REJECTED',
    rejectionReason: reason || 'Rejected by administrator',
    updatedAt: now,
  });

  await logActivity({
    userId: adminUser.uid,
    userName: adminUser.name,
    action: 'ORDER_REJECTED',
    module: 'orders',
    recordId: orderId,
    newData: { rejectionReason: reason },
  });

  await createNotification({
    title: 'Order Rejected',
    message: `Order #${order.orderId} for ${order.customerName} was rejected: ${reason}`,
    type: 'ORDER_REJECTED',
    targetUserId: order.staffId,
    link: `/orders?id=${orderId}`,
  });
}

export async function cancelOrder(orderId: string, reason: string, user: UserProfile): Promise<void> {
  await runTransaction(db, async (transaction) => {
    const orderRef = doc(db, 'orders', orderId);
    const snap = await transaction.get(orderRef);
    if (!snap.exists()) throw new Error('Order not found.');
    const order = snap.data() as Order;

    const now = getNowISO();

    // If the order was already APPROVED, return the stock and reverse the customer's due.
    if (order.orderStatus === 'APPROVED') {
      // ---- all reads first (Firestore rule: no read after a write) ----
      const products: { ref: any; prod: Product; quantity: number }[] = [];
      for (const item of order.items) {
        const ref = doc(db, 'products', item.productId);
        const prodSnap = await transaction.get(ref);
        if (prodSnap.exists()) {
          products.push({ ref, prod: prodSnap.data() as Product, quantity: item.quantity });
        }
      }
      const custRef = doc(db, 'customers', order.customerId);
      const custSnap = await transaction.get(custRef);

      // ---- then all writes ----
      for (const { ref, prod, quantity } of products) {
        const restoredStock = (prod.currentStock || 0) + quantity;
        transaction.update(ref, { currentStock: restoredStock, updatedAt: now });

        const transId = generateId('TRANS');
        transaction.set(doc(db, 'inventoryTransactions', transId), {
          id: transId,
          transactionId: transId,
          productId: prod.productId || ref.id,
          productName: prod.name,
          sku: prod.sku,
          type: 'SALE_RESTORE',
          quantity,
          previousStock: prod.currentStock || 0,
          newStock: restoredStock,
          referenceId: order.orderId,
          reason: `Order #${order.orderId} Cancelled Reversal`,
          performedBy: user.uid,
          performedByName: user.name,
          createdAt: now,
        });
      }

      if (custSnap.exists()) {
        const cust = custSnap.data() as Customer;
        transaction.update(custRef, {
          currentDue: Math.max(0, (cust.currentDue || 0) - order.dueAmount),
          totalPurchases: Math.max(0, (cust.totalPurchases || 0) - order.grandTotal),
          updatedAt: now,
        });
      }
    }

    transaction.update(orderRef, {
      orderStatus: 'CANCELLED',
      rejectionReason: reason || 'Cancelled',
      updatedAt: now,
    });
  });

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'ORDER_CANCELLED',
    module: 'orders',
    recordId: orderId,
    newData: { reason },
  });
}

// ==========================================
// PAYMENT & DUE COLLECTION
// ==========================================

export async function recordPaymentCollection(params: {
  customerId: string;
  amount: number;
  method: Payment['method'];
  reference?: string;
  note?: string;
  orderId?: string;
  invoiceId?: string;
  date?: string;
  user: UserProfile;
}): Promise<string> {
  const { customerId, amount, method, reference, note, orderId, invoiceId, date, user } = params;

  if (amount <= 0) {
    throw new Error('Payment amount must be greater than zero.');
  }

  const now = getNowISO();
  const paymentId = `PAY-${Date.now()}`;

  await runTransaction(db, async (transaction) => {
    const custRef = doc(db, 'customers', customerId);
    const custSnap = await transaction.get(custRef);
    if (!custSnap.exists()) {
      throw new Error('Customer not found.');
    }
    const customer = custSnap.data() as Customer;
    const prevDue = customer.currentDue || 0;
    const newDue = Math.max(0, prevDue - amount);

    // Read the order BEFORE any write (Firestore transaction rule)
    const ordRef = orderId ? doc(db, 'orders', orderId) : null;
    const ordSnap = ordRef ? await transaction.get(ordRef) : null;

    const paymentRecord: Payment = {
      id: paymentId,
      paymentId,
      orderId: orderId || '',
      invoiceId: invoiceId || '',
      customerId,
      customerName: customer.businessName ? `${customer.name} (${customer.businessName})` : customer.name,
      staffId: user.uid,
      staffName: user.name,
      amount,
      method,
      reference: reference || '',
      note: note || '',
      date: date || now,
      type: orderId ? 'ORDER_PAYMENT' : 'DUE_COLLECTION',
      createdAt: now,
    };

    transaction.set(doc(db, 'payments', paymentId), paymentRecord);

    transaction.update(custRef, {
      currentDue: newDue,
      totalPaid: (customer.totalPaid || 0) + amount,
      lastPaymentAt: now,
      updatedAt: now,
    });

    // If payment belongs to a specific order, update order paid and due amount
    if (ordRef && ordSnap) {
      if (ordSnap.exists()) {
        const ord = ordSnap.data() as Order;
        const updatedPaid = (ord.paidAmount || 0) + amount;
        const updatedDue = Math.max(0, ord.grandTotal - updatedPaid);
        transaction.update(ordRef, {
          paidAmount: updatedPaid,
          dueAmount: updatedDue,
          paymentStatus: updatedDue === 0 ? 'PAID' : 'PARTIAL',
          updatedAt: now,
        });
      }
    }
  });

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'PAYMENT_COLLECTED',
    module: 'payments',
    recordId: paymentId,
    newData: { customerId, amount, method },
  });

  return paymentId;
}

// ==========================================
// INVENTORY STOCK OPERATIONS
// ==========================================

export async function manageStockOperation(params: {
  productId: string;
  type: InventoryTransactionType;
  quantity: number;
  reason: string;
  referenceId?: string;
  user: UserProfile;
}): Promise<void> {
  const { productId, type, quantity, reason, referenceId, user } = params;

  if (quantity <= 0) {
    throw new Error('Stock quantity must be positive.');
  }

  const now = getNowISO();

  await runTransaction(db, async (transaction) => {
    const prodRef = doc(db, 'products', productId);
    const prodSnap = await transaction.get(prodRef);
    if (!prodSnap.exists()) {
      throw new Error('Product not found.');
    }
    const prod = prodSnap.data() as Product;
    let newStock = prod.currentStock;

    if (type === 'STOCK_IN' || type === 'SALE_RESTORE') {
      newStock += quantity;
    } else if (type === 'STOCK_OUT' || type === 'SALE_DEDUCTION') {
      newStock -= quantity;
      if (newStock < 0) {
        throw new Error(`Insufficient stock. Current stock is ${prod.currentStock}, cannot deduct ${quantity}.`);
      }
    } else if (type === 'ADJUSTMENT') {
      // Reason determines whether adjustment is up or down, or quantity represents delta
      newStock = quantity; // Absolute adjustment
    }

    transaction.update(prodRef, {
      currentStock: newStock,
      updatedAt: now,
    });

    const transId = `TRANS-${Date.now()}`;
    const transRef = doc(db, 'inventoryTransactions', transId);
    const invTrans: InventoryTransaction = {
      id: transId,
      transactionId: transId,
      productId: prod.productId,
      productName: prod.name,
      sku: prod.sku,
      type,
      quantity,
      previousStock: prod.currentStock,
      newStock,
      referenceId: referenceId || '',
      reason,
      performedBy: user.uid,
      performedByName: user.name,
      createdAt: now,
    };
    transaction.set(transRef, invTrans);
  });

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: `INVENTORY_${type}`,
    module: 'inventory',
    recordId: productId,
    newData: { type, quantity, reason },
  });
}

// ==========================================
// EXPENSES
// ==========================================

export async function addExpense(
  expenseData: Omit<Expense, 'id' | 'expenseId' | 'createdAt' | 'addedBy' | 'addedByName'>,
  user: UserProfile
): Promise<string> {
  const expenseId = `EXP-${Date.now()}`;
  const now = getNowISO();
  const expense: Expense = {
    ...expenseData,
    id: expenseId,
    expenseId,
    addedBy: user.uid,
    addedByName: user.name,
    createdAt: now,
  };

  await setDoc(doc(db, 'expenses', expenseId), expense);

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'EXPENSE_ADDED',
    module: 'expenses',
    recordId: expenseId,
    newData: expense,
  });

  return expenseId;
}

// ==========================================
// PRODUCT REQUESTS (REQUISITIONS)
// ==========================================

export async function createProductRequest(
  data: Omit<ProductRequest, 'id' | 'requestId' | 'createdAt' | 'status' | 'staffId' | 'staffName'>,
  user: UserProfile
): Promise<string> {
  // Check permission: user must have (Add Product) access or be super admin
  const hasAddProductAccess =
    isSuperAdminUser(user) ||
    checkPermission(user, 'product.create') ||
    checkPermission(user, 'ADD_PRODUCT');

  if (!hasAddProductAccess) {
    throw new Error('আপনার কাছে (Add Product) এক্সেস নেই। শুধুমাত্র যাদের (Add Product) এক্সেস রয়েছে তারা সুপারএডমিনের কাছে প্রোডাক্ট রিকোয়েস্ট পাঠাতে পারেন।');
  }

  const requestId = generateId('REQ');
  const now = getNowISO();

  const req: ProductRequest = {
    ...data,
    id: requestId,
    requestId,
    staffId: user.uid,
    staffName: user.name,
    staffEmail: user.email,
    targetRecipient: 'super_admin',
    status: 'PENDING',
    createdAt: now,
  };

  await setDoc(doc(db, 'productRequests', requestId), req);

  // Notify Super Admin specifically
  await createNotification({
    title: 'নতুন প্রোডাক্ট রিকোয়েস্ট (Super Admin)',
    message: `${user.name} (Add Product এক্সেসধারী) সুপারএডমিনের কাছে ${data.quantity} ${data.unit || 'টি'} ${data.productName} এর রিকোয়েস্ট পাঠিয়েছেন।`,
    type: 'PRODUCT_REQUEST',
    targetRole: 'super_admin',
    link: '/product-requests',
  });

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'PRODUCT_REQUEST_CREATED',
    module: 'productRequests',
    recordId: requestId,
    newData: req,
  });

  return requestId;
}

export async function approveProductRequest(
  requestId: string,
  adminNote: string,
  approverUser: UserProfile
): Promise<void> {
  const now = getNowISO();

  await runTransaction(db, async (transaction) => {
    const reqRef = doc(db, 'productRequests', requestId);
    const reqSnap = await transaction.get(reqRef);
    if (!reqSnap.exists()) {
      throw new Error('Product request not found.');
    }
    const req = reqSnap.data() as ProductRequest;

    if (req.status !== 'PENDING') {
      throw new Error(`এই রিকোয়েস্টটি ইতিমধ্যে ${req.status} অবস্থায় আছে। শুধুমাত্র অপেক্ষমাণ (PENDING) রিকোয়েস্ট অনুমোদন করা সম্ভব।`);
    }

    const prodRef = doc(db, 'products', req.productId);
    const prodSnap = await transaction.get(prodRef);
    if (!prodSnap.exists()) {
      throw new Error('অনুরোধকৃত পণ্যটি প্রোডাক্ট ক্যাটালগে পাওয়া যায়নি।');
    }
    const prod = prodSnap.data() as Product;

    // All reads first: approver's and requester's personal stock documents
    const approverStockRef = doc(db, 'userStocks', `${approverUser.uid}_${req.productId}`);
    const approverStockSnap = await transaction.get(approverStockRef);
    const requesterStockId = `${req.staffId}_${req.productId}`;
    const requesterStockRef = doc(db, 'userStocks', requesterStockId);
    const requesterStockSnap = await transaction.get(requesterStockRef);

    // Check stock availability
    const availableStock = prod.currentStock || 0;
    if (availableStock < req.quantity) {
      throw new Error(
        `অনুমোদন করার মতো পর্যাপ্ত স্টক নেই! বর্তমান সেন্ট্রাল স্টক: ${availableStock} ${prod.unit || 'টি'}, রিকোয়েস্টকৃত পরিমাণ: ${req.quantity} ${prod.unit || 'টি'}`
      );
    }

    // 1. Deduct from approver / central product stock
    const newCatalogStock = availableStock - req.quantity;
    transaction.update(prodRef, {
      currentStock: newCatalogStock,
      updatedAt: now,
    });

    // 2. Fetch and check approver's personal userStock if it exists
    if (approverStockSnap.exists()) {
      const approverStockData = approverStockSnap.data() as UserStock;
      const currentApproverQty = approverStockData.quantity || 0;
      const newApproverQty = Math.max(0, currentApproverQty - req.quantity);
      transaction.update(approverStockRef, {
        quantity: newApproverQty,
        lastUpdated: now,
      });
    }

    // 3. Fetch and increment requesting user's stock
    let prevUserStock = 0;
    let newUserStock = req.quantity;

    if (requesterStockSnap.exists()) {
      const existingUserStock = requesterStockSnap.data() as UserStock;
      prevUserStock = existingUserStock.quantity || 0;
      newUserStock = prevUserStock + req.quantity;
      transaction.update(requesterStockRef, {
        quantity: newUserStock,
        userName: req.staffName,
        productName: req.productName,
        sku: prod.sku || '',
        unit: prod.unit || 'pcs',
        lastUpdated: now,
      });
    } else {
      const newUserStockRecord: UserStock = {
        id: requesterStockId,
        userId: req.staffId,
        userName: req.staffName,
        productId: req.productId,
        productName: req.productName,
        sku: prod.sku || '',
        unit: prod.unit || 'pcs',
        quantity: newUserStock,
        lastUpdated: now,
      };
      transaction.set(requesterStockRef, newUserStockRecord);
    }

    // 4. Create inventory audit transactions
    // 4a. Deduction from Approver / Central Stock
    const transIdOut = `TRANS-REQ-DED-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const transRefOut = doc(db, 'inventoryTransactions', transIdOut);
    const invTransOut: InventoryTransaction = {
      id: transIdOut,
      transactionId: transIdOut,
      productId: req.productId,
      productName: req.productName,
      sku: prod.sku,
      type: 'STOCK_OUT',
      quantity: req.quantity,
      previousStock: availableStock,
      newStock: newCatalogStock,
      referenceId: req.requestId,
      reason: `প্রোডাক্ট রিকোয়েস্ট #${req.requestId} অনুমোদন - অনুমোদক (${approverUser.name}) থেকে কর্তন`,
      performedBy: approverUser.uid,
      performedByName: approverUser.name,
      createdAt: now,
    };
    transaction.set(transRefOut, invTransOut);

    // 4b. Stock added to Requesting User
    const transIdIn = `TRANS-REQ-ADD-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const transRefIn = doc(db, 'inventoryTransactions', transIdIn);
    const invTransIn: InventoryTransaction = {
      id: transIdIn,
      transactionId: transIdIn,
      productId: req.productId,
      productName: req.productName,
      sku: prod.sku,
      type: 'STOCK_IN',
      quantity: req.quantity,
      previousStock: prevUserStock,
      newStock: newUserStock,
      referenceId: req.requestId,
      reason: `প্রোডাক্ট রিকোয়েস্ট #${req.requestId} অনুমোদনের মাধ্যমে ${approverUser.name} এর কাছ থেকে ${req.staffName} এর স্টকে যোগ`,
      performedBy: approverUser.uid,
      performedByName: approverUser.name,
      createdAt: now,
    };
    transaction.set(transRefIn, invTransIn);

    // 5. Update ProductRequest document
    transaction.update(reqRef, {
      status: 'APPROVED',
      adminNote: adminNote || '',
      approvedBy: approverUser.uid,
      approvedByName: approverUser.name,
      approvedAt: now,
      deductedFromUserId: approverUser.uid,
      deductedFromUserName: approverUser.name,
      addedToUserId: req.staffId,
      addedToUserName: req.staffName,
      updatedAt: now,
    });
  });

  // Notifications and Audit Logging
  await createNotification({
    title: 'Product Request Approved & Stock Added',
    message: `আপনার #${requestId} নম্বর প্রোডাক্ট রিকোয়েস্ট অনুমোদিত হয়েছে! অনুমোদক ${approverUser.name} এর কাছ থেকে আপনার স্টকে পণ্য যোগ করা হয়েছে।`,
    type: 'PRODUCT_REQUEST_STATUS',
    targetUserId: (await getDoc(doc(db, 'productRequests', requestId))).data()?.staffId,
    link: '/product-requests',
  });

  await logActivity({
    userId: approverUser.uid,
    userName: approverUser.name,
    action: 'PRODUCT_REQUEST_APPROVED_AND_TRANSFERRED',
    module: 'productRequests',
    recordId: requestId,
    newData: {
      requestId,
      approver: approverUser.name,
      adminNote,
    },
  });
}

export async function updateProductRequestStatus(
  requestId: string,
  status: ProductRequest['status'],
  adminNote: string,
  user: UserProfile
): Promise<void> {
  if (status === 'APPROVED') {
    return approveProductRequest(requestId, adminNote, user);
  }

  const reqRef = doc(db, 'productRequests', requestId);
  const snap = await getDoc(reqRef);
  if (!snap.exists()) throw new Error('Product request not found.');
  const req = snap.data() as ProductRequest;

  const now = getNowISO();
  await updateDoc(reqRef, {
    status,
    adminNote,
    updatedAt: now,
  });

  await createNotification({
    title: `Product Request ${status}`,
    message: `Your product request for ${req.productName} (#${requestId}) has been marked as ${status}. ${adminNote ? `(কারণ: ${adminNote})` : ''}`,
    type: 'PRODUCT_REQUEST_STATUS',
    targetUserId: req.staffId,
    link: '/product-requests',
  });

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: `PRODUCT_REQUEST_${status}`,
    module: 'productRequests',
    recordId: requestId,
    newData: { status, adminNote },
  });
}

// ==========================================
// SOFT DELETE & AUDIT RESTORATION
// ==========================================

export async function softDeleteRecord(params: {
  collectionName: string;
  recordId: string;
  deleteReason: string;
  user: UserProfile;
}): Promise<void> {
  const { collectionName, recordId, deleteReason, user } = params;
  const docRef = doc(db, collectionName, recordId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) throw new Error('Record not found.');

  const existingData = snap.data();
  const now = getNowISO();

  // Save to deleteLogs and deletedRecords
  const deleteLogId = `DEL-${Date.now()}`;
  const deleteLog: DeleteLog = {
    id: deleteLogId,
    collection: collectionName,
    collectionName,
    recordId,
    recordData: existingData,
    deleteReason: deleteReason || 'Deleted by user',
    deletedBy: user.uid,
    deletedByName: user.name,
    deletedAt: now,
    restored: false,
  };

  await setDoc(doc(db, 'deleteLogs', deleteLogId), deleteLog);
  await setDoc(doc(db, 'deletedRecords', deleteLogId), deleteLog);

  // Mark record as soft deleted
  await updateDoc(docRef, {
    deleted: true,
    isDeleted: true,
    deletedBy: user.uid,
    deletedByName: user.name,
    deletedAt: now,
    deleteReason,
  });

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'RECORD_DELETED',
    module: collectionName,
    recordId,
    newData: { deleteReason },
  });
}

export async function restoreDeletedRecord(
  param1: string | { deletedRecordId?: string; deleteLogId?: string; user: UserProfile },
  param2?: UserProfile
): Promise<void> {
  let deleteLogId = '';
  let user: UserProfile | undefined;

  if (typeof param1 === 'object' && param1 !== null) {
    deleteLogId = param1.deletedRecordId || param1.deleteLogId || '';
    user = param1.user;
  } else {
    deleteLogId = param1 as string;
    user = param2;
  }

  if (!user) throw new Error('User context required for restore.');

  let log: DeleteLog | null = null;
  const logRef = doc(db, 'deleteLogs', deleteLogId);
  const snap = await getDoc(logRef);
  if (snap.exists()) {
    log = snap.data() as DeleteLog;
  } else {
    const logRef2 = doc(db, 'deletedRecords', deleteLogId);
    const snap2 = await getDoc(logRef2);
    if (snap2.exists()) {
      log = snap2.data() as DeleteLog;
    }
  }

  if (!log) throw new Error('Delete log not found.');

  const collectionName = log.collection || log.collectionName;
  const docRef = doc(db, collectionName!, log.recordId);

  // Restore document
  await updateDoc(docRef, {
    deleted: false,
    isDeleted: false,
    deletedBy: null,
    deletedAt: null,
    deleteReason: null,
    restoredAt: getNowISO(),
    restoredBy: user.name,
  });

  // Mark as restored in logs
  await updateDoc(logRef, { restored: true }).catch(() => {});
  const logRef2 = doc(db, 'deletedRecords', deleteLogId);
  await updateDoc(logRef2, { restored: true }).catch(() => {});

  await logActivity({
    userId: user.uid,
    userName: user.name,
    action: 'RECORD_RESTORED',
    module: collectionName!,
    recordId: log.recordId,
  });
}

export async function markNotificationAsRead(id: string): Promise<void> {
  try {
    const notifRef = doc(db, 'notifications', id);
    await updateDoc(notifRef, { read: true });
  } catch (err) {
    console.error('Failed to mark notification as read:', err);
  }
}
