import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  signOut as fbSignOut,
  updatePassword as fbUpdatePassword,
  GoogleAuthProvider,
  User,
} from 'firebase/auth';
import { doc, onSnapshot, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile } from '../types';
import { initializeSeedData } from './seed';
import { SUPER_ADMIN_PERMISSIONS } from '../permissions';
import { getNowISO } from '../utils/formatters';

/**
 * The owner account. It must match the e-mail used in firestore.rules.
 * Signing in with this (verified) Google/e-mail account always gives Super Admin access
 * and creates the first profile automatically.
 */
export const OWNER_EMAIL = 'rashedulkarimrm12@gmail.com';

interface AuthContextType {
  currentUser: UserProfile | null;
  firebaseUser: User | null;
  loading: boolean;
  statusError: string | null;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateUserPassword: (newPassword: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const isOwner = (user: User) =>
  (user.email || '').toLowerCase() === OWNER_EMAIL && user.emailVerified;

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [statusError, setStatusError] = useState<string | null>(null);
  const stopProfileRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const stopAuth = onAuthStateChanged(auth, (user) => {
      stopProfileRef.current?.();
      stopProfileRef.current = null;
      setFirebaseUser(user);

      if (!user) {
        setCurrentUser(null);
        setLoading(false);
        return;
      }

      setLoading(true);
      const reject = async (message: string) => {
        setStatusError(message);
        setCurrentUser(null);
        setLoading(false);
        await fbSignOut(auth).catch(() => {});
      };

      // Live profile: role / permission / block changes made by an admin apply immediately.
      stopProfileRef.current = onSnapshot(
        doc(db, 'users', user.uid),
        async (snap) => {
          if (!snap.exists()) {
            if (snap.metadata.fromCache) return; // wait for the server answer
            if (isOwner(user)) {
              const now = getNowISO();
              const owner: UserProfile = {
                uid: user.uid,
                name: user.displayName || 'Super Admin',
                email: user.email || OWNER_EMAIL,
                phone: user.phoneNumber || '',
                staffId: 'EMP-001',
                role: 'super_admin',
                status: 'active',
                designation: 'Managing Director & Super Admin',
                assignedAreas: [],
                permissions: SUPER_ADMIN_PERMISSIONS,
                createdAt: now,
                updatedAt: now,
              };
              try {
                await setDoc(doc(db, 'users', user.uid), owner);
                await initializeSeedData();
              } catch (err) {
                console.error('Owner profile setup failed:', err);
                await reject('প্রোফাইল তৈরি করা যায়নি। Firestore Rules ডিপ্লয় করা আছে কিনা দেখুন।');
              }
              return;
            }
            await reject(
              'এই অ্যাকাউন্টটি সিস্টেমে নিবন্ধিত নয়। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।'
            );
            return;
          }

          const profile = { ...(snap.data() as UserProfile), uid: snap.id };
          // Never keep legacy plain-text passwords in memory
          delete profile.password;
          delete profile.initialPassword;

          if (profile.status === 'blocked') {
            await reject('আপনার অ্যাকাউন্ট ব্লক করা হয়েছে।');
            return;
          }
          if (profile.status === 'suspended') {
            await reject('আপনার অ্যাকাউন্ট সাময়িকভাবে স্থগিত করা হয়েছে।');
            return;
          }

          if (isOwner(user)) {
            profile.role = 'super_admin';
            profile.permissions = { ...profile.permissions, ...SUPER_ADMIN_PERMISSIONS, VIEW_ALL_AREAS: true };
          }

          setStatusError(null);
          setCurrentUser(profile);
          setLoading(false);
        },
        (err) => {
          console.error('Profile listener error:', err);
          setStatusError('প্রোফাইল লোড করা যায়নি। ইন্টারনেট ও Firestore Rules পরীক্ষা করুন।');
          setLoading(false);
        }
      );
    });

    return () => {
      stopAuth();
      stopProfileRef.current?.();
    };
  }, []);

  // Record the last login time once per session (best effort)
  const loggedUidRef = useRef<string | null>(null);
  useEffect(() => {
    if (!currentUser || loggedUidRef.current === currentUser.uid) return;
    loggedUidRef.current = currentUser.uid;
    updateDoc(doc(db, 'users', currentUser.uid), { lastLoginAt: getNowISO() }).catch(() => {});
  }, [currentUser]);

  const login = async (email: string, password: string) => {
    setStatusError(null);
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      throw new Error('ইমেইল এবং পাসওয়ার্ড প্রদান করুন');
    }
    if (!cleanEmail.includes('@')) {
      throw new Error('ইমেইল ঠিকানা দিয়ে লগইন করুন (যেমন: name@example.com)');
    }
    await signInWithEmailAndPassword(auth, cleanEmail, password);
  };

  const loginWithGoogle = async () => {
    setStatusError(null);
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    try {
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      if (err?.code === 'auth/popup-blocked') {
        await signInWithRedirect(auth, provider);
        return;
      }
      throw err;
    }
  };

  const logout = async () => {
    setStatusError(null);
    loggedUidRef.current = null;
    await fbSignOut(auth).catch(() => {});
  };

  const updateUserPassword = async (newPassword: string) => {
    if (!auth.currentUser) throw new Error('লগইন করা নেই');
    await fbUpdatePassword(auth.currentUser, newPassword);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        firebaseUser,
        loading,
        statusError,
        login,
        loginWithGoogle,
        logout,
        updateUserPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
