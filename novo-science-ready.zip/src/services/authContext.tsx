import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as fbSignOut,
  updatePassword as fbUpdatePassword,
  User,
} from 'firebase/auth';
import { doc, onSnapshot, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile } from '../types';
import { initializeSeedData } from './seed';
import { SUPER_ADMIN_PERMISSIONS } from '../permissions';
import { getNowISO } from '../utils/formatters';
import { normalizeUsername, usernameToEmail, FIRST_ADMIN_USERNAME } from './username';

interface AuthContextType {
  currentUser: UserProfile | null;
  firebaseUser: User | null;
  loading: boolean;
  statusError: string | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUserPassword: (newPassword: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [statusError, setStatusError] = useState<string | null>(null);
  const stopProfileRef = useRef<(() => void) | null>(null);
  const provisioningRef = useRef(false); // true while the built-in admin profile is being created

  useEffect(() => {
    const stopAuth = onAuthStateChanged(auth, (user) => {
      stopProfileRef.current?.();
      stopProfileRef.current = null;
      setFirebaseUser(user);

      if (!user) {
        setCurrentUser(null);
        setLoading(false);
        return;
      }

      setLoading(true);
      const reject = async (message: string) => {
        setStatusError(message);
        setCurrentUser(null);
        setLoading(false);
        await fbSignOut(auth).catch(() => {});
      };

      // Live profile: role / permission / block changes made by an admin apply immediately.
      stopProfileRef.current = onSnapshot(
        doc(db, 'users', user.uid),
        async (snap) => {
          if (!snap.exists()) {
            if (snap.metadata.fromCache) return; // wait for the server answer
            if (provisioningRef.current) return; // admin profile is being written right now
            if ((user.email || '').toLowerCase() === usernameToEmail(FIRST_ADMIN_USERNAME)) {
              provisioningRef.current = true;
              try {
                const now = getNowISO();
                const admin: UserProfile = {
                  uid: user.uid,
                  name: 'Bappi',
                  username: FIRST_ADMIN_USERNAME,
                  email: usernameToEmail(FIRST_ADMIN_USERNAME),
                  phone: '',
                  staffId: 'EMP-001',
                  role: 'super_admin',
                  status: 'active',
                  designation: 'Admin',
                  assignedAreas: [],
                  permissions: SUPER_ADMIN_PERMISSIONS,
                  createdAt: now,
                  updatedAt: now,
                };
                await setDoc(doc(db, 'users', user.uid), admin);
                await initializeSeedData().catch((e) => console.error('Seed failed:', e));
              } catch (err) {
                console.error('Admin profile setup failed:', err);
                await reject('অ্যাডমিন প্রোফাইল তৈরি করা যায়নি (Firestore Rules পাবলিশ করা আছে কিনা দেখুন)।');
              } finally {
                provisioningRef.current = false;
              }
              return;
            }
            await reject(
              'এই অ্যাকাউন্টটি সিস্টেমে নিবন্ধিত নয়। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।'
            );
            return;
          }

          const profile = { ...(snap.data() as UserProfile), uid: snap.id };
          // Never keep legacy plain-text passwords in memory
          delete profile.password;
          delete profile.initialPassword;

          if (profile.status === 'blocked') {
            await reject('আপনার অ্যাকাউন্ট ব্লক করা হয়েছে।');
            return;
          }
          if (profile.status === 'suspended') {
            await reject('আপনার অ্যাকাউন্ট সাময়িকভাবে স্থগিত করা হয়েছে।');
            return;
          }

          // Admin = full access, always
          if (profile.role === 'super_admin' || profile.role === 'admin') {
            profile.permissions = { ...profile.permissions, ...SUPER_ADMIN_PERMISSIONS, VIEW_ALL_AREAS: true };
          }

          setStatusError(null);
          setCurrentUser(profile);
          setLoading(false);
        },
        (err) => {
          console.error('Profile listener error:', err);
          setStatusError('প্রোফাইল লোড করা যায়নি। ইন্টারনেট ও Firestore Rules পরীক্ষা করুন।');
          setLoading(false);
        }
      );
    });

    return () => {
      stopAuth();
      stopProfileRef.current?.();
    };
  }, []);

  // Record the last login time once per session (best effort)
  const loggedUidRef = useRef<string | null>(null);
  useEffect(() => {
    if (!currentUser || loggedUidRef.current === currentUser.uid) return;
    loggedUidRef.current = currentUser.uid;
    updateDoc(doc(db, 'users', currentUser.uid), { lastLoginAt: getNowISO() }).catch(() => {});
  }, [currentUser]);

  const login = async (username: string, password: string) => {
    setStatusError(null);
    const clean = normalizeUsername(username);
    if (!clean || !password) {
      throw new Error('ইউজার নাম এবং পাসওয়ার্ড প্রদান করুন');
    }
    await signInWithEmailAndPassword(auth, usernameToEmail(clean), password);
  };

  const logout = async () => {
    setStatusError(null);
    loggedUidRef.current = null;
    await fbSignOut(auth).catch(() => {});
  };

  const updateUserPassword = async (newPassword: string) => {
    if (!auth.currentUser) throw new Error('লগইন করা নেই');
    await fbUpdatePassword(auth.currentUser, newPassword);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        firebaseUser,
        loading,
        statusError,
        login,
        logout,
        updateUserPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
