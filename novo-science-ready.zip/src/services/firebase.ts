import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  Firestore,
  setLogLevel,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

setLogLevel('error');

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);

const databaseId =
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? firebaseConfig.firestoreDatabaseId
    : undefined;

let firestore: Firestore;
try {
  firestore = initializeFirestore(
    app,
    {
      // Works on normal hosting, mobile networks and behind proxies:
      // the SDK switches to long-polling by itself only when streaming is blocked.
      experimentalAutoDetectLongPolling: true,
      // Offline cache: faster reloads and fewer billable reads.
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    },
    databaseId as string
  );
} catch {
  firestore = databaseId ? getFirestore(app, databaseId) : getFirestore(app);
}

export const db = firestore;
export { firebaseConfig };
