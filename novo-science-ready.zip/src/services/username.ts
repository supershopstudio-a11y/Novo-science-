import { UserProfile } from '../types';

/**
 * Firebase Auth needs an e-mail-shaped id. People only ever see / type a username;
 * the app silently turns it into this private, never-used e-mail address.
 */
export const USERNAME_DOMAIN = 'novo-erp.app';

/** The one built-in admin. Its profile is created automatically on its first login. */
export const FIRST_ADMIN_USERNAME = 'bappi';

export const normalizeUsername = (value: string) => value.trim().toLowerCase();

export const usernameToEmail = (username: string) =>
  `${normalizeUsername(username)}@${USERNAME_DOMAIN}`;

export const emailToUsername = (email: string) =>
  (email || '').toLowerCase().endsWith(`@${USERNAME_DOMAIN}`)
    ? email.slice(0, email.length - USERNAME_DOMAIN.length - 1)
    : email || '';

/** Returns an error message (Bengali) or null when the username is fine. */
export function validateUsername(value: string): string | null {
  const u = normalizeUsername(value);
  if (u.length < 3) return 'ইউজার নাম কমপক্ষে ৩ অক্ষরের হতে হবে';
  if (u.length > 30) return 'ইউজার নাম ৩০ অক্ষরের বেশি হতে পারবে না';
  if (!/^[a-z0-9._-]+$/.test(u)) {
    return 'ইউজার নামে শুধু ইংরেজি ছোট অক্ষর (a-z), সংখ্যা এবং . _ - ব্যবহার করা যাবে (স্পেস বা @ নয়)';
  }
  return null;
}

export const userHandle = (u: Pick<UserProfile, 'username' | 'email'> | null | undefined) =>
  u ? u.username || emailToUsername(u.email) : '';

/** Only two profile types are shown: Admin and User. */
export const isAdminRole = (role?: string) => role === 'super_admin' || role === 'admin';
export const roleLabel = (role?: string) => (isAdminRole(role) ? 'অ্যাডমিন' : 'ইউজার');
