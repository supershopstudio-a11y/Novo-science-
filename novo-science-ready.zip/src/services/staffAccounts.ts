import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth, firebaseConfig } from './firebase';

const SECONDARY_APP = 'staff-account-creator';

/**
 * Creates a real Firebase login (email + password) for a staff member WITHOUT
 * signing the current admin out. A second, temporary Firebase app instance is used,
 * because createUserWithEmailAndPassword always signs in as the new user.
 * Returns the new user's uid.
 */
export async function createStaffLogin(email: string, password: string): Promise<string> {
  const secondary =
    getApps().find((a) => a.name === SECONDARY_APP) ?? initializeApp(firebaseConfig, SECONDARY_APP);
  const secondaryAuth = getAuth(secondary);
  try {
    const cred = await createUserWithEmailAndPassword(secondaryAuth, email.trim().toLowerCase(), password);
    return cred.user.uid;
  } finally {
    await signOut(secondaryAuth).catch(() => {});
  }
}

/** Sends a "set a new password" email. Passwords are never stored by this app. */
export async function sendStaffPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim().toLowerCase());
}
