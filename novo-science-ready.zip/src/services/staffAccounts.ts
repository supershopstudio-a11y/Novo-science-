import { initializeApp, getApps } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { firebaseConfig } from './firebase';
import { usernameToEmail } from './username';

const SECONDARY_APP = 'staff-account-creator';

/**
 * Creates a real Firebase login (username + password) for a staff member WITHOUT
 * signing the current admin out. A second, temporary Firebase app instance is used,
 * because createUserWithEmailAndPassword always signs in as the new user.
 * The username is turned into a private e-mail-shaped id internally.
 * Returns the new user's uid.
 */
export async function createStaffLogin(username: string, password: string): Promise<string> {
  const secondary =
    getApps().find((a) => a.name === SECONDARY_APP) ?? initializeApp(firebaseConfig, SECONDARY_APP);
  const secondaryAuth = getAuth(secondary);
  try {
    const cred = await createUserWithEmailAndPassword(secondaryAuth, usernameToEmail(username), password);
    return cred.user.uid;
  } finally {
    await signOut(secondaryAuth).catch(() => {});
  }
}
