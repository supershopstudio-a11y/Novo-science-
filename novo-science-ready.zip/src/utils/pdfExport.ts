import jsPDF from 'jspdf';
import { userHandle } from '../services/username';
import autoTable from 'jspdf-autotable';
import { SystemSettings, Order, Product, Customer, UserProfile } from '../types';
import { formatDate } from './formatters';

interface PnlMetrics {
  totalSales: number;
  totalCogs: number;
  grossProfit: number;
  totalExpenses: number;
  netProfit: number;
  profitMargin: number;
}

interface InventoryMetrics {
  totalCostValuation: number;
  totalRetailValuation: number;
  expectedMargin: number;
  totalUnits: number;
  lowStockCount: number;
}

interface StaffPerformanceItem {
  staffId: string;
  name: string;
  email: string;
  role: string;
  salesCount: number;
  salesAmount: number;
  collectedAmount: number;
}

function formatPdfMoney(amount: number | undefined | null): string {
  const val = Number(amount) || 0;
  return 'BDT ' + val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * Draws professional corporate header and returns the Y coordinate after header
 */
function drawCorporateHeader(
  doc: jsPDF,
  settings: SystemSettings,
  reportTitle: string,
  periodText?: string
): number {
  const pageWidth = doc.internal.pageSize.getWidth();
  let currentY = 16;

  // Header background banner
  doc.setFillColor(248, 250, 252); // slate-50
  doc.rect(0, 0, pageWidth, 42, 'F');

  // Top color line
  doc.setFillColor(30, 64, 175); // blue-700
  doc.rect(0, 0, pageWidth, 4, 'F');

  // Company Name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text((settings.companyName || 'NEOVENTIS BIOTECH').toUpperCase(), 14, currentY);

  // Tagline
  if (settings.tagline) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 64, 175); // blue-700
    doc.text(settings.tagline.toUpperCase(), 14, currentY + 5);
  }

  // Partner info on the right
  if (settings.partnerName) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 58, 138); // blue-900
    doc.text(settings.partnerName, pageWidth - 14, currentY, { align: 'right' });

    if (settings.partnerTagline) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139); // slate-500
      doc.text(settings.partnerTagline, pageWidth - 14, currentY + 4, { align: 'right' });
    }
  }

  // Address and contact line
  const addressLine = settings.companyAddress || settings.address || settings.headOfficeAddress || '';
  const contactLine = [
    addressLine,
    settings.companyPhone || settings.phone ? `Phone: ${settings.companyPhone || settings.phone}` : '',
    settings.companyEmail || settings.email ? `Email: ${settings.companyEmail || settings.email}` : '',
  ]
    .filter(Boolean)
    .join(' | ');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text(contactLine, 14, currentY + 11, { maxWidth: pageWidth - 28 });

  currentY = 48;

  // Report Title Badge & Line
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(30, 58, 138); // blue-900
  doc.text(reportTitle.toUpperCase(), 14, currentY);

  const genDateStr = `Generated: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(genDateStr, pageWidth - 14, currentY, { align: 'right' });

  if (periodText) {
    currentY += 5;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85); // slate-700
    doc.text(`Reporting Period: ${periodText}`, 14, currentY);
  }

  currentY += 4;
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.5);
  doc.line(14, currentY, pageWidth - 14, currentY);

  return currentY + 6;
}

/**
 * Draws footer on all pages
 */
function drawPageFooters(doc: jsPDF): void {
  const pageCount = doc.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.line(14, pageHeight - 12, pageWidth - 14, pageHeight - 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text('Official Confidential Record', 14, pageHeight - 7);

    doc.text(`Page ${i} of ${pageCount}`, pageWidth - 14, pageHeight - 7, { align: 'right' });
  }
}

/**
 * 1. Export Financial Profit & Loss PDF Report
 */
export function exportProfitLossPDF(
  metrics: PnlMetrics,
  settings: SystemSettings,
  startDate: string,
  endDate: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const startY = drawCorporateHeader(
    doc,
    settings,
    'Financial Profit & Loss Statement (লাভ-ক্ষতি রিপোর্ট)',
    `${formatDate(startDate)} to ${formatDate(endDate)}`
  );

  // Summary Metrics Banner Boxes
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxWidth = (pageWidth - 28 - 6) / 2;
  const boxY = startY;

  // Revenue Box
  doc.setFillColor(240, 253, 244); // emerald-50
  doc.setDrawColor(187, 247, 208); // emerald-200
  doc.roundedRect(14, boxY, boxWidth, 18, 2, 2, 'FD');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(22, 101, 52); // emerald-800
  doc.text('TOTAL REVENUE / SALES', 18, boxY + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(formatPdfMoney(metrics.totalSales), 18, boxY + 13);

  // Net Profit Box
  const isProfitPositive = metrics.netProfit >= 0;
  doc.setFillColor(isProfitPositive ? 239 : 254, isProfitPositive ? 246 : 242, isProfitPositive ? 255 : 242);
  doc.setDrawColor(isProfitPositive ? 191 : 254, isProfitPositive ? 219 : 202, isProfitPositive ? 254 : 202);
  doc.roundedRect(14 + boxWidth + 6, boxY, boxWidth, 18, 2, 2, 'FD');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(isProfitPositive ? 30 : 153, isProfitPositive ? 58 : 27, isProfitPositive ? 138 : 27);
  doc.text(`NET PROFIT (MARGIN: ${metrics.profitMargin.toFixed(2)}%)`, 14 + boxWidth + 10, boxY + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(formatPdfMoney(metrics.netProfit), 14 + boxWidth + 10, boxY + 13);

  // Detailed P&L Breakdown Table
  const tableData = [
    ['1. Total Gross Sales (Approved Orders)', formatPdfMoney(metrics.totalSales), 'Gross billed revenue from completed orders'],
    ['2. Cost of Goods Sold (COGS)', `(${formatPdfMoney(metrics.totalCogs)})`, 'Direct product purchase/inventory acquisition cost'],
    ['   = GROSS PROFIT', formatPdfMoney(metrics.grossProfit), 'Revenue minus cost of goods sold'],
    ['3. Operating & Administrative Expenses', `(${formatPdfMoney(metrics.totalExpenses)})`, 'Total recorded business operational costs'],
    ['   = NET PROFIT BEFORE TAX', formatPdfMoney(metrics.netProfit), 'Net earnings for the selected reporting period'],
    ['4. Net Profit Margin (%)', `${metrics.profitMargin.toFixed(2)} %`, 'Net Profit divided by Total Sales'],
  ];

  autoTable(doc, {
    startY: boxY + 23,
    head: [['Financial Line Item', 'Amount (BDT)', 'Notes & Description']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138], // navy blue
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 9,
      halign: 'left',
    },
    columnStyles: {
      0: { cellWidth: 70, fontStyle: 'bold', fontSize: 8.5 },
      1: { cellWidth: 45, halign: 'right', fontStyle: 'bold', fontSize: 8.5 },
      2: { cellWidth: 'auto', fontSize: 7.5, textColor: [100, 116, 139] },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      lineColor: [226, 232, 240],
      lineWidth: 0.2,
      cellPadding: 3.5,
    },
    didParseCell: (data) => {
      // Highlight total rows
      if (data.row.index === 2 || data.row.index === 4) {
        data.cell.styles.fillColor = [241, 245, 249];
        data.cell.styles.textColor = [15, 23, 42];
      }
    },
  });

  drawPageFooters(doc);
  doc.save(`Financial_Profit_Loss_${startDate}_to_${endDate}.pdf`);
}

/**
 * 2. Export Sales Summary PDF Report
 */
export function exportSalesReportPDF(
  orders: Order[],
  settings: SystemSettings,
  startDate: string,
  endDate: string
): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const startY = drawCorporateHeader(
    doc,
    settings,
    'Sales & Invoicing Summary Report (বিক্রয় রিপোর্ট)',
    `${formatDate(startDate)} to ${formatDate(endDate)}`
  );

  const totalVolume = orders.reduce((sum, o) => sum + (o.grandTotal ?? o.finalAmount ?? 0), 0);
  const totalPaid = orders.reduce((sum, o) => sum + (o.paidAmount || 0), 0);
  const totalDue = orders.reduce((sum, o) => sum + (o.dueAmount || 0), 0);

  // Summary Metrics Banner
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxWidth = (pageWidth - 28 - 12) / 4;
  const boxY = startY;

  const boxes = [
    { label: 'TOTAL ORDERS', val: `${orders.length} Invoices`, bg: [239, 246, 255], border: [191, 219, 254], text: [30, 58, 138] },
    { label: 'SALES VOLUME', val: formatPdfMoney(totalVolume), bg: [240, 253, 244], border: [187, 247, 208], text: [22, 101, 52] },
    { label: 'COLLECTIONS (PAID)', val: formatPdfMoney(totalPaid), bg: [240, 253, 250], border: [153, 246, 228], text: [17, 94, 89] },
    { label: 'OUTSTANDING DUE', val: formatPdfMoney(totalDue), bg: [254, 242, 242], border: [254, 202, 202], text: [153, 27, 27] },
  ];

  boxes.forEach((b, idx) => {
    const bx = 14 + idx * (boxWidth + 4);
    doc.setFillColor(b.bg[0], b.bg[1], b.bg[2]);
    doc.setDrawColor(b.border[0], b.border[1], b.border[2]);
    doc.roundedRect(bx, boxY, boxWidth, 14, 2, 2, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(b.text[0], b.text[1], b.text[2]);
    doc.text(b.label, bx + 4, boxY + 5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(b.val, bx + 4, boxY + 11);
  });

  const tableRows = orders.map((o, idx) => [
    idx + 1,
    `#${o.orderId || o.id.slice(-6)}`,
    formatDate(o.date || o.createdAt),
    o.customerName || 'N/A',
    o.areaName || '-',
    o.staffName || '-',
    formatPdfMoney(o.grandTotal ?? o.finalAmount),
    formatPdfMoney(o.paidAmount),
    formatPdfMoney(o.dueAmount),
    o.orderStatus || o.status || 'APPROVED',
  ]);

  autoTable(doc, {
    startY: boxY + 18,
    head: [['#', 'Invoice ID', 'Date', 'Customer Name', 'Area / Zone', 'Sales Officer', 'Total Bill', 'Paid', 'Due', 'Status']],
    body: tableRows,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'center',
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 26, fontStyle: 'bold' },
      2: { cellWidth: 22, halign: 'center' },
      3: { cellWidth: 'auto', fontStyle: 'bold' },
      4: { cellWidth: 32 },
      5: { cellWidth: 28 },
      6: { cellWidth: 28, halign: 'right', fontStyle: 'bold' },
      7: { cellWidth: 26, halign: 'right' },
      8: { cellWidth: 26, halign: 'right', textColor: [185, 28, 28] },
      9: { cellWidth: 22, halign: 'center', fontStyle: 'bold' },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      fontSize: 7.5,
      cellPadding: 2.5,
      lineColor: [226, 232, 240],
      lineWidth: 0.2,
    },
    foot: [[
      '',
      'TOTAL',
      `${orders.length} Invoices`,
      '',
      '',
      '',
      formatPdfMoney(totalVolume),
      formatPdfMoney(totalPaid),
      formatPdfMoney(totalDue),
      '',
    ]],
    footStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'right',
    },
  });

  drawPageFooters(doc);
  doc.save(`Sales_Report_${startDate}_to_${endDate}.pdf`);
}

/**
 * 3. Export Inventory Stock & Valuation PDF Report
 */
export function exportInventoryPDF(
  products: Product[],
  settings: SystemSettings,
  metrics: InventoryMetrics
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const todayStr = new Date().toLocaleDateString('en-GB');
  const startY = drawCorporateHeader(
    doc,
    settings,
    'Inventory Stock & Valuation Report (ইনভেন্টরি রিপোর্ট)',
    `As of ${todayStr}`
  );

  // Summary Metrics Banner
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxWidth = (pageWidth - 28 - 8) / 3;
  const boxY = startY;

  const boxes = [
    { label: 'TOTAL CATALOG ITEMS', val: `${products.length} Products`, sub: `${metrics.totalUnits} Physical Units`, bg: [239, 246, 255], border: [191, 219, 254], text: [30, 58, 138] },
    { label: 'COST VALUATION (PURCHASE)', val: formatPdfMoney(metrics.totalCostValuation), sub: 'Total investment in stock', bg: [240, 253, 244], border: [187, 247, 208], text: [22, 101, 52] },
    { label: 'RETAIL VALUATION (SALES)', val: formatPdfMoney(metrics.totalRetailValuation), sub: `Expected Margin: ${formatPdfMoney(metrics.expectedMargin)}`, bg: [250, 245, 255], border: [233, 213, 255], text: [107, 33, 168] },
  ];

  boxes.forEach((b, idx) => {
    const bx = 14 + idx * (boxWidth + 4);
    doc.setFillColor(b.bg[0], b.bg[1], b.bg[2]);
    doc.setDrawColor(b.border[0], b.border[1], b.border[2]);
    doc.roundedRect(bx, boxY, boxWidth, 16, 2, 2, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(b.text[0], b.text[1], b.text[2]);
    doc.text(b.label, bx + 3.5, boxY + 4.5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(b.val, bx + 3.5, boxY + 9.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(b.sub, bx + 3.5, boxY + 13.5);
  });

  const tableRows = products.map((p, idx) => {
    const costVal = p.currentStock * p.purchasePrice;
    const retailVal = p.currentStock * p.salePrice;
    const isLow = p.currentStock <= p.minimumStock;
    return [
      idx + 1,
      p.sku || '-',
      p.name,
      p.categoryName || 'General',
      `${p.currentStock} ${p.unit}`,
      formatPdfMoney(p.purchasePrice),
      formatPdfMoney(p.salePrice),
      formatPdfMoney(costVal),
      formatPdfMoney(retailVal),
      isLow ? 'LOW STOCK' : 'IN STOCK',
    ];
  });

  autoTable(doc, {
    startY: boxY + 21,
    head: [['#', 'SKU', 'Product Name', 'Category', 'Stock', 'Cost Price', 'Sale Price', 'Cost Value', 'Retail Value', 'Status']],
    body: tableRows,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      halign: 'center',
    },
    columnStyles: {
      0: { cellWidth: 8, halign: 'center' },
      1: { cellWidth: 20, fontStyle: 'bold' },
      2: { cellWidth: 'auto', fontStyle: 'bold' },
      3: { cellWidth: 25 },
      4: { cellWidth: 16, halign: 'center', fontStyle: 'bold' },
      5: { cellWidth: 18, halign: 'right' },
      6: { cellWidth: 18, halign: 'right' },
      7: { cellWidth: 22, halign: 'right', fontStyle: 'bold' },
      8: { cellWidth: 22, halign: 'right' },
      9: { cellWidth: 18, halign: 'center', fontStyle: 'bold' },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      fontSize: 7,
      cellPadding: 2,
      lineColor: [226, 232, 240],
      lineWidth: 0.2,
    },
    foot: [[
      '',
      'TOTAL',
      `${products.length} Products`,
      '',
      `${metrics.totalUnits} Units`,
      '',
      '',
      formatPdfMoney(metrics.totalCostValuation),
      formatPdfMoney(metrics.totalRetailValuation),
      '',
    ]],
    footStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 7.5,
      halign: 'right',
    },
  });

  drawPageFooters(doc);
  doc.save(`Inventory_Valuation_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
}

/**
 * 4. Export Due Summary PDF Report
 */
export function exportDueSummaryPDF(
  customers: Customer[],
  settings: SystemSettings
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const todayStr = new Date().toLocaleDateString('en-GB');
  const startY = drawCorporateHeader(
    doc,
    settings,
    'Customer Outstanding Due Report (গ্রাহক বকেয়া খতিয়ান)',
    `As of ${todayStr}`
  );

  const dueCustomers = customers.filter((c) => (c.currentDue || 0) > 0);
  const totalDue = dueCustomers.reduce((sum, c) => sum + (c.currentDue || 0), 0);

  // Summary Metrics Banner
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxWidth = (pageWidth - 28 - 6) / 2;
  const boxY = startY;

  // Total Accounts Box
  doc.setFillColor(254, 242, 242); // rose-50
  doc.setDrawColor(254, 202, 202); // rose-200
  doc.roundedRect(14, boxY, boxWidth, 16, 2, 2, 'FD');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(153, 27, 27);
  doc.text('ACCOUNTS WITH OUTSTANDING DUE', 18, boxY + 5.5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text(`${dueCustomers.length} Customers`, 18, boxY + 12);

  // Total Due Amount Box
  doc.setFillColor(255, 241, 242);
  doc.setDrawColor(254, 205, 211);
  doc.roundedRect(14 + boxWidth + 6, boxY, boxWidth, 16, 2, 2, 'FD');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(159, 18, 57);
  doc.text('TOTAL OUTSTANDING BALANCE', 14 + boxWidth + 10, boxY + 5.5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text(formatPdfMoney(totalDue), 14 + boxWidth + 10, boxY + 12);

  const tableRows = dueCustomers.map((c, idx) => [
    idx + 1,
    c.name,
    c.businessName || '-',
    c.areaName || '-',
    c.phone || '-',
    formatPdfMoney(c.currentDue),
  ]);

  autoTable(doc, {
    startY: boxY + 21,
    head: [['#', 'Customer Name', 'Business / Pharmacy', 'Territory Zone', 'Phone', 'Outstanding Due']],
    body: tableRows,
    theme: 'grid',
    headStyles: {
      fillColor: [159, 18, 57], // deep rose/wine
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 'auto', fontStyle: 'bold' },
      2: { cellWidth: 45 },
      3: { cellWidth: 35 },
      4: { cellWidth: 30 },
      5: { cellWidth: 35, halign: 'right', fontStyle: 'bold', textColor: [185, 28, 28] },
    },
    alternateRowStyles: {
      fillColor: [255, 248, 248],
    },
    styles: {
      fontSize: 8,
      cellPadding: 3,
      lineColor: [226, 232, 240],
      lineWidth: 0.2,
    },
    foot: [[
      '',
      'TOTAL OUTSTANDING DUE',
      `${dueCustomers.length} Parties`,
      '',
      '',
      formatPdfMoney(totalDue),
    ]],
    footStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'right',
    },
  });

  drawPageFooters(doc);
  doc.save(`Customer_Due_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
}

/**
 * 5. Export Staff Sales & KPI Performance PDF Report
 */
export function exportStaffPerformancePDF(
  staffList: StaffPerformanceItem[],
  settings: SystemSettings,
  startDate: string,
  endDate: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const startY = drawCorporateHeader(
    doc,
    settings,
    'Staff Sales & KPI Performance Report (কর্মকর্তা পারফরম্যান্স)',
    `${formatDate(startDate)} to ${formatDate(endDate)}`
  );

  const totalSales = staffList.reduce((sum, s) => sum + s.salesAmount, 0);
  const totalCollections = staffList.reduce((sum, s) => sum + s.collectedAmount, 0);
  const totalOrders = staffList.reduce((sum, s) => sum + s.salesCount, 0);

  // Summary Metrics Banner
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxWidth = (pageWidth - 28 - 8) / 3;
  const boxY = startY;

  const boxes = [
    { label: 'TOTAL ACTIVE STAFF', val: `${staffList.length} Officers`, bg: [239, 246, 255], border: [191, 219, 254], text: [30, 58, 138] },
    { label: 'TOTAL SALES VOLUME', val: formatPdfMoney(totalSales), bg: [240, 253, 244], border: [187, 247, 208], text: [22, 101, 52] },
    { label: 'TOTAL COLLECTIONS', val: formatPdfMoney(totalCollections), bg: [240, 253, 250], border: [153, 246, 228], text: [17, 94, 89] },
  ];

  boxes.forEach((b, idx) => {
    const bx = 14 + idx * (boxWidth + 4);
    doc.setFillColor(b.bg[0], b.bg[1], b.bg[2]);
    doc.setDrawColor(b.border[0], b.border[1], b.border[2]);
    doc.roundedRect(bx, boxY, boxWidth, 15, 2, 2, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(b.text[0], b.text[1], b.text[2]);
    doc.text(b.label, bx + 3.5, boxY + 5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(b.val, bx + 3.5, boxY + 11);
  });

  const tableRows = staffList.map((s, idx) => [
    idx + 1,
    s.name,
    userHandle({ email: s.email }),
    s.role === 'super_admin' || s.role === 'admin' ? 'ADMIN' : 'USER',
    s.salesCount,
    formatPdfMoney(s.salesAmount),
    formatPdfMoney(s.collectedAmount),
  ]);

  autoTable(doc, {
    startY: boxY + 20,
    head: [['#', 'Staff Name', 'Email', 'Role', 'Orders Count', 'Sales Volume', 'Collections']],
    body: tableRows,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 'auto', fontStyle: 'bold' },
      2: { cellWidth: 45, fontSize: 7.5 },
      3: { cellWidth: 26, halign: 'center', fontSize: 7.5 },
      4: { cellWidth: 24, halign: 'center', fontStyle: 'bold' },
      5: { cellWidth: 32, halign: 'right', fontStyle: 'bold' },
      6: { cellWidth: 32, halign: 'right', textColor: [16, 122, 87] },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      fontSize: 8,
      cellPadding: 3,
      lineColor: [226, 232, 240],
      lineWidth: 0.2,
    },
    foot: [[
      '',
      'TOTAL SUMMARY',
      '',
      '',
      `${totalOrders} Orders`,
      formatPdfMoney(totalSales),
      formatPdfMoney(totalCollections),
    ]],
    footStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'right',
    },
  });

  drawPageFooters(doc);
  doc.save(`Staff_Performance_${startDate}_to_${endDate}.pdf`);
}
