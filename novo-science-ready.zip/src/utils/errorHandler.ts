/**
 * Friendly Error Handler mapping technical or Firebase errors into clear, actionable messages
 */
export function getFriendlyErrorMessage(error: any): string {
  if (!error) return 'একটি অজানা ত্রুটি ঘটেছে (An unknown error occurred)';
  const msg = typeof error === 'string' ? error : error.message || error.code || '';

  // Specific prompt messages
  if (msg.includes('permission-denied') || msg.includes('Missing or insufficient permissions')) {
    return 'আপনার এই কাজটি করার অনুমতি নেই। (You do not have permission for this action.)';
  }
  if (msg.includes('Insufficient stock') || msg.includes('পর্যাপ্ত পণ্য নেই')) {
    return 'স্টকে পর্যাপ্ত পণ্য নেই। (Insufficient stock available.)';
  }
  if (msg.includes('Order cannot be approved') || msg.includes('already approved')) {
    return 'অর্ডারটি ইতিমধ্যে অনুমোদিত হয়েছে। (The order is already approved.)';
  }
  if (msg.includes('Payment amount') || msg.includes('পেমেন্টের পরিমাণ')) {
    return 'পেমেন্টের পরিমাণ সঠিক নয়। (Invalid payment amount.)';
  }
  if (msg.includes('the client is offline') || msg.includes('network-request-failed')) {
    return 'ইন্টারনেট সংযোগ পরীক্ষা করুন। (Please check your internet connection.)';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/user-not-found') || msg.includes('auth/wrong-password')) {
    return 'ভুল ইমেইল অথবা পাসওয়ার্ড। (Invalid email or password.)';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return 'এই ইমেইলটি ইতিমধ্যে নিবন্ধিত রয়েছে। (Email is already in use.)';
  }
  if (msg.includes('auth/weak-password')) {
    return 'পাসওয়ার্ডটি অন্তত ৬ অক্ষরের হতে হবে। (Password must be at least 6 characters.)';
  }
  if (msg.includes('auth/operation-not-allowed')) {
    return 'ইমেইল/পাসওয়ার্ড লগইন Firebase Console-এ সক্রিয় নয়। অনুগ্রহ করে "Google দিয়ে লগইন করুন" বা Firebase Console > Authentication-এ Email/Password প্রদানকারী চালু করুন। (Email/Password is not enabled in Firebase Console. Please use "Sign in with Google".)';
  }
  if (msg.includes('auth/requires-recent-login')) {
    return 'নিরাপত্তার জন্য আবার লগইন করে পাসওয়ার্ড পরিবর্তন করুন। (Please sign in again, then change your password.)';
  }
  if (msg.includes('auth/too-many-requests')) {
    return 'অনেকবার ভুল চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন। (Too many attempts. Try again later.)';
  }
  if (msg.includes('auth/unauthorized-domain')) {
    return 'এই ওয়েবসাইটের ডোমেইন Firebase Console > Authentication > Settings > Authorized domains-এ যোগ করুন। (Domain is not authorized in Firebase.)';
  }
  if (msg.includes('auth/invalid-email')) {
    return 'ইমেইল ঠিকানাটি সঠিক নয়। (Invalid email address.)';
  }
  if (msg.includes('auth/popup-closed-by-user')) {
    return 'Google সাইন-ইন উইন্ডো বন্ধ করা হয়েছে। আবার চেষ্টা করুন। (Sign-in popup was closed. Please try again.)';
  }

  return msg;
}
