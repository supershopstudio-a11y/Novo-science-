/**
 * Utility functions for exporting data to CSV and handling document printing
 */

export function exportToCSV(param1: any, param2: any): void {
  let filename = 'export';
  let rows: Record<string, any>[] = [];

  if (typeof param1 === 'string') {
    filename = param1;
    rows = Array.isArray(param2) ? param2 : [];
  } else if (Array.isArray(param1)) {
    rows = param1;
    filename = typeof param2 === 'string' ? param2 : 'export';
  }

  if (!rows || !rows.length) {
    return;
  }

  const headers = Object.keys(rows[0]);
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      headers
        .map((header) => {
          let cell = row[header];
          if (cell === null || cell === undefined) {
            cell = '';
          } else if (typeof cell === 'object') {
            cell = JSON.stringify(cell);
          } else {
            cell = String(cell);
          }
          // Escape quotes
          cell = cell.replace(/"/g, '""');
          if (cell.search(/("|,|\n)/g) >= 0) {
            cell = `"${cell}"`;
          }
          return cell;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function printElement(elementId: string): void {
  const elem = document.getElementById(elementId);
  if (!elem) {
    window.print();
    return;
  }
  window.print();
}
