export function formatCurrency(amount: number | undefined | null, symbol: string = '৳'): string {
  if (amount === undefined || amount === null || isNaN(amount)) {
    return `${symbol}0.00`;
  }
  const formatted = new Intl.NumberFormat('en-BD', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
  return `${symbol}${formatted}`;
}

export function formatDate(dateString: string | undefined | null): string {
  if (!dateString) return '-';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Dhaka',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function formatDateTime(dateString: string | undefined | null): string {
  if (!dateString) return '-';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Dhaka',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).format(d);
  } catch {
    return dateString;
  }
}

export function getNowISO(): string {
  return new Date().toISOString();
}

export type DateFilterType =
  | 'all'
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'this_month'
  | 'last_month'
  | 'this_year'
  | 'custom';

export interface DateRange {
  startDate?: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
}

export function getDateRange(filterType: DateFilterType, customRange?: DateRange): { start: Date | null; end: Date | null } {
  const now = new Date();
  
  // Set in Bangladesh timezone context
  const startOfDay = (d: Date) => {
    const res = new Date(d);
    res.setHours(0, 0, 0, 0);
    return res;
  };

  const endOfDay = (d: Date) => {
    const res = new Date(d);
    res.setHours(23, 59, 59, 999);
    return res;
  };

  switch (filterType) {
    case 'today': {
      return {
        start: startOfDay(now),
        end: endOfDay(now),
      };
    }
    case 'yesterday': {
      const yesterday = new Date(now);
      yesterday.setDate(now.getDate() - 1);
      return {
        start: startOfDay(yesterday),
        end: endOfDay(yesterday),
      };
    }
    case 'this_week': {
      const startOfWeek = new Date(now);
      const day = now.getDay();
      const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Monday start
      startOfWeek.setDate(diff);
      return {
        start: startOfDay(startOfWeek),
        end: endOfDay(now),
      };
    }
    case 'this_month': {
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      return {
        start: startOfDay(startOfMonth),
        end: endOfDay(now),
      };
    }
    case 'last_month': {
      const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
      return {
        start: startOfDay(startOfLastMonth),
        end: endOfDay(endOfLastMonth),
      };
    }
    case 'this_year': {
      const startOfYear = new Date(now.getFullYear(), 0, 1);
      return {
        start: startOfDay(startOfYear),
        end: endOfDay(now),
      };
    }
    case 'custom': {
      if (!customRange?.startDate) return { start: null, end: null };
      const s = startOfDay(new Date(customRange.startDate));
      const e = customRange.endDate ? endOfDay(new Date(customRange.endDate)) : endOfDay(s);
      return { start: s, end: e };
    }
    case 'all':
    default:
      return { start: null, end: null };
  }
}

export function isDateInRange(dateStr: string, range: { start: Date | null; end: Date | null }): boolean {
  if (!range.start && !range.end) return true;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return true;
  if (range.start && d < range.start) return false;
  if (range.end && d > range.end) return false;
  return true;
}


/**
 * Collision-safe document id such as ORD-261028-K7Q2X.
 * (The old `Date.now().slice(-6)` repeated every ~16 minutes and could overwrite records.)
 */
export function generateId(prefix: string): string {
  const d = new Date();
  const yy = String(d.getFullYear()).slice(-2);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const rand = Array.from(crypto.getRandomValues(new Uint8Array(4)))
    .map((b) => b.toString(36).padStart(2, '0').slice(-2))
    .join('')
    .toUpperCase();
  return `${prefix}-${yy}${mm}${dd}-${rand}`;
}
