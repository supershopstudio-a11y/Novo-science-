import { UserPermissions, UserProfile } from '../types';

export interface PermissionGroup {
  id: string;
  name: string;
  permissions: {
    key: keyof UserPermissions;
    label: string;
    description: string;
    type: 'view' | 'create' | 'edit' | 'delete' | 'approve' | 'other';
  }[];
}

export const PERMISSION_MODULES: PermissionGroup[] = [
  {
    id: 'orders',
    name: 'Orders',
    permissions: [
      { key: 'order.view', label: 'View Orders', description: 'Browse and search sales orders', type: 'view' },
      { key: 'order.create', label: 'Create Order', description: 'Create new pending orders', type: 'create' },
      { key: 'order.edit', label: 'Edit Order', description: 'Modify pending orders', type: 'edit' },
      { key: 'order.delete', label: 'Delete Order', description: 'Soft delete orders', type: 'delete' },
      { key: 'order.approve', label: 'Approve Order', description: 'Approve pending orders to issue invoices and decrease stock', type: 'approve' },
      { key: 'order.reject', label: 'Reject Order', description: 'Reject pending orders', type: 'other' },
      { key: 'order.cancel', label: 'Cancel Order', description: 'Cancel orders and reverse inventory/dues', type: 'other' },
    ],
  },
  {
    id: 'customers',
    name: 'Customers',
    permissions: [
      { key: 'customer.view', label: 'View Customers', description: 'View customer directory and profiles', type: 'view' },
      { key: 'customer.create', label: 'Add Customer', description: 'Register new customers in areas', type: 'create' },
      { key: 'customer.edit', label: 'Edit Customer', description: 'Update customer information', type: 'edit' },
      { key: 'customer.delete', label: 'Delete Customer', description: 'Delete or archive customers', type: 'delete' },
      { key: 'customer.viewDue', label: 'View Customer Due', description: 'View customer outstanding due balances', type: 'other' },
    ],
  },
  {
    id: 'products',
    name: 'Products',
    permissions: [
      { key: 'product.view', label: 'View Products', description: 'View catalog and stock items', type: 'view' },
      { key: 'product.create', label: 'Add Product (নতুন পণ্য যোগ)', description: 'Create new catalog products (সুপার এডমিনের কাছে থাকে, চাইলে যে কাউকে দিতে পারে)', type: 'create' },
      { key: 'product.edit', label: 'Edit Product', description: 'Update product prices and details', type: 'edit' },
      { key: 'product.delete', label: 'Delete Product', description: 'Deactivate or delete products', type: 'delete' },
      { key: 'product.request', label: 'Request Products', description: 'Submit stock requisitions for staff', type: 'other' },
    ],
  },
  {
    id: 'inventory',
    name: 'Inventory',
    permissions: [
      { key: 'inventory.view', label: 'View Inventory', description: 'Check stock levels and audit transactions', type: 'view' },
      { key: 'inventory.add', label: 'Add Stock Items', description: 'Add new items to inventory', type: 'create' },
      { key: 'inventory.edit', label: 'Edit Inventory Info', description: 'Update inventory details', type: 'edit' },
      { key: 'inventory.stockIn', label: 'Stock In', description: 'Perform stock in receipt operations', type: 'other' },
      { key: 'inventory.stockOut', label: 'Stock Out', description: 'Issue manual stock out', type: 'other' },
      { key: 'inventory.adjust', label: 'Adjust Stock', description: 'Correct discrepancies in stock', type: 'other' },
      { key: 'inventory.transfer', label: 'Transfer Stock', description: 'Transfer stock between warehouses/areas', type: 'other' },
    ],
  },
  {
    id: 'sales',
    name: 'Sales',
    permissions: [
      { key: 'sales.view', label: 'View Sales', description: 'View personal or assigned sales records', type: 'view' },
      { key: 'sales.viewAll', label: 'View All Sales', description: 'View sales across all staff and areas', type: 'other' },
      { key: 'sales.create', label: 'Create Sales', description: 'Issue direct sales / orders', type: 'create' },
      { key: 'sales.edit', label: 'Edit Sales', description: 'Modify sales records', type: 'edit' },
      { key: 'sales.delete', label: 'Delete Sales', description: 'Delete sales records', type: 'delete' },
    ],
  },
  {
    id: 'invoices',
    name: 'Invoices',
    permissions: [
      { key: 'invoice.view', label: 'View Invoices', description: 'Browse and search sales invoices', type: 'view' },
      { key: 'invoice.create', label: 'Create Invoice', description: 'Generate invoices directly', type: 'create' },
      { key: 'invoice.edit', label: 'Edit Invoice', description: 'Edit existing invoices', type: 'edit' },
      { key: 'invoice.print', label: 'Print Invoice', description: 'Print and download invoices', type: 'other' },
      { key: 'invoice.reprint', label: 'Reprint Invoice', description: 'Reprint historical invoices', type: 'other' },
    ],
  },
  {
    id: 'reports',
    name: 'Reports',
    permissions: [
      { key: 'report.view', label: 'View Reports', description: 'Access analytical reports & metrics', type: 'view' },
      { key: 'report.export', label: 'Export Reports', description: 'Download CSV and Excel files', type: 'other' },
      { key: 'report.print', label: 'Print Reports', description: 'Print summary and performance reports', type: 'other' },
    ],
  },
  {
    id: 'expenses',
    name: 'Expenses',
    permissions: [
      { key: 'expense.view', label: 'View Expenses', description: 'View business operational expenses', type: 'view' },
      { key: 'expense.create', label: 'Add Expense', description: 'Record new business expenses', type: 'create' },
      { key: 'expense.edit', label: 'Edit Expense', description: 'Update expense entries', type: 'edit' },
      { key: 'expense.delete', label: 'Delete Expense', description: 'Delete expense entries', type: 'delete' },
    ],
  },
  {
    id: 'staff',
    name: 'Staff & Roles',
    permissions: [
      { key: 'staff.view', label: 'View Staff', description: 'View staff directory and profiles', type: 'view' },
      { key: 'staff.create', label: 'Create Staff', description: 'Add new staff accounts', type: 'create' },
      { key: 'staff.edit', label: 'Edit Staff', description: 'Update staff details and area assignments', type: 'edit' },
      { key: 'staff.delete', label: 'Delete Staff', description: 'Suspend or delete staff', type: 'delete' },
      { key: 'staff.managePermissions', label: 'Manage Permissions', description: 'Configure granular permissions for users', type: 'other' },
    ],
  },
  {
    id: 'settings',
    name: 'Settings',
    permissions: [
      { key: 'settings.view', label: 'View Settings', description: 'View company and system configuration', type: 'view' },
      { key: 'settings.edit', label: 'Edit Settings', description: 'Modify company profile and business rules', type: 'edit' },
    ],
  },
  {
    id: 'areas',
    name: 'Areas',
    permissions: [
      { key: 'VIEW_ALL_AREAS', label: 'View All Areas', description: 'Bypass assigned area restrictions to see all regions', type: 'other' },
    ],
  },
];

// All permission keys as true for super admin
export const SUPER_ADMIN_PERMISSIONS: UserPermissions = (() => {
  const perms: UserPermissions = {
    // Upper-case legacy mappings
    CREATE_ORDER: true,
    APPROVE_ORDER: true,
    CANCEL_ORDER: true,
    COLLECT_PAYMENT: true,
    VIEW_ALL_AREAS: true,
    MANAGE_PRODUCTS: true,
    ADD_PRODUCT: true,
    'product.create': true,
    ADD_CUSTOMER: true,
    'customer.create': true,
    MANAGE_EXPENSES: true,
    VIEW_REPORTS: true,
    MANAGE_STAFF: true,
  };
  PERMISSION_MODULES.forEach((m) => {
    m.permissions.forEach((p) => {
      perms[p.key] = true;
    });
  });
  return perms;
})();

// Helper to determine if a user profile is Super Admin
export function isSuperAdminUser(user: UserProfile | null | undefined): boolean {
  if (!user) return false;
  const role = user.role ? String(user.role).toLowerCase() : '';
  // If role is explicitly admin or staff, they are strictly NOT super admin!
  if (role === 'admin' || role === 'staff') {
    return false;
  }
  return role === 'super_admin' || role === 'superadmin';
}

// Admin default permissions
export const ADMIN_DEFAULT_PERMISSIONS: UserPermissions = {
  ...SUPER_ADMIN_PERMISSIONS,
  'staff.delete': false, // Super Admin preserves exclusive deletion rights
  'ADD_CUSTOMER': false, // Super Admin decides whether to grant customer creation
  'customer.create': false,
  'ADD_PRODUCT': false, // Super Admin decides whether to grant product addition (নতুন পণ্য যোগ এক্সেস)
  'product.create': false,
};

// Staff default permissions
export const STAFF_DEFAULT_PERMISSIONS: UserPermissions = {
  'order.view': true,
  'order.create': true,
  'order.edit': true,
  'order.delete': false,
  'order.approve': false,
  'order.reject': false,
  'order.cancel': false,

  'customer.view': true,
  'customer.create': false, // Default: Super Admin decides whether to give customer add permission
  'ADD_CUSTOMER': false,
  'customer.edit': true,
  'customer.delete': false,
  'customer.viewDue': true,

  'product.view': true,
  'product.create': false, // Default: Super Admin decides whether to give product add permission
  'ADD_PRODUCT': false,
  'product.edit': false,
  'product.delete': false,
  'product.request': true,

  'inventory.view': true,
  'inventory.add': false,
  'inventory.edit': false,
  'inventory.stockIn': false,
  'inventory.stockOut': false,
  'inventory.adjust': false,
  'inventory.transfer': false,

  'sales.view': true,
  'sales.viewAll': false,
  'sales.create': true,
  'sales.edit': false,
  'sales.delete': false,

  'invoice.view': true,
  'invoice.create': false,
  'invoice.edit': false,
  'invoice.print': true,
  'invoice.reprint': true,

  'report.view': false,
  'report.export': false,
  'report.print': false,

  'expense.view': false,
  'expense.create': false,
  'expense.edit': false,
  'expense.delete': false,

  'staff.view': false,
  'staff.create': false,
  'staff.edit': false,
  'staff.delete': false,
  'staff.managePermissions': false,

  'settings.view': false,
  'settings.edit': false,

  'VIEW_ALL_AREAS': false,
};

export function checkPermission(user: UserProfile | null | undefined, permission: string | keyof UserPermissions): boolean {
  if (!user) return false;
  // Super Admin has absolute unrestricted access to everything
  if (isSuperAdminUser(user)) return true;
  if (user.status !== 'active') return false;

  const perms = user.permissions || {};
  const p = String(permission);

  // 1. PRODUCT ADD (নতুন পণ্য যোগ করার এক্সেস: সুপার এডমিনের কাছে থাকবে, চাইলে যে কাউকে দিতে পারে)
  if (p === 'product.create' || p === 'ADD_PRODUCT') {
    if (perms['ADD_PRODUCT'] === true || perms['product.create'] === true) {
      return true;
    }
    // Must be explicitly granted by super admin; otherwise strictly denied
    return false;
  }

  // 2. PRODUCTS & INVENTORY (পণ্য ও স্টক পরিচালনা)
  if (
    p === 'MANAGE_PRODUCTS' ||
    p.startsWith('product.') ||
    p.startsWith('inventory.')
  ) {
    if (perms['MANAGE_PRODUCTS'] === true) return true;
    if (perms['MANAGE_PRODUCTS'] === false) return false;

    if (perms[p] !== undefined) return Boolean(perms[p]);

    // Product viewing for placing sales orders
    if (p === 'product.view' && (perms['CREATE_ORDER'] || perms['order.create'])) {
      return true;
    }
    return false;
  }

  // 2. CUSTOMER ADD (কাস্টমার এড করার অপশন: সুপার এডমিন চাইলে দিবে, না চাইলে দিবে না)
  if (p === 'customer.create' || p === 'ADD_CUSTOMER') {
    if (perms['ADD_CUSTOMER'] === true || perms['customer.create'] === true) {
      return true;
    }
    // Must be explicitly granted by super admin; otherwise denied
    return false;
  }

  // 3. CUSTOMER VIEW & DIRECTORY
  if (p === 'customer.view' || p === 'VIEW_CUSTOMERS') {
    if (perms['ADD_CUSTOMER'] === true || perms['customer.create'] === true) return true;
    if (perms['VIEW_CUSTOMERS'] === false) return false;
    if (
      perms['VIEW_CUSTOMERS'] === true ||
      perms['COLLECT_PAYMENT'] === true ||
      perms['customer.collectDue'] === true ||
      perms['CREATE_ORDER'] === true ||
      perms['order.create'] === true
    ) {
      return true;
    }
    return Boolean(perms['customer.view']);
  }

  // 4. CUSTOMER EDIT & DELETE
  if (p === 'customer.edit') {
    if (perms['customer.edit'] !== undefined) return Boolean(perms['customer.edit']);
    return Boolean(perms['ADD_CUSTOMER'] || perms['customer.create']);
  }
  if (p === 'customer.delete') {
    return Boolean(perms['customer.delete']);
  }

  // 5. CUSTOMER DUE & PAYMENT COLLECTION
  if (p === 'customer.collectDue' || p === 'customer.viewDue' || p === 'COLLECT_PAYMENT') {
    return Boolean(perms['COLLECT_PAYMENT'] || perms['customer.collectDue'] || perms['customer.viewDue']);
  }

  // 6. ORDERS & SALES
  if (p === 'order.create' || p === 'CREATE_ORDER' || p === 'sales.create') {
    return Boolean(perms['CREATE_ORDER'] || perms['order.create']);
  }
  if (p === 'order.approve' || p === 'APPROVE_ORDER') {
    return Boolean(perms['APPROVE_ORDER'] || perms['order.approve']);
  }
  if (p === 'order.cancel' || p === 'CANCEL_ORDER') {
    return Boolean(perms['CANCEL_ORDER'] || perms['order.cancel']);
  }
  if (p === 'order.reject') {
    return Boolean(perms['APPROVE_ORDER'] || perms['CANCEL_ORDER'] || perms['order.approve'] || perms['order.cancel']);
  }
  if (p === 'order.view' || p === 'sales.view' || p === 'invoice.view' || p === 'invoice.print') {
    return Boolean(
      perms['CREATE_ORDER'] ||
      perms['APPROVE_ORDER'] ||
      perms['CANCEL_ORDER'] ||
      perms['order.view'] ||
      perms['sales.view'] ||
      perms['invoice.view']
    );
  }
  if (p === 'sales.viewAll') {
    return Boolean(perms['VIEW_ALL_AREAS'] || perms['APPROVE_ORDER']);
  }

  // 7. EXPENSES
  if (p.startsWith('expense.') || p === 'MANAGE_EXPENSES') {
    return Boolean(perms['MANAGE_EXPENSES'] || perms['expense.view'] || perms['expense.create']);
  }

  // 8. REPORTS
  if (p.startsWith('report.') || p === 'VIEW_REPORTS') {
    return Boolean(perms['VIEW_REPORTS'] || perms['report.view']);
  }

  // 9. STAFF & ROLES
  if (p.startsWith('staff.') || p === 'MANAGE_STAFF') {
    return Boolean(perms['MANAGE_STAFF'] || perms['staff.view'] || perms['staff.managePermissions']);
  }

  // 10. AREAS
  if (p === 'VIEW_ALL_AREAS') {
    return Boolean(perms['VIEW_ALL_AREAS']);
  }

  // 11. SETTINGS & LOGS
  if (p.startsWith('settings.') || p === 'MANAGE_SETTINGS') {
    return Boolean(perms['MANAGE_SETTINGS'] || perms['MANAGE_STAFF'] || perms['settings.view']);
  }

  // Direct check fallback
  if (perms[permission] !== undefined) {
    return Boolean(perms[permission]);
  }

  return false;
}

export function canAccessArea(user: UserProfile | null | undefined, areaId: string): boolean {
  if (!user) return false;
  if (isSuperAdminUser(user) || user.permissions?.VIEW_ALL_AREAS) return true;
  return user.assignedAreas?.includes(areaId) ?? false;
}
