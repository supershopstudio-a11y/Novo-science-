export type UserRole = 'super_admin' | 'admin' | 'staff';
export type Role = UserRole;
export type AccountStatus = 'active' | 'suspended' | 'blocked';

export interface UserPermissions {
  // Orders
  'order.view'?: boolean;
  'order.create'?: boolean;
  'order.edit'?: boolean;
  'order.delete'?: boolean;
  'order.approve'?: boolean;
  'order.reject'?: boolean;
  'order.cancel'?: boolean;

  // Customer
  'customer.view'?: boolean;
  'customer.create'?: boolean;
  'customer.edit'?: boolean;
  'customer.delete'?: boolean;
  'customer.viewDue'?: boolean;

  // Product
  'product.view'?: boolean;
  'product.create'?: boolean;
  'ADD_PRODUCT'?: boolean;
  'product.edit'?: boolean;
  'product.delete'?: boolean;
  'product.request'?: boolean;

  // Inventory
  'inventory.view'?: boolean;
  'inventory.add'?: boolean;
  'inventory.edit'?: boolean;
  'inventory.stockIn'?: boolean;
  'inventory.stockOut'?: boolean;
  'inventory.adjust'?: boolean;
  'inventory.transfer'?: boolean;

  // Sales
  'sales.create'?: boolean;
  'sales.edit'?: boolean;
  'sales.delete'?: boolean;
  'sales.view'?: boolean;
  'sales.viewAll'?: boolean;

  // Invoice
  'invoice.view'?: boolean;
  'invoice.create'?: boolean;
  'invoice.edit'?: boolean;
  'invoice.print'?: boolean;
  'invoice.reprint'?: boolean;

  // Report
  'report.view'?: boolean;
  'report.export'?: boolean;
  'report.print'?: boolean;

  // Expense
  'expense.view'?: boolean;
  'expense.create'?: boolean;
  'expense.edit'?: boolean;
  'expense.delete'?: boolean;

  // Staff
  'staff.view'?: boolean;
  'staff.create'?: boolean;
  'staff.edit'?: boolean;
  'staff.delete'?: boolean;
  'staff.managePermissions'?: boolean;

  // Settings
  'settings.view'?: boolean;
  'settings.edit'?: boolean;

  // Area
  'VIEW_ALL_AREAS'?: boolean;

  [key: string]: boolean | undefined;
}

export interface UserProfile {
  id?: string;
  uid: string;
  name: string;
  username?: string;
  email: string;
  phone?: string;
  staffId?: string;
  role: UserRole;
  status: AccountStatus;
  designation?: string;
  photoURL?: string;
  assignedAreas: string[]; // Area IDs
  permissions: UserPermissions;
  password?: string;
  initialPassword?: string;
  legacyUid?: string;
  createdAt: string;
  updatedAt?: string;
  lastLoginAt?: string;
}

export interface Area {
  id: string;
  areaId: string;
  name: string;
  division?: string;
  description?: string;
  status: 'active' | 'inactive';
  assignedStaff: string[]; // User UIDs
  createdAt: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export interface Customer {
  id: string;
  customerId: string;
  name: string;
  phone: string;
  email?: string;
  businessName: string;
  address: string;
  areaId: string;
  areaName?: string;
  openingDue: number;
  creditLimit: number;
  currentDue: number;
  status: 'active' | 'inactive' | 'suspended';
  notes?: string;
  createdBy: string;
  createdByName?: string;
  dueStaffName?: string;
  dueStaffId?: string;
  salesStaffName?: string;
  salesStaffId?: string;
  totalPurchases?: number;
  totalPaid?: number;
  lastPurchaseAt?: string;
  lastPaymentAt?: string;
  createdAt: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface Product {
  id: string;
  productId: string;
  name: string;
  sku: string;
  categoryId: string;
  categoryName?: string;
  brand: string;
  unit: string;
  purchasePrice: number;
  salePrice: number;
  currentStock: number;
  minimumStock: number;
  status: 'active' | 'inactive';
  image?: string;
  createdAt: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export type InventoryTransactionType =
  | 'STOCK_IN'
  | 'STOCK_OUT'
  | 'ADJUSTMENT'
  | 'TRANSFER'
  | 'SALE_DEDUCTION'
  | 'SALE_RESTORE';

export interface InventoryTransaction {
  id: string;
  transactionId: string;
  productId: string;
  productName: string;
  sku?: string;
  type: InventoryTransactionType;
  quantity: number;
  previousStock: number;
  newStock: number;
  referenceId?: string; // Order ID, Invoice ID, or Transfer Reference
  reason?: string;
  performedBy: string;
  performedByName: string;
  createdAt: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  purchasePrice: number;
  total: number;
}

export type OrderStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED';
export type PaymentStatus = 'PAID' | 'PARTIAL' | 'DUE';
export type PaymentMethod = 'Cash' | 'Bank' | 'Mobile Banking' | 'Other';

export interface Order {
  id: string;
  orderId: string;
  invoiceId?: string;
  invoiceNumber?: string;
  date: string;
  staffId: string;
  staffName: string;
  areaId: string;
  areaName: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  items: OrderItem[];
  subtotal: number;
  discountType: 'fixed' | 'percentage';
  discountValue: number;
  discountAmount: number;
  grandTotal: number;
  finalAmount?: number;
  paidAmount: number;
  dueAmount: number;
  orderStatus: OrderStatus;
  status?: string;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  notes?: string;
  rejectionReason?: string;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  createdAt: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export type InvoiceStatus = 'CASH' | 'PAID' | 'PARTIAL' | 'DUE';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  orderId: string;
  date: string;
  staffId: string;
  staffName: string;
  areaId: string;
  areaName: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  customerAddress?: string;
  items: OrderItem[];
  subtotal: number;
  discountAmount: number;
  grandTotal: number;
  paidAmount: number;
  dueAmount: number;
  previousDue: number;
  currentDue: number;
  totalDue: number;
  paymentMethod: PaymentMethod;
  status: InvoiceStatus;
  terms?: string;
  createdAt: string;
}

export interface Payment {
  id: string;
  paymentId: string;
  orderId?: string;
  invoiceId?: string;
  customerId: string;
  customerName: string;
  staffId: string;
  staffName: string;
  amount: number;
  method: PaymentMethod;
  reference?: string;
  date: string;
  note?: string;
  type: 'ORDER_PAYMENT' | 'DUE_COLLECTION';
  createdAt: string;
}

export interface UserStock {
  id: string; // `${userId}_${productId}`
  userId: string;
  userName: string;
  userRole?: string;
  productId: string;
  productName: string;
  sku: string;
  unit: string;
  quantity: number;
  lastUpdated: string;
}

export type ProductRequestPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
export type ProductRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'DELIVERED';

export interface ProductRequest {
  id: string;
  requestId: string;
  productId: string;
  productName: string;
  sku?: string;
  quantity: number;
  unit?: string;
  areaId: string;
  areaName: string;
  staffId: string;
  staffName: string;
  staffEmail?: string;
  targetRecipient?: string;
  priority: ProductRequestPriority;
  note?: string;
  status: ProductRequestStatus;
  adminNote?: string;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  deductedFromUserId?: string;
  deductedFromUserName?: string;
  addedToUserId?: string;
  addedToUserName?: string;
  createdAt: string;
  updatedAt?: string;
}

export type ExpenseCategory =
  | 'Transport'
  | 'Salary'
  | 'Office'
  | 'Delivery'
  | 'Marketing'
  | 'Food'
  | 'Other';

export interface Expense {
  id: string;
  expenseId: string;
  title?: string;
  category: ExpenseCategory;
  amount: number;
  description: string;
  paymentMethod?: string;
  referenceNumber?: string;
  recipient?: string;
  note?: string;
  date: string;
  addedBy: string;
  addedByName: string;
  createdBy?: string;
  createdByName?: string;
  attachment?: string;
  createdAt: string;
  updatedAt?: string;
  isDeleted?: boolean;
}

export type NotificationType =
  | 'NEW_ORDER'
  | 'ORDER_APPROVED'
  | 'ORDER_REJECTED'
  | 'PRODUCT_REQUEST'
  | 'PRODUCT_REQUEST_STATUS'
  | 'LOW_STOCK'
  | 'PAYMENT_RECEIVED'
  | 'DUE_REMINDER'
  | 'ACCOUNT_STATUS'
  | 'PERMISSION_CHANGED';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  targetUserId?: string; // If undefined, broadcast to admins
  targetRole?: string;
  read: boolean;
  link?: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  logId?: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  recordId?: string;
  oldData?: any;
  newData?: any;
  timestamp?: string;
  createdAt?: string;
  ipAddress?: string;
}

export interface DeleteLog {
  id: string;
  collection: string;
  collectionName?: string;
  recordId: string;
  recordData?: any;
  deleteReason: string;
  deletedBy: string;
  deletedByName: string;
  deletedAt: string;
  restored?: boolean;
}

export type DeletedRecord = DeleteLog;

export interface SystemSettings {
  lastInvoiceNumber?: number;
  companyName: string;
  tagline?: string;
  partnerName?: string;
  partnerTagline?: string;
  companyPhone?: string;
  telephone?: string;
  companyEmail?: string;
  companyAddress?: string;
  headOfficeAddress?: string;
  regionalOfficeAddress?: string;
  logoUrl?: string;
  partnerLogoUrl?: string;
  address: string;
  phone: string;
  email: string;
  website?: string;

  orderPrefix?: string;
  invoicePrefix: string;
  startingNumber: number;
  invoiceFooter?: string;
  terms: string;
  signatureUrl?: string;

  currency: string;
  currencySymbol: string;
  timezone: string;
  dateFormat: string;
  taxPercentage: number;
  taxRate?: number;
  defaultDiscount: number;

  allowNegativeStock: boolean;
  lowStockThreshold: number;
  autoStockDeduction?: boolean;
  allowPartialPayments?: boolean;
}
