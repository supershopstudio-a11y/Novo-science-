# Novo Science ERP

Sales, inventory, orders, invoices, due collection and staff management (React + Firebase).
The finished website is **static files only**, so it runs on InfinityFree free hosting.

## ১. ওয়েবসাইট বিল্ড করা

**নিজের কম্পিউটারে (Node.js 20+ লাগবে):**

```
npm install
npm run build
```

`dist` ফোল্ডারে তৈরি হবে।

**কম্পিউটারে Node.js না থাকলে:** প্রজেক্টটি GitHub-এ আপলোড করুন। `Actions → Build website` নিজে থেকে বিল্ড করবে। শেষ রানের `website` ফাইলটি ডাউনলোড করে আনজিপ করুন।

## ২. Firebase Console-এ একবার সেটআপ

1. **Authentication → Sign-in method:** *Email/Password* এবং *Google* চালু করুন।
2. **Authentication → Settings → Authorized domains:** আপনার InfinityFree ডোমেইন যোগ করুন (যেমন `yourname.infinityfreeapp.com`)। এটি না করলে লগইন কাজ করবে না।
3. **Firestore Database → Rules:** `firestore.rules` ফাইলের সবটুকু পেস্ট করে **Publish** করুন।
4. (ঐচ্ছিক, নিরাপত্তার জন্য ভালো) Google Cloud Console → APIs & Services → Credentials → আপনার Browser key → *HTTP referrers* এ শুধু আপনার ডোমেইন দিন।

## ৩. InfinityFree-তে আপলোড

1. InfinityFree Client Area → **Free SSL** চালু করুন (HTTPS দরকার, বিশেষ করে মোবাইলে Google লগইনের জন্য)।
2. File Manager (বা FTP) → `htdocs` ফোল্ডারের ভেতরে `dist`-এর **ভেতরের সব ফাইল** আপলোড করুন (`dist` ফোল্ডারটি নয়):
   `index.html`, `assets/`, `.htaccess`
3. `htdocs`-এর পুরনো `index2.html` বা ডিফল্ট ফাইল থাকলে মুছে দিন।

## ৪. প্রথম লগইন

* মালিকের অ্যাকাউন্ট (`rashedulkarimrm12@gmail.com`): **Google দিয়ে লগইন** চাপুন। প্রথমবার নিজে থেকে Super Admin প্রোফাইল তৈরি হবে।
* মালিক অন্য ইমেইল ব্যবহার করলে `src/services/authContext.tsx` (`OWNER_EMAIL`) এবং `firestore.rules` (`isOwner`) — দুই জায়গাতেই বদলান।
* পুরনো স্টাফদের জন্য: **Staff Management → স্টাফ নির্বাচন → "নিরাপদ লগইনে আপগ্রেড করুন"** (শুধু Super Admin পারবেন)। একই পাসওয়ার্ডে আসল Firebase লগইন তৈরি হবে এবং ডেটাবেস থেকে পাসওয়ার্ড মুছে যাবে।
* নতুন স্টাফ: **Staff Management → নতুন স্টাফ**। পাসওয়ার্ড ভুলে গেলে স্টাফ প্রোফাইলে "রিসেট ইমেইল পাঠান"।

## কী কী ঠিক করা হয়েছে

**নিরাপত্তা:** যেকোনো পাসওয়ার্ডে "superadmin" লিখে ঢোকার ফাঁক, কোডে লুকানো গেটওয়ে পাসওয়ার্ড, ডেমো লগইন, ডেটাবেসে প্লেইন-টেক্সট পাসওয়ার্ড — সব বাদ। Firestore Rules কঠোর করা হয়েছে।

**অর্ডার/হিসাব:** অর্ডার অনুমোদন, বাতিল, পেমেন্ট ও প্রোডাক্ট রিকোয়েস্ট অনুমোদনে Firestore transaction-এর read-after-write ভুল (কাজই করত না) ঠিক করা হয়েছে। সেটিংস `global`/`system` দুই জায়গায় ছিল, এখন একটাই। ইনভয়েস নম্বর এখন ক্রমিক (INV-00001…)। অর্ডার/কাস্টমার/পণ্য ID ১৬ মিনিট পর পর মিলে গিয়ে পুরনো ডেটা মুছে ফেলতে পারত, এখন নিরাপদ। রিপোর্টে বিক্রি সবসময় ০ দেখাত এবং Pending অর্ডার ব্যাজ ০ থাকত, ঠিক হয়েছে। প্রতি লগইনে পণ্য রিসেট/পুনরুদ্ধার হওয়ার সমস্যা বন্ধ।

**মোবাইল ও কম্পিউটার:** ডেস্কটপে সাইডবার কনটেন্টের ওপর চেপে বসত, ঠিক হয়েছে। মোবাইলে পপআপ নিচ থেকে ওঠা শিট, iPhone-এ ইনপুটে জুম বন্ধ, নোটিফিকেশন স্ক্রিনের ভেতরে, মোবাইলে "+ অর্ডার" বাটন, `dvh` উচ্চতা ও নচ-সেফ এরিয়া। Notifications পেজ আগে ফাঁকা ছিল।

**গতি ও খরচ:** স্ক্রিনগুলো দরকার হলে লোড হয়। ইনভেন্টরি ও অডিট লগ শুধু ওই স্ক্রিনে খুললে পড়া হয় (Firebase read কম)। যেকোনো স্ক্রিন ক্র্যাশ করলে পুরো অ্যাপ সাদা হয় না।
